#include <iostream>
#include <string>
using namespace std;
class Node{
    public:
    string data;
    Node* next;
    Node(string s):data(s),next(nullptr){}

};
class HashTable{
    int bucket_count;
    Node**table;
    int hash_function(string str){
        int hash_value=0;
        for(int i=0;i<str.length();i++){
            hash_value+=int(str[i]);
            
        }
        return hash_value%bucket_count;
    }
    public:
    HashTable(int size){
        bucket_count=size;
        table= new Node*[bucket_count];
        for(int i=0;i<bucket_count;i++){
            table[i]=nullptr;
        }
    }
    void insert(string str){
        int index=hash_function(str);
        Node* new_node= new Node(str);
        new_node->next=table[index];
        table[index]=new_node;
    }
    bool search(string str){
        int index= hash_function(str);
        Node* curr=table[index];
        while(curr){
          if(curr->data==str)
            return true;
            curr=curr->next;
        }
        return false;

    }
    void remove(string str){
        int index= hash_function(str);
        Node*curr=table[index];
        Node*prev=nullptr;
        while(curr){
            if(curr->data==str){
                if(prev)
                    prev->next=curr->next;
                else table[index]=curr->next;
            return;
            }
            prev=curr;
            curr=curr->next;
        }
    }
    void display(){
        for(int i=0;i<bucket_count;i++){
            cout<<"Bucket "<<i+1<<": ";
            Node* curr= table[i];
            while(curr){
                cout<<curr->data<<" ";
                curr=curr->next;
            }
            cout<<endl;
        }
        cout<<endl;
    }
};
int main(){
    HashTable hash_table(10);
    hash_table.insert("apple");
    hash_table.insert("banana");
    hash_table.insert("ppale");
    hash_table.insert("grape");
    hash_table.insert("nanaba");
    hash_table.display();
    if(hash_table.search("banana"))
        cout<<"found.\n";
        else cout<<"not found.\n";
    hash_table.remove("apple");
    hash_table.display();
}