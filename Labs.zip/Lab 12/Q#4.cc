#include <iostream>
using namespace std;

class Node {
public:
    int sum, i, j;
    Node* next;
    Node(int s, int one, int two) : sum(s), i(one), j(two), next(nullptr) {}
};

class HashTable {
    int bucket_count;
    Node** table;

    int hash_function(int value) {
        return value % bucket_count;
    }

public:
    HashTable(int size) {
        bucket_count = size;
        table = new Node*[bucket_count];
        for (int i = 0; i < bucket_count; i++) {
            table[i] = nullptr;
        }
    }

    void insert(int sum, int i, int j) {
        int index = hash_function(sum);
        Node* new_node = new Node(sum, i, j);
        new_node->next = table[index];
        table[index] = new_node;
    }

    bool search(int sum, int i, int j, int arr[]) {
        int index = hash_function(sum);
        Node* curr = table[index];
        while (curr) {
            if (curr->sum == sum && curr->i != i && curr->j != j) {
                cout << "Found pairs: (" << arr[curr->i] << ", " << arr[curr->j]
                     << ") and (" << arr[i] << ", " << arr[j] << ")\n";
                return true;
            }
            curr = curr->next;
        }
        return false;
    }

    void find_pair_with_equal_sum(int arr[], int n) {
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                int sum = arr[i] + arr[j];
                if (search(sum, i, j, arr)) {
                    return;
                }
                insert(sum, i, j);
            }
        }

        cout << "No pairs found.\n";
    }
};

int main() {
    HashTable hash_table(10);
    int arr[] = {3, 4, 7, 1, 2, 9, 8};
    int n = 7;
    hash_table.find_pair_with_equal_sum(arr, n);
    return 0;
}
