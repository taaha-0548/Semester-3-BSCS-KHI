#include <iostream>
#include <string>
using namespace std;
class Page{
    public:
    string name;
    Page*next;
    Page(string s):name(s),next(nullptr){}
};
class BrowserHistory{
    Page* top;
    int size;
    public:
    BrowserHistory():top(nullptr),size(0){}
    bool is_empty(){
        return top==nullptr;
    }
    void push(string page){
        Page *new_page= new Page(page);
        new_page->next=top;
        top =new_page;
        size++;
    }
    string pop(){
        if(is_empty())
            return "";
      Page  *temp = top;
      string page_name= top->name;
        top =top->next;
        delete temp;
        size--;
        return page_name;

    }
    void back(){ // considering the scenario given in the question.
     // popping the 
        cout<< "Going back from:"<<pop()<<endl;
        cout<<"Going back from :"<<pop()<<endl;
        
    }
    void displayHistory() {
        Page* current = top;
        cout << "Current Browsing History :" << endl;
        while (current != nullptr) {
            cout << current->name << endl;
            current = current->next;
        }
        cout<<endl;
    }

};
int main(){
    BrowserHistory history;
   history.push("Google");
    history.push("Facebook");
    history.push("Twitter");
    history.push("LinkedIn");
    history.push("Instagram");
    history.displayHistory();
    history.back(); // user pressed back button twice.
    history.displayHistory();
}