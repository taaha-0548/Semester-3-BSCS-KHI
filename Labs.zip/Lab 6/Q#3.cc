#include <iostream>
#include <string>

using namespace std;

class Stack
{
private:
    char *arr;  // Change to char to store operators and operands
    int capacity;
    int top;

public:
    Stack(int capacity)
    {
        this->capacity = capacity;
        arr = new char[capacity];  // Change to char array
        top = -1;
    }

    void pop()
    {
        if (isEmpty())
        {
            cout << "Stack is Empty\n";
            return;
        }
        top--;
    }

    void push(char value)  // Change parameter type to char
    {
        if (isFull())
        {
            cout << "Stack full\n";
            return;
        }
        arr[++top] = value;
    }

    char peek()  // Change return type to char
    {
        if (isEmpty())
        {
            cout << "Stack is Empty\n";
            return -1;
        }
        return arr[top];
    }

    bool isEmpty()
    {
        return top == -1;
    }

    bool isFull()
    {
        return top == capacity - 1;
    }

    int cap()
    {
        return top + 1;
    }

    ~Stack()
    {
        delete[] arr;
    }

    int precedence(char c)
    {
        if (c == '^')
        {
            return 3;
        }
        else if (c == '*' || c == '/')
        {
            return 2;
        }
        else if (c == '+' || c == '-')
        {
            return 1;
        }
        else
        {
            return -1;
        }
    }

    string infixToPostfix(string infix)
    {
        string postfix = "";
        Stack s(infix.length());

        for (int i = 0; i < infix.length(); i++)
        {
            char c = infix[i];
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
            {
                postfix += c;  // Add operand to the output
            }
            else if (c == '(')
            {
                s.push(c);  // Push '(' to the stack
            }
            else if (c == ')')
            {
                while (!s.isEmpty() && s.peek() != '(')  // Use peek to get the top value
                {
                    char op = s.peek();
                    s.pop();  // Pop the operator
                    postfix += op;  // Add to output
                }
                if (s.peek() == '(')
                {
                    s.pop();  // Pop '('
                }
            }
            else  // If the character is an operator
            {
                while (!s.isEmpty() && precedence(c) <= precedence(s.peek()))
                {
                    char op = s.peek();
                    s.pop();
                    postfix += op;
                }
                s.push(c);
            }
        }

        // Pop all remaining operators from the stack
        while (!s.isEmpty())
        {
            char op = s.peek();
            s.pop();
            postfix += op;
        }

        return postfix;
    }
};

int main()
{
    string infixExpression;
    cout << "Enter an infix expression: ";
    getline(cin, infixExpression);  // Use getline to read the whole line

    Stack stack(infixExpression.length());
    string postfixExpression = stack.infixToPostfix(infixExpression);

    cout << "Postfix Expression: " << postfixExpression << endl;

    return 0;
}

// Precedence: ^, * /, + -,
// same priority: pop()
// Example: (A+B/C *(D+C)-F)
/*  
    Input: (A + B / C * (D + C) - F)
    
    1. (: Push ( to the stack.
    Stack: (

    2. A: Add operand A to the output.
    Postfix: A

    3. +: Push + to the stack.
    Stack: ( +

    4. B: Add operand B to the output.
    Postfix: A B

    5. /: Push / to the stack (higher precedence than +).
    Stack: ( + /

    6. C: Add operand C to the output.
    Postfix: A B C

    7. *: Pop / from the stack to output (same precedence, left to right).
    Stack: ( + 
    Postfix: A B C /

    8. Push * to the stack.
    Stack: ( + *

    9. (: Push ( to the stack.
    Stack: ( + * (

    10. D: Add operand D to the output.
    Postfix: A B C / D

    11. +: Push + to the stack.
    Stack: ( + * ( +

    12. C: Add operand C to the output.
    Postfix: A B C / D C

    13. ): Pop + from the stack to output (until '(' is found).
    Stack: ( + * 
    Postfix: A B C / D C +

    14. Pop * from the stack to output (after processing the parentheses).
    Stack: ( + 
    Postfix: A B C / D C + *

    15. -: Pop + from the stack to output (higher precedence).
    Stack: ( 
    Postfix: A B C / D C + * +

    16. Push - to the stack.
    Stack: ( -

    17. F: Add operand F to the output.
    Postfix: A B C / D C + * + F

    18. ): Pop remaining operators from the stack to output.
    Stack: ( 
    Postfix: A B C / D C + * + F -
*/

// Final Postfix Expression: A B C / D C + * + F -
