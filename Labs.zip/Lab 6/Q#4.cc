#include <iostream>
#include <string>
using namespace std;
class Order{
    string name;
    int quantity;
    public:
    Order(string s,int n ):name(s),quantity(n){}
    Order():name(" "),quantity(0){}
    string getName() const { return name; }
    int getQuantity() const { return quantity; }
};
class Order_flow{
    Order *arr;
    int size;
    int capacity;
    int rear;
    int front;
    public:
    Order_flow(int cap):capacity(cap),front(0),rear(-1),size(0){
        arr= new Order [capacity];

    }
    bool is_full(){
    return size== capacity;}
    bool is_empty(){
        return size==0;
    }
    void enqueue(Order new_order){
        if(is_full()){
            cout<<"Cant add more orders\n";
            return;
        }
        rear =(rear+1)%capacity;
        arr[rear]=new_order;
        size++;
        cout<<"Order:"<<new_order.getName()<<" with quantity: "<<new_order.getQuantity()<<" added"<<endl;

    }
    Order dequeue(){
        if(is_empty()){
            cout<<"No order to process.\n";
            return Order();
        }
        Order order= arr[front];
        front= (front+1)%capacity;
        size--;
        cout<<"Now processing order: "<<order.getName()<<"with quentity "<<order.getQuantity()<<endl;
        return order;
    }
    void print_orders(){
        if(is_empty()){
            cout<<"No orders in the queue.\n";
            return;
        }
        cout << "Current Orders in the Queue:" << endl;
        for (int i = 0; i < size; i++) {
            int index = (front + i) % capacity; // Wrap around the index
            cout << "- " << arr[index].getName() << " (" << arr[index].getQuantity() << ")" << endl;
        }
    }
    ~Order_flow() {
        delete[] arr; // Free the allocated memory
    }

};
int main() {
    Order_flow orderQueue(5); // Create an order queue with a capacity of 5

    // Adding orders to the queue
    orderQueue.enqueue(Order("Pizza", 2));
    orderQueue.enqueue(Order("Burger", 3));
    orderQueue.enqueue(Order("Pasta", 1));

    // Print current orders
    orderQueue.print_orders();

    // Process orders
    orderQueue.dequeue();
    orderQueue.dequeue();

    // Print remaining orders
    orderQueue.print_orders();

    // Try to add more orders
    orderQueue.enqueue(Order("Salad", 4));
    orderQueue.enqueue(Order("Soda", 5));

    // Print orders again to see the updated list
    orderQueue.print_orders();

    // Try to fill the queue
    orderQueue.enqueue(Order("Tacos", 2));
    orderQueue.enqueue(Order("Wings", 10)); // This will fail if the queue is full
 orderQueue.print_orders();
    return 0;
}