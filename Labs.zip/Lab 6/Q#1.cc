#include <iostream>


using namespace std;


class Stack
{
private:
    int *arr;
    int capacity;
    int top;


public:
    Stack(int capacity)
    {
        this->capacity = capacity;
        arr = new int[capacity];
        top = -1;
    }


    void pop()
    {
        if (isEmpty())
        {
            cout << "Stack is Empty\n";
            return;
        }
        top--;
    }
    void push(int value)
    {
        if (isFull())
        {
            cout << "stack full\n";
            return;
        }
        arr[++top] = value;
    }
    int peek()
    {
        if (isEmpty())
        {
            cout << "Stack is Empty\n";
            return -1;
        }
        return arr[top];
    }


    bool isEmpty()
    {
        return top == -1;
    }


    bool isFull()
    {
        return top == capacity - 1;
    }


    int cap()
    {
        return top + 1;
    }
    ~Stack()
    {
        delete[] arr;
    }
};
int main()
{
    Stack stack(8);
    stack.push(1);
    cout << stack.peek() << endl;
    stack.pop();
    if (stack.isEmpty() == true)
        cout << "stack is empty\n";
    cout << stack.cap();
}