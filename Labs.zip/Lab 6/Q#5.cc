#include <iostream>
#include <string>
using namespace std;
 // implementing a simple linear queue with linked list.

class Text{
    public:
    string message;
    Text *next;
    Text(string mes):message(mes),next(nullptr){}
};
class MessageApplication{
    // implementing a simple linear queue.
    Text *front;
    Text *rear;
    int size;
    public:
    MessageApplication() : front(nullptr), rear(nullptr), size(0) {}
    bool is_empty(){
        return size==0;
    }
    void enqueue(string msg){
        Text *new_text= new Text(msg);
        if(is_empty()){
            front= rear= new_text;
        }else{
            rear->next= new_text;
            rear= new_text;
        }
        size++;
        cout<<"Message added: "<<msg<<endl;
    }
    string dequeue(){
        if(is_empty()){
            cout<<"No message to process."<<endl;
            return "";
        }
        Text* temp= front;
        string message= front->message;
        front= front->next;
        delete temp;
        size--;
        cout<<"message processing: "<< message<<endl;
        return message;
    }
        int get_size() {
        return size;
    }
    void display(){
        if(is_empty()){
            cout<<"No messages to display:\n";
            return;
        }
        cout<<"Current messages:\n";
        Text *temp =front;
        while(temp){
            cout<<"-"<<temp->message<<endl;
            temp= temp->next;
        }
    }
    
};
int main(){
    MessageApplication queue;
     queue.enqueue("Hello, User 1!");
    queue.enqueue("Welcome to the messaging app!");
    queue.enqueue("Your order has been processed.");
    
    queue.display(); // Display current messages in the queue

    queue.dequeue(); // Process the first message
    queue.dequeue(); // Process the second message

    queue.display(); // Display remaining messages in the queue

    return 0;
}