#include <iostream>
#include <string>
using namespace std;

const int  MAX =10;
class Patron{
    public:
    string name;
    int books;
    Patron(string name, int books) : name(name), books(books) {}

};
class LibraryQ{
    Patron* arr[MAX];
    int front,rear;
    public:
    LibraryQ():front(0),rear(-1){}
    bool is_full(){
        return rear== MAX-1;
    }
    bool is_empty(){
        return front==-1 || front>rear;
    }
      void enqueue(string name, int books) {
        if (is_full()) {
            cout << "Queue is full, cannot add patron " << name << endl;
            return;
        }
       
        arr[++rear] = new Patron(name, books); 
        cout << "Patron " << name << " added to the queue with " << books << " book(s)." << endl;
    }
    void dequeue() {
        if (is_empty()) {
            cout << "Queue is empty, no patron to serve." << endl;
            return;
        }
        Patron* patron = arr[front]; 
        cout << "Serving patron " << patron->name << " with " << patron->books << " book(s)." << endl;
        delete patron; 
        front++; 
        if (front > rear) { 
            front = rear = -1;
        }
    }

    
    void display_Q() {
        if (is_empty()) {
            cout << "The queue is currently empty." << endl;
            return;
        }
        cout << "Current queue of patrons:" << endl;
        for (int i = front; i <= rear; i++) {
            cout << "- " << arr[i]->name << " (" << arr[i]->books << " book(s))" << endl;
        }
    }

  
 
};
int main() {
    LibraryQ libraryQueue;

    // Automatically enqueue some patrons
    libraryQueue.enqueue("Alice", 3);
    libraryQueue.enqueue("Bob", 5);
    libraryQueue.enqueue("Charlie", 2);
    libraryQueue.enqueue("David", 4);
    libraryQueue.enqueue("Eve", 1);

    // Display the queue after adding patrons
    libraryQueue.display_Q();

    // Dequeue a few patrons
    libraryQueue.dequeue();
    libraryQueue.dequeue();

    // Display the queue after serving some patrons
    libraryQueue.display_Q();

    // Add a few more patrons to the queue
    libraryQueue.enqueue("Frank", 3);
    libraryQueue.enqueue("Grace", 6);

    // Display the final state of the queue
    libraryQueue.display_Q();
}
