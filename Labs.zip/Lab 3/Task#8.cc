#include <iostream>
#include <string>
using namespace std;
class Node{
    public:
    int data;
    Node* next;
    Node* prev;
    Node(int val):data(val), next(nullptr),prev(nullptr){}

};
class DoublyLinkedList{
    Node* head;
    Node* tail;
    public:
    DoublyLinkedList():head(nullptr),tail(nullptr){}
    void insert_at_end(int val){
        Node* new_node= new Node(val);
        // if the list is empty, then new node will be both tail and head
        if(!head){
            head=new_node;
            tail=new_node;
        }else{
            tail->next=new_node;
            new_node->prev=tail;
            tail= new_node;
        }
        cout<<"New node is added with value: "<<val<<endl;
    }
    void delete_at_front(){
        if(!head){
            cout<<"List is empty.\n";
        }
        if(head==tail){//means there is only one node
            head= nullptr;
            tail= nullptr;
        } else{
        Node* temp= head;
        head= temp->next;
        head->prev = nullptr;
        delete temp;
        }
    }
    bool search(int val){
        Node *temp= head;
        while(temp){
            if(temp->data==val)
                return true;
            temp=temp->next;
        }
        return false;
    }
    void display(){
        Node *temp= head;
        while(temp){
            cout<<temp->data<<" ";
            temp=temp->next;

        }
        cout<<endl;
    }
};
int main() {
    DoublyLinkedList dll;

    dll.insert_at_end(10);
    dll.insert_at_end(20);
    dll.insert_at_end(30);
    dll.insert_at_end(40);

    cout << "Doubly Linked List after insertions: ";
    dll.display();

    cout << "Searching for 20: " << (dll.search(20) ? "Found" : "Not Found") << "\n";
    cout << "Searching for 50: " << (dll.search(50) ? "Found" : "Not Found") << "\n";

    dll.delete_at_front();
    cout << "Doubly Linked List after deleting at front: ";
    dll.display();

    return 0;
}
