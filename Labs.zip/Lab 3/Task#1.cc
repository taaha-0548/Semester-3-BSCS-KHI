#include <iostream>
#include <string>

using namespace std;

class Student
{
public:
    int score;
    string name;
    Student *next;

    Student(string n, int s) : name(n), score(s), next(nullptr) {}
};

class Studentlist
{
    Student *head;
    int size;

public:
    Studentlist() : size(0), head(nullptr) {}

    // Destructor using delete_from_front to free memory
    ~Studentlist()
    {
        while (head != nullptr)
        {
            delete_from_front();  // Call delete_from_front to remove each node
        }
    }

    // Function to add to the head of the list
    void add_to_start(string student_name, int student_score)
    {
        Student *new_student = new Student(student_name, student_score);
        new_student->next = head;
        head = new_student;
        size++;
        cout << student_name << " added to the start of the list with score: " << student_score << endl;
    }
 // Function to delete from the front of the list
    void delete_from_front() {
        if (!head) {
            cout << "Linked list is empty.\n";
            return;
        }
        Student* temp = head;
        head = temp->next;
        delete temp;
        size--;
        cout << "Student deleted from the front.\n";
    }

    // Function to delete from the tail of the list
    void delete_from_tail() {
        if (!head) {
            cout << "Linked list is empty.\n";
            return;
        }

        if (head->next == nullptr) {  // Only one node
            delete_from_front();
            return;
        }

        Student* temp = head;
        Student* prev = nullptr;
        while (temp->next != nullptr) {
            prev = temp;
            temp = temp->next;
        }
        delete temp;
        prev->next = nullptr;
        size--;
        cout << "Student deleted from the tail.\n";
    }

    // Function to delete a student by name (at a specific key)
    void delete_at_key(string student_name) {
        if (!head) {
            cout << "Linked list is empty.\n";
            return;
        }

        if (head->name == student_name) {  // If the key is at the head
            delete_from_front();
            return;
        }

        Student* temp = head;
        Student* prev = nullptr;
        while (temp != nullptr && temp->name != student_name) {
            prev = temp;
            temp = temp->next;
        }

        if (temp == nullptr) {  // Student not found
            cout << "Student with name " << student_name << " not found.\n";
            return;
        }

        prev->next = temp->next;  // Bypass the node to be deleted
        delete temp;
        size--;
        cout << "Student with name " << student_name << " deleted from the list.\n";
    }

    // Function to add to the tail of the list
    void add_to_tail(string student_name, int student_score)
    {
        Student *new_student = new Student(student_name, student_score);
        if (!head)
        {
            head = new_student;
        }
        else
        {
            Student *temp = head;
            while (temp->next != nullptr)
            {
                temp = temp->next;
            }
            temp->next = new_student;
        }
        size++;
        cout << student_name << " added to the end of the list with score: " << student_score << endl;
    }

    // Function to add at a specific position after a given student
    void add_to_position(string student_name, int student_score, string key)
    {
        Student *new_student = new Student(student_name, student_score);
        if (!head)
        {
            head = new_student;
        }
        else
        {
            if (!search_student(key))
                return;
            Student *temp = head;
            while (temp && temp->name != key)
            {
                temp = temp->next;
            }
            new_student->next = temp->next;
            temp->next = new_student;
        }
        size++;
        cout << student_name << " with score: " << student_score << " added after " << key << endl;
    }

    // Function to search for a student by name
    bool search_student(string student_name)
    {
        Student *temp = head;
        while (temp)
        {
            if (temp->name == student_name)
            {
                cout << student_name << "'s score: " << temp->score << endl;
                return true;
            }
            temp = temp->next;
        }
        cout << "Student with name: " << student_name << " not found in the list.\n";
        return false;
    }

    // Function to display the entire list
    void display_list()
    {
        Student *temp = head;
        while (temp)
        {
            cout << "Student name: " << temp->name << " | Score: " << temp->score << endl;
            temp = temp->next;
        }
        cout << endl;
    }
};

int main()
{
    Studentlist students;

    students.add_to_start("Alice", 90);
    students.display_list();
    students.add_to_tail("Frank", 89);
    students.display_list();
    students.add_to_position("Grace", 92, "Frank");
    students.display_list();
    students.add_to_start("Eve", 88);
    students.display_list();
    students.add_to_position("David", 95, "Frank");
    students.display_list();

    cout << "Current student list:\n";
    students.display_list();

    return 0;
}
