#include <iostream>
#include <string>
using namespace std;
class Node{
    public:
    int data;
    Node*next;
    Node(int d):data(d),next(nullptr){}

};
class Linked_list{
    Node* head;
    int size;
    public:
    Linked_list():size(0),head(nullptr){}
    void add_to_head(int value){
        Node* new_node= new Node(value);
        new_node->next= head;
        head=new_node;
        size++;
        
    }
    void display(){
        Node *temp= head;
        while(temp){
            cout<<"-> " ;
            cout<<temp->data;
            temp=temp->next;
        }
        cout<<endl;
    }
    void reverse(){
        Node *curr= head;
        Node *next_node= nullptr;
        Node *prev= nullptr;
        while(curr){
            next_node=curr->next;
            curr->next= prev; // reversing the direction.
            prev= curr; // move prev and curr one step forward.
            curr= next_node;
        }
        head =prev;
        
        
    }
};
int main() {
    Linked_list list;

    // Adding some elements
    list.add_to_head(10);
    list.add_to_head(20);
    list.add_to_head(30);

    // Display the list before reversing
    cout << "Original List:\n";
    list.display();

    // Reverse the list
    list.reverse();

    // Display the list after reversing
    cout << "Reversed List:\n";
    list.display();

    return 0;
}
