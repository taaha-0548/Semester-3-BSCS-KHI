#include <iostream>
#include <string>
using namespace std;
class Task{
    public:
    string description;
    Task* next;
    Task(string des):description(des),next(nullptr){}

};
class ToDoList{
    Task *head;
    int size;
    public:
    ToDoList():head(nullptr),size(0){}
    void add_to_front(string des){
        Task* new_task= new Task(des);
        new_task->next =head;
        head= new_task;
        cout<<"New task added.\n";
        size++;
    }
    void delete_from_front(){
        if(!head){
            cout<<"To-do-List is empty.\n";
            return;
        }
        Task* temp= head;
        head= temp->next;
        delete temp;
        cout<<"Task deleted from the front of the To-do-List.\n";

    }
    void delete_from_tail(){
        if(!head){
            cout<<"To-do-List is empty.\n";
            return;
        }   
        if(head->next== nullptr){
            delete_from_front();
            cout<<"Only one element in to-do-list.\n";
        }
        Task *temp= head;
        Task *prev = nullptr;
        while(temp->next!=nullptr){
            prev= temp;
            temp= temp->next;
        }
        delete temp;
        prev->next=nullptr;
        size--;
    }
    void add_to_tail(string des){
        Task *new_task= new Task( des);
        if(!head)
            head= new_task;
        else{
            Task *temp= head;
            while(temp->next!=nullptr){
                temp= temp->next;
            }
            temp->next= new_task;
        }
        size++;
        cout<<"New Task added to the end of the To-do-List.\n";
    }
    void delete_from_position(string desc){
        if(!head){
            cout<<"To-do-List is empty\n";
            return;
        }
        if(head->description==desc){
            delete_from_front();
            cout<<"Only task removed.\n";
            return;
        }
        Task *temp= head;
        Task *prev= nullptr;
        while(temp ){
            if(temp->description==desc){
                prev->next=temp->next;
                delete temp;
                size--;
                cout<<"Tasked named as: "<<desc<<"removed from the list\n";
                size--;
                return;
            }
            prev= temp;
            temp= temp->next;
        }
         cout<<"Task not found.\n";

    }
     void display_list() {
        if (!head) {
            cout << "To-do-List is empty.\n";
            return;
        }
        Task* temp = head;
        while (temp != nullptr) {
            cout << "- " << temp->description << endl;
            temp = temp->next;
        }
    }

};
int main() {
    ToDoList todo_list;

    // Add tasks to the front
    todo_list.add_to_front("Buy groceries");
    todo_list.add_to_front("Finish a report");
    todo_list.add_to_front("Go for a run");

    // Display the initial list
    cout << "Current To-do-List:\n";
    todo_list.display_list();
    cout << endl;

    // Deletion from the Front: "Buy groceries"
    cout << "Deleting the task 'Buy groceries' from the front...\n";
    todo_list.delete_from_front();
    cout << "Updated To-do-List:\n";
    todo_list.display_list();
    cout << endl;

    // Add a new task to the tail: "Call a friend"
    todo_list.add_to_tail("Call a friend");
    cout << "Updated To-do-List after adding 'Call a friend':\n";
    todo_list.display_list();
    cout << endl;

    // Deletion from the Tail: "Call a friend"
    cout << "Deleting the task 'Call a friend' from the tail...\n";
    todo_list.delete_from_tail();
    cout << "Updated To-do-List:\n";
    todo_list.display_list();
    cout << endl;

    // Deletion at a Specific Position: "Finish a report"
    cout << "Deleting the task 'Finish a report' from a specific position...\n";
    todo_list.delete_from_position("Finish a report");
    cout << "Updated To-do-List:\n";
    todo_list.display_list();

    return 0;
}