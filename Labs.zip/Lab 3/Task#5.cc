#include <iostream>
#include <string>
using namespace std;
class Node{
    public:
    int data;
    Node* next;
    Node(int d):data(d),next(nullptr){}

};
class LinkedList{
    public:
    Node *head;
    LinkedList():head(nullptr){}
    void add_to_front(int val){
        Node* new_node= new Node(val);
        new_node->next=head;
        head= new_node;
        cout<<"New node added with value: "<< val<<endl;
    }
    void display(){
        Node *temp= head;
        while(temp){
            cout<<temp->data<<" ";
            temp=temp->next;
        }
        cout<<endl;
    }
    // helping funciton to swap data in nodes.
    void swap_data(Node *one, Node *two){
        int temp= one->data;
        one->data=two->data;
        two->data=temp;
    }
    //function to implement bubble sort.
    void sort_list(){
        if(!head){
            cout<<"Linked list is empty\n";
            return;
        }
        bool sort; //to check if all the values in the list are sorted.
        Node* a;
        Node* last= nullptr;
        do{
            sort= false;
            a= head;
            while(a->next!=last){// since the last element will be sorted 
                if(a->data > a->next->data){
                    swap_data(a,a->next);
                    sort=true;
                }
                a=a->next; 
            }
            last =a; // to mark the sorted portion. 


        }while(sort);
        
    }
};


int main(){
    LinkedList first;
    first.add_to_front(31);
    first.add_to_front(25);
    first.add_to_front(10);
    first.add_to_front(100);
    first.add_to_front(21);
    first.add_to_front(143);
    first.add_to_front(37);
    first.add_to_front(2);
    first.add_to_front(100);

    first.display();
    first.sort_list();
    first.display();
    
}