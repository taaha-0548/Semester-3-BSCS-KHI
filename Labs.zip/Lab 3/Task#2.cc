
#include <iostream>
#include <string>
using namespace std;
class Book{
    public:
    Book *next;
    string name;
    Book(string n):name(n),next(nullptr){}
};
class Library{
    Book* head;
    int size;
    public:
    Library():head(nullptr),size(0){}
    ~Library() {
    while (head) {
        delete_from_the_front();
    }
}

    void add_book_to_tail(string book_name){
        Book *newbook= new Book(book_name);
        if(!head)
            head= newbook;
        else{
        Book *temp=head;
        while(temp->next!=nullptr){
            temp=temp->next;
        }
        temp->next= newbook;

        }
        cout<<book_name<<" added to the library.\n";
        size++;
    }
    void delete_from_the_front(){
        if(!head){
            cout<<"Library is empty.\n";
            return;
        }
      Book* temp = head;
     
        head = temp->next;
    
        delete temp;
        cout<<"Book removed from the start of the list.\n";
        size--;
    }
    void search_by_title(string bookname){
        if(!head){
            cout<<"Library is empty.\n";
            return;
        }
        Book *temp= head;
        while(temp){
            if(temp->name== bookname){
                cout<<bookname<<" book found in the list.\n";
                return;
            }
            temp=temp->next;
        }
        cout<<"Book not found in the list.\n";
    }
    void search_by_position(int index){
        if(!head){
            cout<<"Library is empty.\n";
            return;
        }
        if(index<0||index>=size){
            cout<<"Invalid position\n";
            return;
        }
        Book *temp=head;
        for(int i=0;i<index;i++){
            temp=temp->next;
        }   
        cout<<"Book at position"<<index<<" positon: "<<temp->name<<endl;

    }
    void display_catalog() {
    if (!head) {
        cout << "Library is empty.\n";
        return;
    }
    Book* temp = head;
    int position = 0;
    while (temp) {
        cout << "Book at position " << position++ << ": " << temp->name << endl;
        temp = temp->next;
    }
}

};
int main(){
    Library my_library;
    my_library.add_book_to_tail("harry potter");
    my_library.add_book_to_tail("fowl twins");
    my_library.add_book_to_tail("how to win friends");
    my_library.add_book_to_tail("dont give up");
    my_library.delete_from_the_front();
    my_library.search_by_position(1);
    my_library.search_by_title("harry potter");
     my_library.display_catalog();


}