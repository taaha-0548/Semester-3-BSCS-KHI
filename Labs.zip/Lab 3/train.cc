#include <iostream>
#include <string>
using namespace std;

class Node {
public:
    int demand;
    int distance;
    Node* next;

    Node() {
        demand = 0;
        distance = 0;
        next = NULL;
    }

    Node(int val, int val2) {
        demand = val;
        distance = val2;
        next = NULL;
    }
};

class Circular {
public:
    Node* head;
    Node* tail;

    Circular() {
        head = NULL;
        tail = NULL;
    }

    // Insert at the end of the circular linked list
    void insert_at_end(int val, int val2) {
        Node* n = new Node(val, val2);
        if (!head) {
            head = n;
            tail = n;
            tail->next = head;
        } else {
            tail->next = n;
            tail = n;
            tail->next = head;  // Circular linkage
        }
    }

    // Insert at the head of the circular linked list
    void insert_at_head(int val, int val2) {
        Node* n = new Node(val, val2);
        if (!head) {
            head = n;
            tail = n;
            tail->next = head;
        } else {
            n->next = head;
            head = n;
            tail->next = head;  // Update circular linkage
        }
    }
};

void return_to_head(int petrol, int n, Circular& list) {
    Node* temp = list.head;
    int ratio = petrol / n;
    int temp_ratio = 0;
    bool visitedAll = false;

    cout << "Visiting cities: " << endl;

    // Traverse the circular list and check conditions
    while (temp && petrol > 0 && !visitedAll) {
        temp_ratio = temp->demand / temp->distance;

        if (temp_ratio > ratio) {
            cout << "Skipping city with demand " << temp->demand << " and distance " << temp->distance << endl;
        } else {
            petrol -= temp->demand;
            cout << "Visiting city with demand " << temp->demand << " and distance " << temp->distance << endl;
        }

        temp = temp->next;
        if (temp == list.head) {  // If we circle back to the head, stop
            visitedAll = true;
        }
    }
    
    if (petrol > 0) {
        cout << "Returned with " << petrol << " litres of petrol remaining." << endl;
    } else {
        cout << "Ran out of petrol!" << endl;
    }
}

int main() {
    // Initial petrol
    int petrol = 1000;

    // Number of towns
    int n = 4;

    // Create circular list of cities with demand and distance
    Circular cities;
    cities.insert_at_end(300, 50);
    cities.insert_at_end(200, 40);
    cities.insert_at_end(400, 60);
    cities.insert_at_end(250, 30);

    // Test the function to return to head and print visited cities
    return_to_head(petrol, n, cities);

    return 0;
}
