#include <iostream>
#include <string>
using namespace std;
class Table
{
public:
    static int table_counter;
    int table_no;
    bool reservation_status;
    string customer_name;
    Table *next;
    Table() : customer_name(""), reservation_status(false), next(nullptr)
    {
        table_no = ++table_counter;
    }
};
int Table::table_counter = 0;

class CircularLinkedList
{
    int number_of_tables;
    Table *head;
    void create_tables()
    {
        if (number_of_tables <= 0)
            return;
        Table *last = nullptr;
        for (int i = 0; i < number_of_tables; i++)
        {
            Table *new_table = new Table();
            if (head == nullptr)
                head = new_table;
            else
                last->next = new_table;
            last = new_table;
        }
        last->next = head;
    }

    

    public:
    CircularLinkedList(int n) : number_of_tables(n), head(nullptr)
    {
        create_tables();
    }
    bool reserve_table(string customer_name)
    {
        if (head == nullptr)
            return false;

        Table *temp = head;
        do
        {
            if (!temp->reservation_status)
            {
                temp->reservation_status = true;
                temp->customer_name = customer_name;
                cout << "Table " << temp->table_no << " has been reserved by " << customer_name << ".\n";
                return true;
            }
            temp = temp->next;
        } while (temp != head);

        cout << "No available tables for reservation.\n";
        return false;
    }
    bool cancel_reservation(string customer_name) {
        if (head == nullptr) return false;

        Table* temp = head;
        do {
            if (temp->reservation_status && temp->customer_name == customer_name) {
                temp->reservation_status = false;
                cout << "Reservation for " << customer_name << " on Table " << temp->table_no << " has been canceled.\n";
                return true;
            }
            temp = temp->next;
        } while (temp != head);

        cout << "No reservation found for customer " << customer_name << ".\n";
        return false;
    }
     void display_table_status() {
        if (head == nullptr) return;

        Table* temp = head;
        do {
            cout << "Table " << temp->table_no 
                 << (temp->reservation_status ? " is reserved by " + temp->customer_name : " is available") 
                 << ".\n";
            temp = temp->next;
        } while (temp != head);
    }

};
int main()
{
    // Create a CircularLinkedList with 5 tables
    CircularLinkedList restaurant(5);

    // Display initial table status
    cout << "Initial table status:\n";
    restaurant.display_table_status();

    // Reserve some tables
    restaurant.reserve_table("Alice");
    restaurant.reserve_table("Bob");

    // Display table status after reservations
    cout << "\nTable status after reservations:\n";
    restaurant.display_table_status();

    // Cancel a reservation
    restaurant.cancel_reservation("Alice");

    // Display table status after cancellation
    cout << "\nTable status after cancellation:\n";
    restaurant.display_table_status();

    // Try to reserve a table when no available tables
    restaurant.reserve_table("Charlie");

    return 0;
}