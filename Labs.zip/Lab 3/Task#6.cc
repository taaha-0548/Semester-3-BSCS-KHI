#include <iostream>
#include <string>
using namespace std;
class Node{
    public:
    int data;
    Node* next;
    Node(int d):data(d),next(nullptr){}

};
class LinkedList{
    public:
    Node *head;
    LinkedList():head(nullptr){}
    void add_to_front(int val){
        Node* new_node= new Node(val);
        new_node->next=head;
        head= new_node;
        cout<<"New node added with value: "<< val<<endl;
    }
    void display(){
        Node *temp= head;
        while(temp){
            cout<<temp->data<<" ";
            temp=temp->next;
        }
        cout<<endl;
    }
    
};
// function to concatenate two lists (first list will contain all the nodes)
void Concatenate_linked_lists(LinkedList &first,LinkedList &second){
    if(!first.head){
        first.head=second.head;
        return;
    }
    Node *temp=first.head;
    while(temp->next!=nullptr){
        temp=temp->next;
    }
    temp->next= second.head;
    cout<<"Concatenated.\n";
}
int main(){
    LinkedList first;
    first.add_to_front(3);
    first.add_to_front(2);
    first.add_to_front(1);
    first.display();
    LinkedList second;
    second.add_to_front(6);
    second.add_to_front(5);
    second.add_to_front(4);
    second.display();
    Concatenate_linked_lists(first,second);
    first.display();

}