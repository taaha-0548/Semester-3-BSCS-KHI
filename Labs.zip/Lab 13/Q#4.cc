#include <iostream>
#include <string>
using namespace std;
void computing_prefix(string pattern, int lps[]){
    int p = pattern.length();
    int len =0;
    lps[0]=0;
    for(int i=1;i<p;i++){
        while(len>0&&pattern[i]!=pattern[len])
            len=lps[len-1];
        if(pattern[i]==pattern[len])
        len++;
        lps[i]=len;
    }
    
    }
    int KMP(string text, string pattern){
        int t= text.length();
        int p=pattern.length();
        if(p>t)
            return -1;
        int lps[p];
        computing_prefix(pattern,lps);
        int i=0,j=0;
        while(i<t){
            if(text[i]==pattern[j]){
                i++;
                j++;
                if(j==p)
                    return i-j;
                }else{
                    if(j>0)
                        j=lps[j-1];
                    else 
                        i++;
                }
            
        }
        return -1;
    }
    int main(){
        string text = "ababcababcd";
        string pattern = "abcd";
        cout<<KMP(text,pattern);
    }