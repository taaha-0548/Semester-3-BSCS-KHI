#include <iostream>
#include <string>
using namespace std;
void computing_prefix(string pattern, int lps[]){
    int p = pattern.length();
    int len =0;
    lps[0]=0;
    for(int i=1;i<p;i++){
        while(len>0&&pattern[i]!=pattern[len])
            len=lps[len-1];
        if(pattern[i]==pattern[len])
        len++;
        lps[i]=len;
    }
    
    }
    int KMP(string text, string pattern){
        int t= text.length();
        int p=pattern.length();
        if(p>t)
            return -1;
        int lps[p];
        computing_prefix(pattern,lps);
        int i=0,j=0;
        while(i<t){
            if(text[i]==pattern[j]){
                i++;
                j++;
                if(j==p)
                    return i-j;
                }else{
                    if(j>0)
                        j=lps[j-1];
                    else 
                        i++;
                }
            
        }
        return -1;
    }
    int brute_force(string text, string pattern){ 
    int t= text.length();
    int p =pattern.length();

    for(int i=0;i<=t-p;i++){
          bool  found =true;
        if(text[i]== pattern[0]){ // checks if the first character matches the pattern's first character
            for(int j=1;j<p;j++){ // checks from the second character of both strings
                if(text[i+j]!=pattern[j]){ // if there is mismatch, the inner loop breaks and we continue the search.
                    found =false;
                    break;
                }
            }
            if(found)    // if the loop has completed without a mismatch then this would be true, returning the ith index
            return i;
        }
    }
    }
    int main(){
        string text = "ababcababcd";
        string pattern = "abcd";
        cout<<brute_force(text,pattern)<<endl;
        cout<<KMP(text,pattern);
    }