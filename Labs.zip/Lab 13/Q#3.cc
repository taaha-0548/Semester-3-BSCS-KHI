#include <iostream>
#include <string>
using namespace std;
void create_bad_character(string pattern,int bad_char[256]){
    int p=pattern.length();
    for(int i=0;i<256;i++){
        bad_char[i]=-1;
    }
    for(int i=0;i<p;i++){
        bad_char[pattern[i]]=i; // for storing the last occurence of each character.

    }

}
int Boyre_Moore(string text,string pattern){
    int t= text.length();
    int p=pattern.length();
    if(p>t)
        return -1;
    int bad_char[256];
    create_bad_character(pattern,bad_char);
    int i=0;
    while(i<=t-p){
        int j=p-1;
        while( j>=0 &&pattern [j]== text[i+j]) 
            j--;
        if(j<0) // if the pattern matches
            return i;
        else
            i+= max(1,j-bad_char[text[i+j]]); // we dont start from the start again
    }
    return -1;
}
int main() {
    string text = "badrabradadbra";
    string pattern = "rada";

    cout<<Boyre_Moore(text,pattern);
    return 0;
}