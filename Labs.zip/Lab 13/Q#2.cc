#include <iostream>
#include <string>
using namespace std;

const int d = 256; // Number of characters in the input alphabet (ASCII)
const int q = 101; // A prime number for modulo operation

// Function to compute the initial hash value for the first 's' characters of a string
int hash_rolling_function(const string& text, int s) {
    int hash_value = 0;
    for (int i = 0; i < s; i++) {
        hash_value = (hash_value * d + text[i]) % q;
    }
    return hash_value;
}

// Rabin-Karp Algorithm for pattern searching
int Rabin_Karp(const string& text, const string& pattern) {
    int t = text.length(); // Length of the text
    int p = pattern.length(); // Length of the pattern
    
    if (p > t) {
        return -1; // If pattern is longer than the text, return -1
    }

    // Compute the hash values for the pattern and the first window of the text
    int p_hash = hash_rolling_function(pattern, p);
    int t_hash = hash_rolling_function(text, p);

    // Precompute d^(p-1) % q for rolling hash updates
    int h = 1;
    for (int i = 0; i < p - 1; i++) {
        h = (h * d) % q;
    }

    // Search for the pattern in the text
    for (int i = 0; i <= t - p; i++) {
        // If the hash values match, check the characters to avoid collisions
        if (p_hash == t_hash) {
            if (text.substr(i, p) == pattern) {
                return i; // Return the index where the pattern is found
            }
        }

        // Calculate the hash value for the next window of text
        if (i < t - p) {
            t_hash = (d * (t_hash - text[i] * h) + text[i + p]) % q;
            if (t_hash < 0) {
                t_hash += q; // Ensure the hash is non-negative
            }
        }
    }

    return -1; // Return -1 if no match is found
}

int main() {
    string text = "baracababra";
    string pattern = "abra";

    int result = Rabin_Karp(text, pattern);
    if (result != -1) {
        cout << "Pattern found at index: " << result << endl;
    } else {
        cout << "Pattern not found" << endl;
    }

    return 0;
}
