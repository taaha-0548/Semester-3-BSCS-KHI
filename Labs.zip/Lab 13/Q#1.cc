#include <iostream>
#include <string>
using namespace std;
int brute_force(string text, string pattern){ 
    int t= text.length();
    int p =pattern.length();

    for(int i=0;i<=t-p;i++){
          bool  found =true;
        if(text[i]== pattern[0]){ // checks if the first character matches the pattern's first character
            for(int j=1;j<p;j++){ // checks from the second character of both strings
                if(text[i+j]!=pattern[j]){ // if there is mismatch, the inner loop breaks and we continue the search.
                    found =false;
                    break;
                }
            }
            if(found)    // if the loop has completed without a mismatch then this would be true, returning the ith index
            return i;
        }
    }
    return -1;
}
int main(){
    string text= "Alu potato";
    string pattern= "ota";
    cout<<brute_force(text,pattern);
}