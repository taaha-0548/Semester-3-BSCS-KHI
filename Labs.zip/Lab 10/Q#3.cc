#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;
    Node(int l) : data(l), left(nullptr), right(nullptr) {}
};

class AVL {
     Node* insert(Node* node, int key) {
        if (!node) return new Node(key);

        // Perform normal BST insert
        if (key < node->data) {
            node->left = insert(node->left, key);
        } else if (key > node->data) {
            node->right = insert(node->right, key);
        } else {
            return node;  // Duplicate keys are not allowed
        }

        // Update the balance factor of this node
        int balance = get_balance(node);

        // Left Left Case
        if (balance > 1 && key < node->left->data) {
            return right_rotate(node);
        }

        // Right Right Case
        if (balance < -1 && key > node->right->data) {
            return left_rotate(node);
        }

        // Left Right Case
        if (balance > 1 && key > node->left->data) {
            node->left = left_rotate(node->left);
            return right_rotate(node);
        }

        // Right Left Case
        if (balance < -1 && key < node->right->data) {
            node->right = right_rotate(node->right);
            return left_rotate(node);
        }

        // Return the (unchanged) node pointer
        return node;
    }
public:
    Node* root;
    AVL():root(nullptr){}
    int height(Node* node) {
        if (!node) return 0;
        return 1 + max(height(node->left), height(node->right));
    }
    void insert_node(int val){
        root=insert(root,val);
    }

    int get_balance(Node* node) {
        if (!node) return 0;
        return height(node->left) - height(node->right);
    }

    Node* right_rotate(Node* y) {
        Node* x = y->left;
        Node* T2 = x->right;
        // Perform rotation
        x->right = y;
        y->left = T2;
        return x;
    }

    Node* left_rotate(Node* x) {
        Node* y = x->right;
        Node* T2 = y->left;
        // Perform rotation
        y->left = x;
        x->right = T2;
        return y;
    }

   

    Node* minValueNode(Node* node) {
        Node* current = node;
        while (current && current->left) {
            current = current->left;
        }
        return current;
    }

    Node* delete_node(Node* root, int key) {
        if (!root) return root;

        // Step 1: Perform standard BST delete
        if (key < root->data) {
            root->left = delete_node(root->left, key);
        } else if (key > root->data) {
            root->right = delete_node(root->right, key);
        } else {
            // Node with only one child or no child
            if (!root->left) {
                Node* temp = root->right;
                delete root;
                return temp;
            } else if (!root->right) {
                Node* temp = root->left;
                delete root;
                return temp;
            }

            // Node with two children: Get the inorder successor (smallest in the right subtree)
            Node* temp = minValueNode(root->right);

            // Copy the inorder successor's content to this node
            root->data = temp->data;

            // Delete the inorder successor
            root->right = delete_node(root->right, temp->data);
        }

        // Step 2: Balance the tree after deletion
        int balance = get_balance(root);

        // Left Left Case
        if (balance > 1 && get_balance(root->left) >= 0) {
            return right_rotate(root);
        }

        // Left Right Case
        if (balance > 1 && get_balance(root->left) < 0) {
            root->left = left_rotate(root->left);
            return right_rotate(root);
        }

        // Right Right Case
        if (balance < -1 && get_balance(root->right) <= 0) {
            return left_rotate(root);
        }

        // Right Left Case
        if (balance < -1 && get_balance(root->right) > 0) {
            root->right = right_rotate(root->right);
            return left_rotate(root);
        }

        return root;
    }

    void inorderTraversal(Node* root) {
        if (root != nullptr) {
            inorderTraversal(root->left);
            cout << root->data << " ";
            inorderTraversal(root->right);
        }
    }
  
};

int main() {
    AVL tree;
   tree.insert_node(10);
   tree.insert_node(5);
   tree.insert_node(15);
   tree.insert_node(3);
   tree.insert_node(7);
 
   

    cout << "Inorder traversal of the constructed AVL tree is \n";
    tree.inorderTraversal(tree.root);
    cout << endl;

   tree.insert_node(12);

    cout << "Inorder traversal of the constructed AVL tree after insertion is \n";
    tree.inorderTraversal(tree.root);
    cout << endl;

    return 0;
}
