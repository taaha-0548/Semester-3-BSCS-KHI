
    cout << "Original array: ";