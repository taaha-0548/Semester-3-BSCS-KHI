#include <iostream>
#include <string>
using namespace std;

class Student {
public:
    string name;
    int score;
    Student* next;
    
    Student(string n, int s) : name(n), score(s), next(nullptr) {}
};

class StudentList {
private:
    Student* head;

public:
    StudentList() : head(nullptr) {}

    // Function to add a student record to the list
    void addStudent(string name, int score) {
        Student* newStudent = new Student(name, score);
        if (!head) {
            head = newStudent;
        } else {
            Student* temp = head;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = newStudent;
        }
    }

    // Function to convert the linked list to an array of scores
    int* toArray(int& n) {
        Student* temp = head;
        n = 0;
        while (temp) {
            n++;
            temp = temp->next;
        }
        int* arr = new int[n];
        temp = head;
        for (int i = 0; i < n; i++) {
            arr[i] = temp->score;
            temp = temp->next;
        }
        return arr;
    }

    // Function to update the list from an array of sorted scores
    void updateList(int* sortedScores, int n) {
        Student* temp = head;
        for (int i = 0; i < n; i++) {
            temp->score = sortedScores[i];
            temp = temp->next;
        }
    }

    // Function to display the student list
    void display() {
        Student* temp = head;
        while (temp) {
            cout << temp->name << ": " << temp->score << endl;
            temp = temp->next;
        }
    }
};

// Counting sort function for radix sort
void counting_sort(int* arr, int n, int exp) {
    int output[n];
    int count[10] = {0};

    // Count the occurrences of digits
    for (int i = 0; i < n; i++) {
        int digit = (arr[i] / exp) % 10;
        count[digit]++;
    }

    // Modify the count array
    for (int i = 1; i < 10; i++) {
        count[i] += count[i - 1];
    }

    // Place the elements in sorted order in the output array
    for (int i = n - 1; i >= 0; i--) {
        int digit = (arr[i] / exp) % 10;
        output[count[digit] - 1] = arr[i];
        count[digit]--;
    }

    // Copy the sorted numbers back to arr[]
    for (int i = 0; i < n; i++) {
        arr[i] = output[i];
    }
}

// Radix sort function
void radix_sort(int* arr, int n) {
    int max = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }

    // Use counting sort for each digit place
    for (int exp = 1; max / exp > 0; exp *= 10) {
        counting_sort(arr, n, exp);
    }
}

int main() {
    // Create a linked list of student records
    StudentList students;
    students.addStudent("Alice", 89);
    students.addStudent("Bob", 75);
    students.addStudent("Charlie", 92);
    students.addStudent("David", 60);
    students.addStudent("Eve", 77);

    cout << "Before sorting:\n";
    students.display();

    // Convert the linked list to an array of scores
    int n;
    int* scores = students.toArray(n);

    // Sort the scores using radix sort
    radix_sort(scores, n);

    // Update the linked list with sorted scores
    students.updateList(scores, n);

    cout << "\nAfter sorting by score:\n";
    students.display();

    // Free the dynamically allocated array
    delete[] scores;

    return 0;
}
