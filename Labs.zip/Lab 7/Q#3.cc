#include <iostream>
#include <string>
using namespace std;
class Product{
    public:
    string name,descr;
    bool avail;
    float price;
    Product(string n,string d,bool a,float p):name(n),descr(d),avail(a),price(p){

    }
    Product(){}
   
};
 void display(Product *products){
        for(int i=0;i<3;i++){
            cout<<products[i].name<<" "<<products[i].price<<endl;
        }
    }
int  paritition(Product *arr,int low,int high){
    float pivot= arr[low].price;
    int i=low+1;
    int j=high;
    while(i<=j){
        while(i<=high &&arr[i].price<=pivot){
            i++;
        }
        while(j>=low &&arr[j].price>pivot){
            j--;
        }
        if(i<j)
        swap(arr[j],arr[i]);

    }
    swap(arr[low],arr[j]);
    return j;
}
void quick_sort(Product *arr,int low ,int high){
    if(low<high){
        int piv=paritition(arr,low,high);
        quick_sort(arr,low,piv-1);
        quick_sort(arr,piv+1,high);

    }
}
int main(){
    Product *producst= new Product[3];
    producst[0]=Product("apple","fruit",true,34.5);
    producst[1]=Product("banana","fruit",true,12.5);
    producst[2]=Product("anaar","fruit",true,500.5);
    quick_sort(producst,0,2);
    display(producst);
}