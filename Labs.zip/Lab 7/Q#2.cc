#include <iostream>
#include <string>
using namespace std;
class Runner{
        public:
    string name;
    int finish_time;
    Runner(){}
    Runner(string s,int n):name(s),finish_time(n){}

};
void merge(Runner *arr,int left,int mid,int right){
   int left_size= mid+1-left;
    int right_size= right-mid;
    Runner *left_arr = new Runner[left_size];
    Runner *right_arr = new Runner[right_size];

    for(int i=0;i<left_size;i++){
        left_arr[i]= arr[left+i];
    }
      for(int i=0;i<right_size;i++){
        right_arr[i]= arr[mid+1+i];
    }
        int i=0, j=0, k=left;
    while(i<left_size && j<right_size){
        if(left_arr[i].finish_time<=right_arr[j].finish_time)
                arr[k++]=left_arr[i++];
        else arr[k++]=right_arr[j++];
    }
    while(i<left_size){
        arr[k++]=left_arr[i++];
    }
    while(j<right_size){
        arr[k++]=right_arr[j++];
    }
     delete[] left_arr;
    delete[] right_arr;
}
void merge_sort(Runner *arr, int left,int right){
    if(left<right){
        int mid= left+(right-left)/2;
        merge_sort(arr,left,mid);
        merge_sort(arr,mid+1,right);
        merge(arr,left,mid,right);
    }
}
int main(){
    // Create an array of Runner objects
    Runner *arr = new Runner[5];
    
    // Initialize the array with sample runner names and finish times
    arr[0] = Runner("Alice", 300);
    arr[1] = Runner("Bob", 200);
    arr[2] = Runner("Charlie", 250);
    arr[3] = Runner("Diana", 180);
    arr[4] = Runner("Eve", 220);

    // Print the array before sorting
    cout << "Before sorting:\n";
    for (int i = 0; i < 5; i++) {
        cout << arr[i].name << " finished in " << arr[i].finish_time << " seconds\n";
    }

    // Call merge_sort to sort the runners based on their finish times
    merge_sort(arr, 0, 4);

    // Print the array after sorting
    cout << "\nAfter sorting by finish time:\n";
    for (int i = 0; i < 5; i++) {
        cout << arr[i].name << " finished in " << arr[i].finish_time << " seconds\n";
    }

    // Free the allocated memory
    delete[] arr;

    return 0;
}
