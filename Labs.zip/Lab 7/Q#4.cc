#include <iostream>
#include <string>
#include <iostream>
#include <string>
using namespace std;
int comparisions=0;
int partition(int *arr, int low,int high){
    int pivot= arr[low];// 1st element
    int i=low+1;
    int j= high;

    while(i<=j){
     // Increment i until you find an element greater than the pivot
    while(i<=high && arr[i]<=pivot){
        i++;
        comparisions++;
    }
      // Decrement until you find an element less than the pivot
    while(j>=low && arr[j]>pivot){
        j--;
        comparisions++;
    }
    // If there is an element on the left that is greater than the pivot
        // and an element on the right that is less than the pivot, swap them
        if (i < j) 
            swap(arr[i], arr[j]);
    }
// Place the pivot element in the correct position
    swap(arr[low], arr[j]);
    return j; // Return the partition index
}
void quick_sort(int *arr,int low,int high){
    if(low<high){
        int piv= partition(arr,low,high);
        quick_sort(arr,low,piv);
        quick_sort(arr,piv+1,high);
    }
}
// Function to print the array
void printArray(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main() {
    int arr[] =  {10, 1, 2, 3, 4, 5, 6};// Example array
    int n = sizeof(arr) / sizeof(arr[0]); // Calculate the number of elements

    cout << "Original array: ";
    printArray(arr, n); // Print original array

    quick_sort(arr, 0, n - 1); // Perform Quick Sort

    cout << "Sorted array: ";
    printArray(arr, n); // Print sorted array
    cout<<comparisions;

    return 0;
}