#include <iostream>
#include <string>
using namespace std;
class BookNode{
    public:
    int isbn;
    BookNode*left,*right;
    BookNode(int i):isbn(i),left(nullptr),right(nullptr){}
};
class Binary_Search_Library{
    BookNode* root;
    void inorder_traversal(BookNode *node){
        if(!node)
            return;
        inorder_traversal(node->left);
        cout<<node->isbn<<" ";
        inorder_traversal(node->right);
    }
    void preorder_traversal(BookNode* node){
        if(!node)
            return;
        cout<<node->isbn<<" ";
        preorder_traversal(node->left);
        preorder_traversal(node->right);
    }
    void postorder_traversal(BookNode* node){
        if(!node)
            return;
        postorder_traversal(node->left);
        postorder_traversal(node->right);
        cout<<node->isbn<<" ";
    }
     BookNode* insert_node(BookNode* node,int key){
        if(!node)
            return new BookNode(key);
        if(key>node->isbn)
        node->right=insert_node(node->right,key);
        else
        node->left=insert_node(node->left,key);
        return node;
    }
    public:
    Binary_Search_Library():root(nullptr){}
    void insert(int key){
        root=insert_node(root,key);
    }
   
    void inorder_print(){
        cout<<"Inorder traversal: ";
        inorder_traversal(root);
        cout<<endl;
    }
    
    void postorder_print(){
        cout<<"Postorder traversal: ";
        postorder_traversal(root);
         cout<<endl;
    }
    void preorder_print(){
        cout<<"Preorder traversal: ";
        preorder_traversal(root);
         cout<<endl;
    }
};
int main(){
    Binary_Search_Library library;
    library.insert(4);
    library.insert(2);
    library.insert(5);
    library.insert(1);
    library.insert(3);
    library.insert(6);
    library.inorder_print();
    library.preorder_print();
    library.postorder_print();
    
}