#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Product {
public:
    int id;
    int stock;
    Product *left;
    Product *right;

    Product(int i, int s) : id(i), stock(s), left(nullptr), right(nullptr) {}
};

class BST_Product {
    Product *root;

public:
    BST_Product() : root(nullptr) {}  // Initialize root to nullptr

    ~BST_Product() {  // Destructor to free memory
        clear(root);
    }

    void clear(Product* node) {
        if (node) {
            clear(node->left);
            clear(node->right);
            delete node;
        }
    }

    void insert(int i, int s) {
        Product *new_node = new Product(i, s);
        if (!root) {
            root = new_node;
            return;
        }

        Product *temp = root;
        Product *parent = nullptr;

        while (true) {
            parent = temp;  // Keep track of the parent

            if (temp->stock == new_node->stock) {
                cout << "Can't add the same value.\n";
                delete new_node;  // Free the memory
                return;
            }

            if (new_node->stock < temp->stock) {
                temp = temp->left;
                if (!temp) {
                    parent->left = new_node;  // Insert as left child
                    return;
                }
            } else {
                temp = temp->right;
                if (!temp) {
                    parent->right = new_node;  // Insert as right child
                    return;
                }
            }
        }
    }

    Product *Find_max_stock() {
        return find_max_helper(root);
    }

    Product *find_max_helper(Product *node) {
        if (node == nullptr)
            return nullptr;
        while (node->right != nullptr) {
            node = node->right;
        }
        return node;
    }

    Product *search_by_id(int i) {
        return search_helper(root, i);
    }

    Product *search_helper(Product *node, int i) {
        if (node == nullptr || node->id == i)
            return node;
        if (i < node->id)
            return search_helper(node->left, i);
        else
            return search_helper(node->right, i);
    }

    void display_product(Product *p) {
        if (p) {
            cout << "ID: " << p->id << " Stock: " << p->stock << endl;
        } else {
            cout << "Product not found.\n";
        }
    }

    void update_product(int curr, int newval) {
        vector<Product *> products;
        store_in_array(root, products);
        for (Product* p : products) {
            if (p->stock == curr) {
                p->stock = newval;  // Corrected assignment
                cout << "Updated stock.\n";
                return;
            }
        }
        cout << "Stock not found.\n";
    }

    void store_in_array(Product *node, vector<Product *> &products) {
        if (node != nullptr) {
            store_in_array(node->left, products);
            products.push_back(node);
            store_in_array(node->right, products);
        }
    }
};

int main() {
    BST_Product bst;

    // Inserting products into the binary search tree
    bst.insert(1, 50);
    bst.insert(2, 30);
    bst.insert(3, 70);
    bst.insert(4, 20);
    bst.insert(5, 40);
    bst.insert(6, 60);
    bst.insert(7, 80);

    // Searching for a product by ID
    int searchID = 3;
    Product *foundProduct = bst.search_by_id(searchID);
    if (foundProduct) {
        cout << "Product found: ";
        bst.display_product(foundProduct);
    } else {
        cout << "Product with ID " << searchID << " not found.\n";
    }

    // Finding the product with the maximum stock
    Product *maxStockProduct = bst.Find_max_stock();
    if (maxStockProduct) {
        cout << "Product with maximum stock: ";
        bst.display_product(maxStockProduct);
    } else {
        cout << "No products in the inventory.\n";
    }

    // Updating a product's stock
    int currentStock = 30;
    int newStock = 35;
    bst.update_product(currentStock, newStock);

    // Displaying the updated product
    foundProduct = bst.search_by_id(2);
    if (foundProduct) {
        cout << "Updated product: ";
        bst.display_product(foundProduct);
    } else {
        cout << "Product with ID 2 not found.\n";
    }

    return 0;
}
