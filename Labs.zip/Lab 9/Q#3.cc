#include <iostream>
#include <string>
#include <stack>
using namespace std;
class TreeNode {
public:
    int value;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) : value(val), left(nullptr), right(nullptr) {}
};
class BinarySearchTree{
    TreeNode *root;
       TreeNode* insertNode(TreeNode* node, int val) {
        if (!node) return new TreeNode(val);
        if (val < node->value) {
            node->left = insertNode(node->left, val);
        } else {
            node->right = insertNode(node->right, val);
        }
        return node;
    }
    public:
    BinarySearchTree():root(nullptr){}
    void insert(int val) {
        root = insertNode(root, val);
    }
    // left, right and then parent
    
    void post_order_traversal(){
        if(!root)
            return;
        TreeNode*curr= root;
        stack<TreeNode*>s;
        TreeNode* visited= nullptr;
        while(!s.empty()||curr){
            if(curr){
                s.push(curr);
                curr=curr->left;
            }
            else{
                TreeNode* peek=s.top();
                if(peek->right && visited!=peek->right)
                    curr=peek->right;
                else{
                    cout<<peek->value<<" ";
                    visited=s.top();
                    s.pop();
                }
            }
        }
        cout<<endl;
        
    }
    void inorder_traversal(){
        if(!root)
            return;
        TreeNode *curr=root;
        stack<TreeNode*>s;
        while(!s.empty()||curr){
            if(curr){
                s.push(curr);
                curr=curr->left;
            }
            else{
                curr= s.top();
                s.pop();
                cout<<curr->value<<" ";
                curr=curr->right;
            }
        }
        cout<<endl;
    }
    void preorder_traversal(){
         if(!root)
            return;
        TreeNode *curr=root;
        stack<TreeNode*>s;
        while(!s.empty()||curr){
            if(curr){
                cout<<curr->value<<" ";
                s.push(curr);
                curr=curr->left;
            }
            else{
                curr=s.top();
                s.pop();
                curr=curr->right;
            }
        }
        cout<<endl;
    }
};
int main(){
    BinarySearchTree bst;
    bst.insert(4);
    bst.insert(2);
    bst.insert(5);
    bst.insert(1);
    bst.insert(3);
    bst.insert(6);
    bst.inorder_traversal();
   
    bst.preorder_traversal();
     bst.post_order_traversal();

    
}