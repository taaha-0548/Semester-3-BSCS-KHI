#include <iostream>
#include <string>
using namespace std;
void heapify_down(int heap[],int n,int index){
    int largest=index;
    int left=2*index+1;
    int right= 2*index+2;
    if(left<n && heap[left]>heap[largest])
        largest=left;
    if(right<n && heap[right]>heap[largest])
        largest=right;
    if(largest!=index){
        swap(heap[largest],heap[index]);
        heapify_down(heap,n,largest);
    }
}
void remove_root(int heap[],int &n){
    heap[0]=heap[n-1];
    //first replace the root with last element.
    n--;
    heapify_down(heap,n,0);

}
void display(int heap[],int n){
    for(int i=0;i<n;i++){
        cout<<heap[i]<<" ";
    }
    cout<<endl;
}
int main(){
    int heap[]={50,30,40,10,20,35};
    int s=6;
    display(heap,s);
    remove_root(heap,s);
    display(heap,s);
}