#include <iostream>
using namespace std;
void max_heapify(int arr[],int n,int i){
    int largest=i;
    int left=2*i+1;
    int right=2*i+2;
    if(left<n && arr[left]>arr[largest])
        largest=left;
    if(right<n && arr[right]>arr[largest])
        largest=right;
    if(largest!=i){
        swap(arr[i],arr[largest]);
        max_heapify(arr,n,largest);
    }
}
void min_heapify(int arr[],int n,int i){
    int smallest=i;
    int left=2*i+1;
    int right=2*i+2;
    if(left<n && arr[left]<arr[smallest])
        smallest= left;
    if(right<n &&arr[right]<arr[smallest])
        smallest =right;
    if(smallest!=i){
        swap(arr[i],arr[smallest]);
        min_heapify(arr,n,smallest);
    }
}
void build_min_heap(int arr[],int n){
    for(int i=n/2-1;i>=0;i--){
        min_heapify(arr,n,i);
    }
}
void build_max_heap(int arr[],int n){
    for(int i=n/2-1;i>=0;i--){
        max_heapify(arr,n,i);

    }
}
void delete_from_max_heap(int arr[],int &size,int value){
    if(size<=0){
        cout<<"Array is empty.\n"<<endl;
        return;
    }
    int index=-1;
    for(int i=0;i<size;i++){
        if(arr[i]==value){
            index=i;
            break;
        }
    }
    if(index==-1){
        cout<<"Value not found in min-heap\n";
        return;
    }

    // replacing the element with last element.
    arr[index]=arr[size-1];
    size--;
    //heapify down to restore the max_heap property
    max_heapify(arr,size,index);
}
void delete_from_min_heap(int arr[],int &size,int value){
     if(size<=0){
        cout<<"Array is empty.\n"<<endl;
        return;
    }
    int index=-1;
    for(int i=0;i<size;i++){
        if(arr[i]==value){
            index=i;
            break;
        }
    }
    if(index==-1){
        cout<<"Value not found in min-heap\n";
        return;
    }
    // replacing the value with last element.
    arr[index]=arr[size-1];
    size--;
    min_heapify(arr,size,index);
}

void print_arr(int arr[],int n){
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";

    }
    cout<<endl;
}
void max_heap_sort(int arr[],int n){
    for(int i=n-1;i>0;i--){
        swap(arr[0],arr[i]);
        max_heapify(arr,i,0);
    }
}
int main(){
    int min[]={25, 30, 35, 11, 15, 19, 18, 55, 78, 36};
    int max[]={25, 30, 35, 11, 15, 19, 18, 55, 78, 36};
    int min_size = sizeof(min) / sizeof(min[0]);
    int max_size= sizeof(min) / sizeof(min[0]);
    build_max_heap(max,max_size);
    cout<<"Max-heap: ";
    print_arr(max,max_size);

    delete_from_max_heap(max,max_size,55);
    cout<<"Max-heap after deleting 55:\n";
    print_arr(max,max_size);
    
    
    build_min_heap(min,min_size);
    cout<<"Min-heap: ";
    print_arr(min,min_size);
    cout<<"Min-heap after deleting 18:\n";
    delete_from_min_heap(min,min_size,18);
    print_arr(min,min_size);

    max_heap_sort(max,max_size);
    cout<<"Now sorting the max heap:\n";
    print_arr(max,max_size);
}