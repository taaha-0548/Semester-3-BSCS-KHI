#include <iostream>
using namespace std;
void heapify_up(int arr[],int index){
    while(index>0){
        int parent=(index-1)/2;
        if(arr[parent]>arr[index]){
            swap(arr[parent],arr[index]);
            index=parent;
        }
        else break;
    }
}
void add_element(int heap[],int &size,int new_element){
    if(size>=10){ // considering 10 to be the max capacity.
        cout<<"Heap is full.\n";
        return;
    }
    heap[size]=new_element;
    size++;
    heapify_up(heap,size-1);
}
void display(int arr[],int n){
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}
int main(){
    int heap[10]={1,3,4,5};
    int curr_size=4;
    display(heap,curr_size);
    int new_element=2;
    add_element(heap,curr_size,new_element);
    display(heap,curr_size);
}