#include <iostream>
#include <string>
using namespace std;
void Display_GPAs(){
    int department=4;
    string departments[4]= {"SE","AI","CS","DS"};
    int courses[4]={3,4,2,1};
    float *Gpas[department];

    for(int i=0;i<department;i++){
        Gpas[i]= new float [courses[i]];
        for(int j=0;j<courses[i];j++){
            cout<<"Enter GPA for Course# "<<j+1<<" for "<<departments[i]<<": "<<endl;
            cin>>Gpas[i][j];
    }
}
    cout<<"GPAs for each department's core courses:\n";
    for(int i=0;i<department;i++){
        cout<<departments[i]<<": "<<endl;
        for(int j=0;j<courses[i];j++){
            cout<<"Course#"<<j+1<<": "<<Gpas[i][j]<<endl;
        }
        cout<<endl;
    }
    for (int i = 0; i<department; i++) {
        delete[] Gpas[i];
    }
}
int main(){
    Display_GPAs();
    return 0;
}