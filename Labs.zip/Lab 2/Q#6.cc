#include <iostream>
#include <string>
using namespace std;

void manage_courses() {
    string student_id[5];
    int no_of_courses[5];
  
    int **course_info = new int*[5];
    for (int i = 0; i < 5; i++) {
        cout << "Enter student-id for " << i + 1 << "th student: ";
        cin.ignore();  // Ignore the newline character left by the previous input
        getline(cin, student_id[i]);
       
        cout << "Enter no. of courses for student: ";
        cin >> no_of_courses[i];

        course_info[i] = new int[no_of_courses[i]];
        for (int j = 0; j < no_of_courses[i]; j++) {
            cout << "Enter marks for Course#" << j + 1 << ": ";
            cin >> course_info[i][j];
        }
    }

    // Display the course information
    for (int i = 0; i < 5; i++) {
        cout << "Student id: " << student_id[i] << endl;
        cout << "Number of courses: " << no_of_courses[i] << endl;
        for (int j = 0; j < no_of_courses[i]; j++) {
            cout << course_info[i][j] << " ";
        }
        cout << endl;
    }

    // Deallocating memory
    for (int i = 0; i < 5; i++) {
        delete[] course_info[i];
    }
    delete[] course_info;
}

int main() {
    manage_courses();
    return 0;
}
