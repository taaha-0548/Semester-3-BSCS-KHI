#include <iostream>
using namespace std;
class FruitShopInventory{
    int **fruits;
    int no_of_fruits;
    int cols;// for data.
    bool safe_array_checker(int row )  {
        return row >= 0 && row < no_of_fruits;}
    public:
    FruitShopInventory(int n,int quantity,int price):no_of_fruits(n),cols(2){
        fruits= new int*[no_of_fruits]; 
        for(int i=0;i<no_of_fruits;i++){
            fruits[i]= new int[2];// quantity & price.
            fruits[i][0]=quantity;
            fruits[i][1]=price;
        }
    }
    FruitShopInventory(const FruitShopInventory &other):no_of_fruits(other.no_of_fruits),cols(2){
        fruits= new int*[no_of_fruits];
        for(int i=0;i<no_of_fruits;i++){
            fruits[i]= new int[cols];
            for(int j=0;j<cols;j++){
                fruits[i][j]=other.fruits[i][j];
            }
        }
    }
    ~FruitShopInventory(){
        for(int i=0;i<no_of_fruits;i++){
            delete[]fruits[i];
        }
        delete[] fruits;
    }
    FruitShopInventory &operator=(const FruitShopInventory &other){
        if(this==&other)
            return *this;
        for(int i=0;i<no_of_fruits;i++){
            delete[] fruits[i];
        }
        delete []fruits;
        no_of_fruits=other.no_of_fruits;
        cols=other.cols;
        fruits= new int*[no_of_fruits];
        for(int i=0;i<no_of_fruits;i++){
            fruits[i]= new int[2];// quantity & price.
            for(int j=0;j<cols;j++){
                fruits[i][j]=other.fruits[i][j];
            }
        }
        return *this;
    }
    void set_fruit_details(int index,int quantity,int price){
            if(!safe_array_checker(index))
                return;
            fruits[index][0]=quantity;
            fruits[index][1]=price;
    }
     void displayInventory() const {
        for (int i = 0; i < no_of_fruits; i++) {
            cout << "Fruit " << i + 1 << " - Quantity: " << fruits[i][0] << ", Price: " << fruits[i][1] << endl;
        }
        cout<<endl;
    }
};
int main(){
    FruitShopInventory one(3,100,1000);
    FruitShopInventory two(one);
    FruitShopInventory three=one;
    one.displayInventory();
    one.set_fruit_details(2,32,500);
    one.displayInventory();
}