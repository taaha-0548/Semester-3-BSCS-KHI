#include <iostream>
#include <string>
using namespace std;
class StudentFeeManager{
    int *fee;
    int no_of_students;
    bool safe_array_checker(int index){
        return index>=0 && index<no_of_students;

    }
    public:
    StudentFeeManager(int initial_fee,int n):no_of_students(n){
        fee= new int[no_of_students];
        for(int i=0;i<no_of_students;i++){
            fee[i]=initial_fee;
        }
    }
    StudentFeeManager(const StudentFeeManager &other){
        no_of_students=other.no_of_students;
          fee= new int[no_of_students];
        for(int i=0;i<no_of_students;i++){
            fee[i]=other.fee[i];
        }
    }
    ~StudentFeeManager(){
        delete[]fee;
    }
    StudentFeeManager &operator=(const StudentFeeManager&other){
        if(this==&other)
            return *this;
            delete[]fee;
            no_of_students=other.no_of_students;
          fee= new int[no_of_students];
        for(int i=0;i<no_of_students;i++){
            fee[i]=other.fee[i];
        }
        return *this;
    }
    void set_fee(int index,int new_fee){
        if(!safe_array_checker(index))
            return;
        fee[index]=new_fee;
    }
    int get_fee(int index){
        if(!safe_array_checker(index))
            return -1;
        return fee[index];
    }
    void display_fees(){
        for(int i=0;i<no_of_students;i++){
            cout<<fee[i]<<" ";
        }
        cout<<endl;
    }
};
int main(){
    StudentFeeManager manager1(1000,3);
    manager1.display_fees();
    StudentFeeManager manager2=manager1;
    manager1.set_fee(1,900);
    manager1.display_fees();
    
}