#include <iostream>
#include <string>
using namespace std;
class ProductStockManager{
    int *stock;
    int no_of_products;
    bool safe_array_checker(int index){
        return index>=0 && index<no_of_products;

    }
    public:
    ProductStockManager(int initial,int n):no_of_products(n){
        stock= new int[no_of_products];
        for(int i=0;i<no_of_products;i++){
            stock[i]=initial;
        }
    }
    ProductStockManager(const ProductStockManager &other):no_of_products(other.no_of_products){
       stock= new int[no_of_products];
       for(int i=0;i<no_of_products;i++){
            stock[i]=other.stock[i];
       }
    }
    ~ProductStockManager(){
        delete[]stock;
    }
     ProductStockManager &operator=(const ProductStockManager&other){
        if(this==&other)
            return *this;
            delete[]stock;
            no_of_products=other.no_of_products;
          stock= new int[no_of_products];
        for(int i=0;i<no_of_products;i++){
            stock[i]=other.stock[i];
        }
        return *this;
    }
    void set_stock(int index,int newstock){
        if(!safe_array_checker(index))
            return;
        stock[index]=newstock;
    }
    int get_stock(int index){
        if(!safe_array_checker(index))
            return -1;
        return stock[index];
    }
    void display_stocks(){
        for(int i=0;i<no_of_products;i++){
            cout<<stock[i]<<" ";
        }
        cout<<endl;
    }
};
int main(){
    ProductStockManager p1(100,3);
    p1.display_stocks();
    ProductStockManager p2(p1);
    ProductStockManager p3=p1;
    p1.set_stock(2,200);
    p1.display_stocks();

}