#include <iostream>
#include <string>
using namespace std;
bool is_diagonal(int matrix[][100],int n){ // considering a square matrix
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(i!=j && matrix[i][j]!=0)
                return false;
        }
        
    }
    return true;
}
int main(){
     int arr[3][100] = { // considering 3*3 matrix
        {1, 0, 0},
        {0, 2, 0},
        {0, 0, 3}
    };
      if (is_diagonal(arr, 3)) {
        cout << "The matrix is diagonal." << endl;
    } else {
        cout << "The matrix is not diagonal." << endl;
    }
}