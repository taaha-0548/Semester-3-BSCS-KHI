#include <iostream>
#include <string>
using namespace std;
class Tasks{
    string description;
    string due_date; // considering dd/mm/yy format
    public:
    Tasks(string des="",string date=""):description(des),due_date(date){}
    void display_task(){
        cout<<"Task: "<<description<<"\nDue date: "<<due_date<<endl;
    }
};
void start_todo_list(){
    int capacity=1;
    int size=0;
    Tasks *tasks= new Tasks[capacity];
    while(true){
        int choice;
        cout<<"1. Add task\n2. Display all the tasks.\n3. Exit\n";
        cin>>choice;
           cin.ignore(); 
        if(choice==1){ 
            if(size==capacity){
                capacity*=2;// to grow the array by double when its full.
                Tasks *resize_tasks= new Tasks[capacity];
            for(int i=0;i<size;i++){
                resize_tasks[i]=tasks[i];
            }
            delete[] tasks;
            tasks=resize_tasks;
            }
        string des,date;
        cout<<"Enter task description:\n";
         getline(cin, des);
        cout<<"Enter due date:\n";
       getline(cin, date);
        tasks[size++]= Tasks(des,date);
          
        }
        else if(choice==2){
            cout<<"\nTotal no. tasks:"<<size<<endl;

            for(int i=0;i<size;i++){
                cout<<i+1<<": ";
                tasks[i].display_task();
                cout<<endl;
            }
        }
        else {cout<<"Exiting.\n"; // for 3rd or any other option. 
            break;
        }
       
    }
     delete[] tasks;
}

int main(){
    start_todo_list();
}
