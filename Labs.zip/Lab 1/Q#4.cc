#include <iostream>
#include <cstring>
using namespace std;
class Document{
    char* content;
    public:
    Document(const char* initial_data){
        content=new char[strlen(initial_data)+1];
        strcpy(content,initial_data);
    }
    ~Document() {
        delete[] content;
    }
    Document(const Document&other){
        content= new char[strlen(other.content)+1];
        strcpy(content,other.content);
    }
    Document &operator=(const Document &other){
        if(this== &other)
            return *this;
        delete[]content;
        content= new char[strlen(other.content)+1];
        strcpy(content,other.content);
        return *this;
    }
     void modify_content(const char* new_content) {
        delete[] content;
        content = new char[strlen(new_content) + 1];
        strcpy(content, new_content);
    }
    void display(){
        cout<<content<<endl;
    }
};
int main(){
    Document my_doc("Existing content\n");
    Document copy_of_mydoc(my_doc);
    Document another_mydoc=my_doc;
    // now modifying my_doc document.
    my_doc.display();
    copy_of_mydoc.display();
    another_mydoc.display();
    my_doc.modify_content("New content\n");
    my_doc.display();
}