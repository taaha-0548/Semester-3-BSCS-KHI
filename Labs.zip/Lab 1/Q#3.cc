#include <iostream>
#include <string>
using namespace std;
class Exam{
    string student_name;
    string exam_date;
    int score;
public:
    Exam(string name="",string date="",int s=0):student_name(name),exam_date(date),score(s){}
    Exam(const Exam& obj){
       this->student_name=obj.student_name;
       this->exam_date=obj.exam_date;
       this->score=obj.score;
   
    }
    Exam operator=(const Exam &obj){
    if(this!=&obj){
     this->student_name=obj.student_name;
       this->exam_date=obj.exam_date;
       this->score=obj.score;
     return obj;
    }
    else return *this;
    }
    void set_name(string name){
    student_name=name;
    }
    void set_date(string date){
    exam_date=date;
    }
    void set_score(int s){
    score=s;
    }
    int get_score(){
        return score;
    }
    string get_name(){
    return student_name;
    }
    string get_exam_date(){
    return exam_date;
    }
    ~Exam(){
    cout<<"Destructor called.\n";
}
    void display(){
    cout<<student_name<<endl;
    cout<<exam_date<<endl;
    cout<<score<<endl;
    } };
int main() {
  Exam myexam("Taaha","13-5-2024",99);
  Exam my2exam(myexam);
  myexam.display();
  my2exam.display();

    return 0;}
