#include <iostream>
#include <cstring>
using namespace std;
class Dictionary{
    char**words, ** definitions;
    int size, capacity;
    public:
    Dictionary(int cap):capacity(cap),size(0){
        words= new char*[capacity];
        definitions= new char*[capacity];
        
    }
    ~Dictionary(){
        for(int i=0;i<size;i++){
            delete[] words[i];
            delete[] definitions[i];
        }
        delete[] words;
        delete[] definitions;
    }
    Dictionary(const Dictionary&other):size(other.size),capacity(other.capacity){
        words=new char*[capacity];
        definitions=new char*[capacity];
        for(int i=0;i<size;i++){
            words[i]=new char[strlen(other.words[i])+1];
            strcpy(words[i],other.words[i]);
            definitions[i]= new char[strlen(other.definitions[i])+1];
            strcpy(definitions[i],other.definitions[i]);
        }
    }
     Dictionary& operator=(const Dictionary& other) {
        if (this == &other) {
            return *this; // Handle self-assignment
        }

        // Free existing memory
        for (int i = 0; i < size; i++) {
            delete[] words[i];
            delete[] definitions[i];
        }
        delete[] words;
        delete[] definitions;

        // Allocate new memory and copy the content
        size = other.size;
        capacity = other.capacity;
        words = new char*[capacity];
        definitions = new char*[capacity];
        for (int i = 0; i < size; i++) {
            words[i] = new char[strlen(other.words[i]) + 1];
            strcpy(words[i], other.words[i]);

            definitions[i] = new char[strlen(other.definitions[i]) + 1];
            strcpy(definitions[i], other.definitions[i]);
        }

        return *this;
    }
    void add_entry(const char*word,const char* definition){
        if(size==capacity){
            cout<<"Cant add more words.\n";
            return;
        }
        words[size]= new char[strlen(word)+1];
        strcpy(words[size],word);
        definitions[size]=new char[strlen(definition)+1];
        strcpy(definitions[size],definition);
        size++;
    }
    void print_dictionary(){
        for(int i=0;i<size;i++){
            cout<<words[i]<<":"<<definitions[i]<<endl;
        }
        cout<<endl;
    }

};
int main(){
    Dictionary dictionary(10);
    dictionary.add_entry("Hello","A greeting");
    dictionary.add_entry("Atom","Smallest unit that can be measured.");
   dictionary.print_dictionary();

   Dictionary copy_dictionary(dictionary);
   copy_dictionary.print_dictionary();
   
   Dictionary other_dictionary=dictionary;
   other_dictionary.print_dictionary();
   
   dictionary.add_entry("Data","Facts and statistics");
   dictionary.print_dictionary();

}