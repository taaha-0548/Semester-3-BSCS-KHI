#include <iostream>

using namespace std;
bool is_even(int n){ 
    return n%2==0;
}

void total_and_is_even_or_odd(int *arr,int size){
    cout<<"Total numbers in the array is:"<<size<<endl;
    for (int i=0; i <size; ++i) {
        cout << "Number " << arr[i] << " is " 
                  << (is_even(arr[i]) ? "even" : "odd") << endl;
    }
    
}
int main(){
    int size=0;
   
    cout<<"Enter total numbers to input:"<<endl;
    cin>>size;
     int *array = new int[size];
     cout<<"Enter "<<size<<" numbers for the array:\n";
    for(int i=0;i<size;i++){
        cin>>array[i];
    }
    total_and_is_even_or_odd(array,size);
}