#include <iostream>
using namespace std;
void sort(int *arr, int n){
    //using shell sort
    for(int gap=n/2;gap>0;gap/=2){
        for(int i=gap;i<n;i++){
            int temp= arr[i];
            int j;
            for(j=i;j>=gap&& arr[j-gap]>temp;j-=gap){
                arr[j]=arr[j-gap];
            }
            arr[j]=temp;
        }
    }
}
void printArray(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}
int  interpolation_search(int *arr, int n,int target){
    int high= n-1;
    int low=0;
    while(low<=high && target>=arr[low]&& target<=arr[high]){
        int pos=low+((target-arr[low])/(arr[high]-arr[low]))*(high-low);
        if(arr[pos]==target)
            return pos;
        if(arr[pos]<target)
            low=pos+1;
        else high=pos-1;
    }
    return -1;
}
int main() {
    // Example array
    int arr[] = { 34, 7, 23, 32, 5, 62, 32, 22 };
    int n = sizeof(arr) / sizeof(arr[0]);

    // Print original array
    cout << "Original array: ";
    printArray(arr, n);

    // Sort the array using Shell Sort
    sort(arr, n);

    // Print sorted array
    cout << "Sorted array: ";
    printArray(arr, n);

    // Perform Interpolation Search
    int target = 23;
    int index = interpolation_search(arr, n, target);

    // Output the result of the search
    if (index != -1) {
        cout << "Element " << target << " found at index " << index << endl;
    } else {
        cout << "Element " << target << " not found in the array" << endl;
    }

    return 0;
}
