#include <iostream>
#include <string>
using namespace std;

class swings {
public:
    int number;
    string name;

    swings(int n, string s) : number(n), name(s) {}
};

void Sort_swings(swings *arr, int n) {
    for (int i = 0; i < n - 1; i++) {
        int min_index = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j].number < arr[min_index].number) {
                min_index = j;  // Corrected index here
            }
        }
        if (min_index != i) {
            swings temp = arr[i];
            arr[i] = arr[min_index];
            arr[min_index] = temp;  // Corrected swapping logic
        }
    }
}

void print_swings(swings *arr, int n) {
    for (int i = 0; i < n; i++) {
        cout << "Swing Number: " << arr[i].number << ", Name: " << arr[i].name << endl;
    }
}

int main() {
    // Array of swings objects
    swings arr[] = {
        swings(5, "Swing A"),
        swings(3, "Swing B"),
        swings(4, "Swing C"),
        swings(1, "Swing D"),
        swings(2, "Swing E")
    };
    
    int n = sizeof(arr) / sizeof(arr[0]);  // Get number of elements in the array
    
    cout << "Before sorting:" << endl;
    print_swings(arr, n);  // Print original array
    
    Sort_swings(arr, n);  // Sort the swings based on their number
    
    cout << "\nAfter sorting:" << endl;
    print_swings(arr, n);  // Print sorted array
    
    return 0;
}
