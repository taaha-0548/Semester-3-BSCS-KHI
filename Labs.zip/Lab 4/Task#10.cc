#include <iostream>
#include <string>
using namespace std;
void sort_ascending_order(int *arr,int n){
    // using selection sort.
    for(int i=0;i<n-1;i++){
        int min=i;
        for(int j=i;j<n;j++){
            if(arr[j]<arr[min])
            min=j;
        }
        if(min!=i){ // if the minimum is different then swap
            int temp= arr[min];
            arr[min] =arr[i];
            arr[i]=temp;

        }
    }
}
int binary_search(int *arr,int n, int value){
    int left= 0;
    int right = n-1;
    int mid=0;
    while(left<=right){
        mid= left +(right-left)/2;
        if(arr[mid]==value)
            return mid;
        else if(value>arr[mid])
            left=mid+1;
        else right = mid-1;

    }
    return -1;
}
int main(){
    int arr[5]={1,4,2,3,5};
    int value_to_find=3;
    sort_ascending_order(arr,5);
    cout<<binary_search(arr,5,value_to_find);
}