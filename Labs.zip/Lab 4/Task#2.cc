#include <iostream>
#include <string>
using namespace std;
void sort_bottles(int *arr,int n){
    // using insertion sort.
    for(int i=1;i<n;i++){
        int j=i;
        while(j>0&& arr[j]>arr[j-1]){
            int temp= arr[j];
            arr[j]=arr[j-1];
            arr[j-1]=temp;
            j--;
        }

    }
}
int main() {
    int n;
    cout << "Enter the number of bottles: ";
    cin >> n;

    int* bottles = new int[n];  // Dynamic array to store bottle fill levels
    cout << "Enter the fill levels of the bottles:\n";
    for (int i = 0; i < n; i++) {
        cin >> bottles[i];
    }

    // Sort the bottles by their fill levels in descending order
    sort_bottles(bottles, n);

    cout << "Bottles sorted by fill levels in descending order:\n";
    for (int i = 0; i < n; i++) {
        cout << bottles[i] << " ";
    }
    cout << endl;

    delete[] bottles;  // Free dynamically allocated memory

    return 0;
}