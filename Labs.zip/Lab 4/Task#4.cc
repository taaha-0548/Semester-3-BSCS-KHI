#include <iostream>
using namespace std;

int iterations_bubble_sort(int* arr, int n) {
    int pass_count = 0;
    bool swapped;
    
    for (int i = 0; i < n - 1; i++) {
        swapped = false;
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) { //for ascending.
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                swapped = true;
            }
        }
        pass_count++;
        if (!swapped) {
            break;
        }
    }
    return pass_count;
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;

    int* arr = new int[n];  // Dynamic array to store elements
    cout << "Enter the elements:\n";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    // Sort the array in ascending order and count the number of passes
    int pass_count = iterations_bubble_sort(arr, n);

    cout << "Sorted array in ascending order:\n";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    cout << "Number of passes: " << pass_count << endl;

    delete[] arr;  // Free dynamically allocated memory

    return 0;
}
