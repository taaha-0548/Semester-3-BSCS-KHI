#include <iostream>
#include <ctime>  
#include <cstdlib> 
using namespace std;
void swap(int &a,int &b){
    int temp= a;
    a=b;
    b= temp;
}
int  bubble_sort(int *arr, int n){
    int comparisons=0;
    for(int i=0;i<n;i++){
        for(int j=0;j<n-i-1;j++){
            comparisons++;
            if(arr[j]>arr[j+1]) // for ascending order.
                swap(arr[j],arr[j+1]);
        }
    }
    return comparisons;
}
int  selection_sort(int *arr,int n){
    int comparisons=0;
    for(int i=0;i<n-1;i++){
        int min=i;
        for(int j=i;j<n;j++){
            comparisons++;
            if(arr[j]<arr[min])
                min=j;
        }
        if(min!=i){
            swap(arr[min],arr[i]);
        }
    }
   return comparisons;

}
int  insertion_sort(int *arr,int n){
    int comparisons=0;
    for(int i=1;i<n;i++){
        int j=i;
        while( j>0 &&arr[j-1]>arr[j] ){
            comparisons++;
            swap(arr[j-1],arr[j]);
            j--;
        }
        if (j > 0) comparisons++; // to account for missed comparison.

    }
    return comparisons;
}
int  shell_sort(int *arr, int n){
    int comparions=0;
    for(int gap=n/2;gap>0;gap/=2){
        for(int i=gap;i<n;i++){
            int temp= arr[i];
             int j;
             for(j=i;j>=gap&& arr[j-gap]>temp;j-=gap){
                comparions++;
                arr[j]=arr[j-gap];
             }
             arr[j]=temp;
             if(j>=gap)comparions++;// to account for missed comparison
        }
    }
    return comparions;
    
}
void print_array(int *arr, int n){
    for(int i=0; i<n; i++){
        cout << arr[i] << " ";
    }
    cout << endl;
}
void generate_random_array(int *arr, int n, int lower = 1, int upper = 100){
    for(int i = 0; i < n; i++){
        arr[i] = lower + rand() % (upper - lower + 1);
    }
}
int main() {
    srand(time(0));  // Seed random number generator

    int arr[100];  // Array large enough to hold 100 integers
    int n = 20;  // Start with 20 integers

    // Generate random array of 20 integers
    generate_random_array(arr, n);
    cout << "Original Array (20 integers): ";
    print_array(arr, n);

    // Bubble Sort
    int bubble_arr[100];
    copy(arr, arr+n, bubble_arr); // Copy original array
    int bubble_comparisons = bubble_sort(bubble_arr, n);
    cout << "\nBubble Sorted Array: ";
    print_array(bubble_arr, n);
    cout << "Bubble Sort Comparisons: " << bubble_comparisons << endl;

    // Selection Sort
    int selection_arr[100];
    copy(arr, arr+n, selection_arr); // Copy original array
    int selection_comparisons = selection_sort(selection_arr, n);
    cout << "\nSelection Sorted Array: ";
    print_array(selection_arr, n);
    cout << "Selection Sort Comparisons: " << selection_comparisons << endl;

    // Insertion Sort
    int insertion_arr[100];
    copy(arr, arr+n, insertion_arr); // Copy original array
    int insertion_comparisons = insertion_sort(insertion_arr, n);
    cout << "\nInsertion Sorted Array: ";
    print_array(insertion_arr, n);
    cout << "Insertion Sort Comparisons: " << insertion_comparisons << endl;

    // Shell Sort
    int shell_arr[100];
    copy(arr, arr+n, shell_arr); // Copy original array
    int shell_comparisons = shell_sort(shell_arr, n);
    cout << "\nShell Sorted Array: ";
    print_array(shell_arr, n);
    cout << "Shell Sort Comparisons: " << shell_comparisons << endl;

    // Extend the array size to 100 integers and repeat
    n = 100;
    generate_random_array(arr, n);
    cout << "\nOriginal Array (100 integers): ";
    print_array(arr, n);

    // Bubble Sort (100 integers)
    copy(arr, arr+n, bubble_arr); // Copy original array
    bubble_comparisons = bubble_sort(bubble_arr, n);
    cout << "\nBubble Sorted Array (100 integers): ";
    print_array(bubble_arr, n);
    cout << "Bubble Sort Comparisons (100 integers): " << bubble_comparisons << endl;

    // Selection Sort (100 integers)
    copy(arr, arr+n, selection_arr); // Copy original array
    selection_comparisons = selection_sort(selection_arr, n);
    cout << "\nSelection Sorted Array (100 integers): ";
    print_array(selection_arr, n);
    cout << "Selection Sort Comparisons (100 integers): " << selection_comparisons << endl;

    // Insertion Sort (100 integers)
    copy(arr, arr+n, insertion_arr); // Copy original array
    insertion_comparisons = insertion_sort(insertion_arr, n);
    cout << "\nInsertion Sorted Array (100 integers): ";
    print_array(insertion_arr, n);
    cout << "Insertion Sort Comparisons (100 integers): " << insertion_comparisons << endl;

    // Shell Sort (100 integers)
    copy(arr, arr+n, shell_arr); // Copy original array
    shell_comparisons = shell_sort(shell_arr, n);
    cout << "\nShell Sorted Array (100 integers): ";
    print_array(shell_arr, n);
    cout << "Shell Sort Comparisons (100 integers): " << shell_comparisons << endl;

    return 0;
}