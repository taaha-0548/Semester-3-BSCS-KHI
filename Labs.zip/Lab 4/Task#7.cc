#include <iostream>
using namespace std;
void swap(int &a,int &b){
    int temp=a;
    a=b;
    b=temp;
}
void sort_cards(int *arr,int n){
    //using comb sort
    const float shrink_factor=1.3;
    int gap=n;
    bool swapped=true;
    while(gap>1|| swapped){
        gap= gap/shrink_factor;
        if(gap<1) gap=1;
        swapped= false;
        for(int i=0;i+gap<n;i++){
            if(arr[i]>arr[i+gap]){
                swap(arr[i],arr[i+gap]);
                swapped=true;
            }
        }
    }
}
void print_arr(int *arr,int n){
    for(int i=0;i<n;i++){
       cout<<arr[i]<<" ";
    }
    cout<<endl;
}
int main(){
    int arr[5]={5,4,3,2,1};
    sort_cards(arr,5);
    print_arr(arr,5);
}