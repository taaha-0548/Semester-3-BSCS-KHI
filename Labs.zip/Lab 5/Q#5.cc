#include <iostream>
#include <string>
using namespace std;
void print_maze(int solution[5][5]){
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            cout<<solution[i][j]<<" ";
        }
        cout<<endl;
    }
}
bool isSafe(int maze[5][5],int x, int y){
    return (x>=0 && x<5&& y>=0 && y<5 &&maze[x][y]==1);
}
bool solve_maze(int maze[5][5],int x,int y, int solution[5][5]){
    // base condition.
     if (x == 4 && y == 4) {
        solution[x][y] = 1;
        return true;
    }
    if(isSafe(maze,x,y)){
        solution[x][y]=1;
   
    if(solve_maze(maze,x,y+1,solution))
        return true;
    if(solve_maze(maze,x+1,y,solution))
        return true;
    solution[x][y]=0;
    return false;
     }   
     return false;
}
bool path_find(int maze[5][5]){
    int solution[5][5]={ { 0, 0, 0, 0, 0 },
                           { 0, 0, 0, 0, 0 },
                           { 0, 0, 0, 0, 0 },
                           { 0, 0, 0, 0, 0 },
                           { 0, 0, 0, 0, 0 } };
   if (!solve_maze(maze, 0, 0, solution)) {
        cout << "No solution exists" << endl;
        return false;
    }

    print_maze(solution);
    return true;
}
int main(){
     int maze[5][5] = { { 1, 0, 0, 0, 0 },
                       { 1, 1, 1, 0, 0 },
                       { 0, 0, 1, 0, 0 },
                       { 0, 1, 1, 1, 0 },
                       { 0, 0, 0, 1, 1 } };

    path_find(maze);
    return 0;
}