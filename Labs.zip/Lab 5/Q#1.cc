#include <iostream>
#include <cstdlib>  
#include <ctime>    
#include <string>
using namespace std;
// function to generater numbers 
int generate_random_number(){
    srand(time(0));
    return rand()%100+1;
}
void  guess_number( int magic_number){
    int n=0;
    cout<<"Guess the magic number between 1 and 100:\n";
    cin>>n;

    if(n== magic_number){
        cout<<"You have guessed the correct number.\n";
        return;
    }
    if(n<magic_number){
        cout<<"Too low,its next player's turn now.\n";
    }
    else
    cout<<"Too high, its next player's turn now:\n";
    return guess_number(magic_number);
}
int main(){
    int magic= generate_random_number();
    guess_number(magic);

}