#include <iostream>
#include <string>
using namespace std;
class Stack{
    int *arr;
    int top;// index
    int capacity;
    public:
    Stack(int cap){
        arr= new int[cap];
        capacity =cap;
        top=-1;
    }
    ~Stack(){
        delete[] arr;

    }
    bool isFull(){
        return top== capacity-1;

    }
    bool isEmpty(){
        return top==-1;
    }
    int get_size(){
        return top+1;
    }
    // to insert the element int the insert.
    void push(int new_elment){
        if(isFull()){
            cout<<"Stack Overflow.\n";
            return;
        }
        arr[++top]=new_elment;
        cout<<"New element pushed: "<<new_elment<<".\n";
    }
    // function to remove the top element from the stack.
    int pop(){
        if(isEmpty()){
            cout<<"Stack Underflow.\n";
            return -1;
        }
        return arr[top--];

    }
    // function to return the top element of the stack.
    int peek(){
       if(isEmpty()){
        cout<<"Stack is empty.\n";
        return -1;
       } 
       return arr[top];
    }
};
int main() {
    // Create a stack of capacity 5
    Stack stack(5);

    // Push elements into the stack
    stack.push(10);
    stack.push(20);
    stack.push(30);
    stack.push(40);
    stack.push(50);

    // Trying to push into a full stack
    stack.push(60); // This should print "Stack Overflow."

    // Get the size of the stack
    cout << "Stack size: " << stack.get_size() << endl;

    // Peek at the top element
    cout << "Top element is: " << stack.peek() << endl;

    // Pop elements from the stack
    cout << "Popped element: " << stack.pop() << endl;
    cout << "Popped element: " << stack.pop() << endl;

    // Peek at the top element again
    cout << "Top element is: " << stack.peek() << endl;

    // Get the size of the stack after popping elements
    cout << "Stack size: " << stack.get_size() << endl;

    // Pop all elements to empty the stack
    cout << "Popped element: " << stack.pop() << endl;
    cout << "Popped element: " << stack.pop() << endl;
    cout << "Popped element: " << stack.pop() << endl;

    // Trying to pop from an empty stack
    cout << "Popped element: " << stack.pop() << endl; // This should print "Stack Underflow."

    return 0;
}
