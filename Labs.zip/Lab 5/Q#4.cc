#include <iostream>

int recursiveArraySum(int* arr[], int sizes[], int dim) {
    
    if (dim < 0) {
        return 0;
    }
    
 
    int rowSum = 0;
    for (int i = 0; i < sizes[dim]; i++) {
        rowSum += arr[dim][i];
    }

    return rowSum + recursiveArraySum(arr, sizes, dim - 1);
}

int main() {
    // Example jagged array
    int* arr[3]; // 3 rows
    int sizes[3] = {4, 3, 3}; // Row sizes

    // Allocating and initializing the jagged array
    arr[0] = new int[sizes[0]]{1, 2, 3, 4};
    arr[1] = new int[sizes[1]]{5, 6,7};
    arr[2] = new int[sizes[2]]{8, 9, 10};

    // Calculate the sum
    int totalSum = recursiveArraySum(arr, sizes, 2); // Start from the last row (dim = 2)
    std::cout << "Total sum of elements: " << totalSum << std::endl;

    // Clean up dynamically allocated memory
    for (int i = 0; i < 3; i++) {
        delete[] arr[i];
    }

    return 0;
}
