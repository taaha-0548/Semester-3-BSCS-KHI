#include <iostream>
#include <string>
using namespace std;
#include <iostream>
using namespace std;

class Node {
public:
    int value;
    Node* next;

    // Parameterized constructor
    Node(int value) {
        this->value = value;
        this->next = nullptr;
    }
};

class LinkedList {
public:
    Node* head;
    


    // Constructor
    LinkedList() {
        head = nullptr;
        
    }

    
    void Add_to_tail(int data) {
        Node* newnode = new Node(data);
        if (head == nullptr) {
            head = newnode;
        } else {
            Node* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }
            temp->next = newnode;
        }
       
        cout << data << " added at the end of the list.\n";
    } 
  

  
};
  bool search(Node *head,int key){ 
     if(!head)
        return false;
    bool found_in_next=search (head->next,key);


  return head->value == key || found_in_next;
  // non tail recursion 
      
       
    }
  

int main() {
    LinkedList list;

    // Adding nodes
    list.Add_to_tail(1);
    list.Add_to_tail(2);
    list.Add_to_tail(3);
    list.Add_to_tail(4);
    list.Add_to_tail(5);
    if(search(list.head,0))
        cout<<"found";
        else cout<<"not found.";
    

    return 0;
}
