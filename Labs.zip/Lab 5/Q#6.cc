#include <iostream>
using namespace std;
int  no_of_flags(int arr[4][4],int n){
    return n; // the maximum flags that can be placed wil always be n
    /*Its a very lite version of N-queen problem, normally the problem 
    is to tell the number of ways in which n queens are placed on a nxn board
    but here we only need to tell how many pieces(flages in this scenario) that can be place on a NxN board,
    which is always going to be N. In this case, it's 4*/
}
int main(){
    int arr[4][4];
    int n=4;
    cout<<"Max no. flags: "<<no_of_flags(arr,n);
}
