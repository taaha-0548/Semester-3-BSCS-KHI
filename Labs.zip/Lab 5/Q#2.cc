#include <iostream>
using namespace std;

class Node {
public:
    int value;
    Node* next;

    // Parameterized constructor
    Node(int value) {
        this->value = value;
        this->next = nullptr;
    }
};

class LinkedList {
public:
    Node* head;
    


    // Constructor
    LinkedList() {
        head = nullptr;
        
    }

    
    void Add_to_tail(int data) {
        Node* newnode = new Node(data);
        if (head == nullptr) {
            head = newnode;
        } else {
            Node* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }
            temp->next = newnode;
        }
       
        cout << data << " added at the end of the list.\n";
    }

  
};
  
    int getSize(Node*head ,int n=0) {
        
        if(head== nullptr)
            return n;
      
        return getSize(head->next,n+1);
       

    }

int main() {
    LinkedList list;

    // Adding nodes
    list.Add_to_tail(1);
    list.Add_to_tail(2);
    list.Add_to_tail(3);
    list.Add_to_tail(4);
    list.Add_to_tail(5);

    // Displaying the size of the list
    cout << "Final size of the list: " << getSize(list.head) << endl;

    return 0;
}
