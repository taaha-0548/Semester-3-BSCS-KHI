#include <iostream>
#include <climits>

// Definition for a binary tree node.
class TreeNode {
    public:
    int val;
    TreeNode *left;
    TreeNode *right;
    
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};
bool isValidBST(TreeNode* node, int min_val,int max_val){
    if(!node)
        return true;
    if(node->val<=min_val|| node->val>=max_val)
    return false;
    return isValidBST(node->left,min_val,node->val) && isValidBST(node->right,node->val,max_val);
}


TreeNode* createTree() {
    TreeNode* root = new TreeNode(8);
    root->left = new TreeNode(5);
    root->right = new TreeNode(10);
    root->right->left = new TreeNode(9);
    root->right->right = new TreeNode(11);
    
    return root;
}

int main() {
  
    TreeNode* root = createTree();
    
 
    if (isValidBST(root,-243,112)) {
        std::cout << "The tree is a valid Binary Search Tree (BST)." << std::endl;
    } else {
        std::cout << "The tree is NOT a valid Binary Search Tree (BST)." << std::endl;
    }

    

    return 0;
}
