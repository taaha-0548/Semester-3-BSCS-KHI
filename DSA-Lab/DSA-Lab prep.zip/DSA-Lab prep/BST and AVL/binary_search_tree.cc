#include <iostream>
using namespace std;
#include <queue>

// Class to represent a node in the binary tree
class TreeNode {
public:
    int data;
    TreeNode* left;
    TreeNode* right;

    // Constructor to initialize the node with a value
    TreeNode(int value) {
        data = value;
        left = nullptr;
        right = nullptr;
    }
};

// Class to represent the binary tree
class BinaryTree {
     int count_nodes(TreeNode* node){
        if(!node)
            return 0;
        return 1+count_nodes(node->left)+count_nodes(node->right);
    }
    int height(TreeNode *node){
        if(!node)
        return -1;
        return 1+ max(height(node->left),height(node->right));
    }
    int leaf_nodes(TreeNode* node){
        if(!node)
            return 0;
        if(!node->right && !node->left) return 1;
        return leaf_nodes(node->left)+leaf_nodes(node->right);
    }
    
    int sum_nodes(TreeNode* node){
        if(!node)
            return 0;
        return node->data+ sum_nodes(node->left)+sum_nodes(node->right);
    }
    // Helper function to insert a node recursively
    TreeNode* insertNode(TreeNode* node, int value) {
        if (node == nullptr) {
            return new TreeNode(value);
        }

        if (value < node->data) {
            node->left = insertNode(node->left, value);
        } else if (value > node->data) {  // Prevent duplicate values
            node->right = insertNode(node->right, value);
        }

        return node;
    }
    TreeNode *DeleteNode(TreeNode *root,int val){
        if(!root)
            return nullptr;
        if(val<root->data)
        root->left=DeleteNode(root->left,val);
        else if(val>root->data)
        root->right=DeleteNode(root->right,val);
        else{ // node to be deleted is found.
        
        // for 0 or 1 child:
        if(!root->left){
            TreeNode*temp=root->right;
            delete root;
            return temp;
        }
        else if(!root->right){
            TreeNode*temp=root->left;
            delete root;
            return temp;
        }
        else{ // if the node has two children.
            TreeNode *successor= find_min(root->right);
            root->data=successor->data;
            root->right= DeleteNode(root->right,successor->data);

        }
        return root;
        }
        
    }
    TreeNode *find_min(TreeNode *node){
        while(node && node->left){
            node=node->left;
        }
        return node;
    }
    TreeNode *find_max(TreeNode *node){
        while(node && node->right){
            node=node->right;
        }
        return node;
    }
    TreeNode *SearchNode(TreeNode *root,int val){
        if(!root)
            return nullptr;
        if(root->data==val)
            return root;
        if(val<root->data)
        return SearchNode(root->left,val);
        else return SearchNode(root->right,val);
    }
    // Helper function for inorder traversal
    void inorder(TreeNode* node) {
        if (node == nullptr) {
            return;
        }

        inorder(node->left);
        cout << node->data << " ";
        inorder(node->right);
    }
    
    // Helper function for preorder traversal
    void preorder(TreeNode* node) {
        if (node == nullptr) {
            return;
        }

        cout << node->data << " ";
        preorder(node->left);
        preorder(node->right);
    }
    bool is_balanced(TreeNode *node){
        if(!node)
            return true;
        int left_height = height(node->left);
    int right_height = height(node->right);

    return abs(left_height - right_height) <= 1 && is_balanced(node->left) && is_balanced(node->right);
    }
   
public:
    TreeNode* root;

    // Constructor to initialize the tree
    BinaryTree() {
        root = nullptr;
    }

    // Function to insert a new node in the binary tree
    void insert(int value) {
        root = insertNode(root, value);
    }


    // Inorder traversal: Left -> Root -> Right
    void inorderTraversal() {
        inorder(root);
        cout<<endl;
    }

    // Preorder traversal: Root -> Left -> Right
    void preorderTraversal() {
        preorder(root);
    }


    // Postorder traversal: Left -> Right -> Root
    void postorderTraversal() {
        postorder(root);
    }

    // Helper function for postorder traversal
    void postorder(TreeNode* node) {
        if (node == nullptr) {
            return;
        }

        postorder(node->left);
        postorder(node->right);
        cout << node->data << " ";
    }
   
    int total_nodes(){
        return  count_nodes(root);
    }
    int max_height(){
        return height(root);
    }
    int count_leafs(){
        return leaf_nodes(root);
    }
    
    int sum_of_all_nodes(){
        return sum_nodes(root);
    }
    bool check_if_balanced(){
        return is_balanced(root);
    }
   bool search(int val){
    return SearchNode(root,val);
   }
   void delete_node(int val){
    root=DeleteNode(root,val);
   }
    void Update_node(int old_val,int new_val){
        TreeNode *node = SearchNode(root,old_val);
        if(!node){
            cout<<"couldnt find the the node.\n";
            return;
        }
        root=DeleteNode(root,node->data);
        insert(new_val);

    }
};

int main() {
    BinaryTree tree;

    // Insert nodes into the binary tree
    tree.insert(50);
    tree.insert(30);
    tree.insert(40);
    tree.insert(20);

    tree.insert(70);
    tree.insert(60);
    tree.insert(80);
    tree.insert(90);
    tree.insert(100);
    tree.inorderTraversal();
    if(tree.search(100))
        cout<<"exists\n";
    else cout<<"doesnt exist";
    tree.delete_node(100);
     tree.inorderTraversal();
     if(tree.search(100))
        cout<<"exists";
    else cout<<"doesnt exist\n";
    tree.Update_node(60,100);
     tree.inorderTraversal();
    
    return 0;
}
