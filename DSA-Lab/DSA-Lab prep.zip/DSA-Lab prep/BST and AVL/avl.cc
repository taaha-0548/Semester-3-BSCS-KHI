#include <iostream>
#include <queue>
#include <algorithm>

using namespace std;

class TreeNode {
public:
    int data;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int value) : data(value), left(nullptr), right(nullptr) {}
};

class BinaryTree {
    int getHeight(TreeNode* node) {
        if (node == nullptr) {
            return -1;
        }
        return 1 + max(getHeight(node->left), getHeight(node->right));
    }

    int getBalanceFactor(TreeNode* node) {
        if (node == nullptr) {
            return 0;
        }
        int leftHeight = getHeight(node->left);
        int rightHeight = getHeight(node->right);
        return leftHeight - rightHeight;
    }

    // Left Rotation
    TreeNode* rotateLeft(TreeNode* x) {
        TreeNode* y = x->right;
        x->right = y->left;
        y->left = x;
        return y;
    }

    // Right Rotation
    TreeNode* rotateRight(TreeNode* x) {
        TreeNode* y = x->left;
        x->left = y->right;
        y->right = x;
        return y;
    }

    // Balance the node after insertion or deletion
    TreeNode* balance(TreeNode* node) {
        if (!node) return node;

        int balanceFactor = getBalanceFactor(node);

        // Left-Left Case
        if (balanceFactor > 1 && getBalanceFactor(node->left) >= 0) {
            return rotateRight(node);
        }

        // Right-Right Case
        if (balanceFactor < -1 && getBalanceFactor(node->right) <= 0) {
            return rotateLeft(node);
        }

        // Left-Right Case
        if (balanceFactor > 1 && getBalanceFactor(node->left) < 0) {
            node->left = rotateLeft(node->left);
            return rotateRight(node);
        }

        // Right-Left Case
        if (balanceFactor < -1 && getBalanceFactor(node->right) > 0) {
            node->right = rotateRight(node->right);
            return rotateLeft(node);
        }

        return node;
    }

    // Recursive insertion with balancing
    TreeNode* insertNode(TreeNode* node, int value) {
        if (!node) return new TreeNode(value);

        if (value < node->data) {
            node->left = insertNode(node->left, value);
        } else if (value > node->data) {
            node->right = insertNode(node->right, value);
        } else {
            return node;  // Duplicate values are not allowed
        }

        return balance(node);
    }

    // Find the node with the smallest value (used in deletion)
    TreeNode* findMin(TreeNode* node) {
        while (node->left) {
            node = node->left;
        }
        return node;
    }

    // Recursive deletion with balancing
    TreeNode* deleteNode(TreeNode* node, int value) {
        if (!node) return nullptr;

        if (value < node->data) {
            node->left = deleteNode(node->left, value);
        } else if (value > node->data) {
            node->right = deleteNode(node->right, value);
        } else {
            if (!node->left || !node->right) {
                TreeNode* temp = node->left ? node->left : node->right;
                delete node;
                return temp;
            } else {
                TreeNode* temp = findMin(node->right);
                node->data = temp->data;
                node->right = deleteNode(node->right, temp->data);
            }
        }

        return balance(node);
    }

    // Inorder traversal
    void inorder(TreeNode* node) const {
        if (!node) return;
        inorder(node->left);
        cout << node->data << " ";
        inorder(node->right);
    }

public:
    TreeNode* root;

    BinaryTree() : root(nullptr) {}

    // Insert a value into the AVL tree
    void insert(int value) {
        root = insertNode(root, value);
    }

    // Delete a value from the AVL tree
    void deleteValue(int value) {
        root = deleteNode(root, value);
    }

    // Inorder traversal
    void inorderTraversal() const {
        inorder(root);
        cout << endl;
    }
};

int main() {
    BinaryTree tree;
    tree.insert(50);
    tree.insert(30);
    tree.insert(40);
    tree.insert(20);
    tree.insert(70);
    tree.insert(60);
    tree.insert(80);

    cout << "Inorder traversal after inserts: ";
    tree.inorderTraversal();

    tree.deleteValue(50);
    cout << "Inorder traversal after deletion: ";
    tree.inorderTraversal();

    return 0;
}
