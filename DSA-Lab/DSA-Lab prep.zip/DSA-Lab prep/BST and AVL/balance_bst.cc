#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

/**
 * Definition for a binary tree node.
 */
struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};

// Function to perform inorder traversal and store nodes in sorted order
void inorder(TreeNode* root, vector<int>& arr) {
    if (!root) return;
    inorder(root->left, arr);
    arr.push_back(root->val);
    inorder(root->right, arr);
}

// Function to build a balanced BST from a sorted array
TreeNode* buildBalancedBST(vector<int>& nodes, int left, int right) {
    if (left > right) return nullptr;

    int mid = left + (right - left) / 2;
    TreeNode* root = new TreeNode(nodes[mid]);
    root->left = buildBalancedBST(nodes, left, mid - 1);
    root->right = buildBalancedBST(nodes, mid + 1, right);
    return root;
}

// Main function to balance a BST
TreeNode* balanceBST(TreeNode* root) {
    vector<int> sorted_arr;
    inorder(root, sorted_arr); // Get sorted list of values
    return buildBalancedBST(sorted_arr, 0, sorted_arr.size() - 1); // Build balanced BST
}

// Helper function to check if a tree is balanced
int checkHeight(TreeNode* node) {
    if (!node) return 0;
    
    int leftHeight = checkHeight(node->left);
    if (leftHeight == -1) return -1; // Left subtree is not balanced

    int rightHeight = checkHeight(node->right);
    if (rightHeight == -1) return -1; // Right subtree is not balanced

    if (abs(leftHeight - rightHeight) > 1) return -1; // Current node is not balanced

    return 1 + max(leftHeight, rightHeight);
}

// Wrapper function to check if tree is balanced
bool isBalanced(TreeNode* root) {
    return checkHeight(root) != -1;
}

// Helper function to print the tree in inorder
void printInorder(TreeNode* root) {
    if (!root) return;
    printInorder(root->left);
    cout << root->val << " ";
    printInorder(root->right);
}

int main() {
    TreeNode* root = new TreeNode(8);
    root->left = new TreeNode(5);
    root->right = new TreeNode(10);
    root->right->left = new TreeNode(9);
    root->right->right = new TreeNode(11);
    
    cout << "Inorder of original BST: ";
    printInorder(root);
    cout << endl;

    // Check if the original BST is balanced
    cout << "Is the original BST balanced? " << (isBalanced(root) ? "Yes" : "No") << endl;

    

    return 0;
}
