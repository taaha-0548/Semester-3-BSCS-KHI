#include <iostream>
#include <string>
using namespace std;
//making a binary search tree
class TreeNode{
    public:
    int data;
    TreeNode*left, *right;
    TreeNode(int d):data(d),left(nullptr),right(nullptr){}
};
class BST{
    TreeNode *root;
    TreeNode* insert(TreeNode* node,int val){
        if(node==nullptr)
            return new TreeNode(val);
        if(val<node->data)
        node->left=insert(node->left,val);
        else 
        node->right= insert(node->right,val);
        return node;
    }
     // delete node in a bst
    //1. if the node is leaf,then 0 child
            // else either 1 or 2 children nodes
    //2. if we delete the leaf node, no change in required in bst
    //3. if a node has a single child:
        // first connect the node's parent node to the node's only child node, then delete the node
        // which means the child node is connected to its grand parent node
    //4. if a node has 2 children nodes:
        // find the smallest in the right subtree,copy that nodes data to the current node
        // and remove that node
    TreeNode* delete_(TreeNode *node,int val){
            if (node==nullptr)
                return node;
            // find the value.
            if(val<node->data)
                node->left=delete_(node->left,val);
            else if(val>node->data)
            node->right=delete_(node->right,val);
            // if found the value: 

            else{
                
                //case 1:node has 1 or 0 child
                if(node->left==nullptr){
                    TreeNode *temp=node->right;
                    delete node;
                    return temp;

                }
                else if(node->right==nullptr){
                    TreeNode *temp=node->left;
                    delete node;
                    return temp;
                }
                //case 2: node has 2 children
                TreeNode* successor =find_min(node->right);
                node->data=successor->data;
                node->right=delete_(node->right,successor->data);      

            }
            
    }
        TreeNode * find_min(TreeNode *node){
            while(node &&node->left!=nullptr)
                node=node->left;
                return node;
        }
    
     void inorder_traversal(TreeNode *node){
        if(node==nullptr)
            return;
        inorder_traversal(node->left);
        cout<<node->data<<" ";
        inorder_traversal(node->right);
    }
    public:
    BST():root(nullptr){}
    void insert_value(int val){
        root=insert(root,val);
    }
    void inorder_print(){
        inorder_traversal(root);
    }
   
   void delete_value(int val){
    root= delete_(root,val);
   }
    
};
int main(){
    BST bst;
    bst.insert_value(4);
     bst.insert_value(2);
      bst.insert_value(3);
       bst.insert_value(6);
        bst.insert_value(5);
         bst.insert_value(7);
          bst.insert_value(1);
          bst.delete_value(4);
        bst.inorder_print();
}