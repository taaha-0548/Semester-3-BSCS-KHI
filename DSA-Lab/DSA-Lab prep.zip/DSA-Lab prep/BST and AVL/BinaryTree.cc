#include <iostream>
#include <string>
#include <queue>
#include <algorithm>
using namespace std;

class TreeNode {
public:
    int data;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) : data(val), left(nullptr), right(nullptr) {}
};

// Class to represent the binary tree
class BinaryTree {


    TreeNode* insertNode(int value) {
        if (!root) return new TreeNode(value);
        queue<TreeNode*> q;
        q.push(root);
        while (!q.empty()) {
            TreeNode* current = q.front();
            q.pop();
            if (!current->left) {
                current->left = new TreeNode(value);
                return root;
            } else {
                q.push(current->left);
            }
            if (!current->right) {
                current->right = new TreeNode(value);
                return root;
            } else {
                q.push(current->right);
            }
        }
        return root;
    }

    TreeNode* deleteNode(TreeNode* root, int val) {
        if (!root)
            return nullptr;

        queue<TreeNode*> q;
        q.push(root);
        TreeNode* keyNode = nullptr;
        TreeNode* curr = nullptr;
        TreeNode* parent =nullptr;
        // Find the node with the given value and keep track of the last node
        while (!q.empty()) {
            curr = q.front();
            q.pop();

            if (curr->data == val)
                keyNode = curr;

            if (curr->left){
                parent=curr;
                q.push(curr->left);

            }
            if (curr->right){
                parent=curr;
                q.push(curr->right);

        }
        }

        // If we found the key node, replace its data and delete the deepest node
        if (keyNode) {
            keyNode->data = curr->data;
            if(parent->left==curr)
                parent->left=nullptr;
            else parent->right=nullptr;
            delete curr;
        }
        return root;
    }

   

    int count_nodes(TreeNode* node) {
        if (!node)
            return 0;
        return 1 + count_nodes(node->left) + count_nodes(node->right);
    }

    void inorder(TreeNode* node) {
        if (node == nullptr) {
            return;
        }
        inorder(node->left);
        cout << node->data << " ";
        inorder(node->right);
    }

    TreeNode* sorted_array_to_BST(int* arr, int start, int end) {
        if (start > end)
            return nullptr;
        int mid = start + (end - start) / 2;
        TreeNode* node = new TreeNode(arr[mid]);
        node->left = sorted_array_to_BST(arr, start, mid - 1);
        node->right = sorted_array_to_BST(arr, mid + 1, end);
        return node;
    }

    void store_in_array(TreeNode* root, int* arr, int& index) {
        if (!root)
            return;
        store_in_array(root->left, arr, index);
        arr[index++] = root->data;
        store_in_array(root->right, arr, index);
    }

public:
    TreeNode* root;
    BinaryTree() : root(nullptr) {}

    void insert(int value) {
        root = insertNode(value);
    }

    void delete_node(int value) {
      root=  deleteNode(root, value);
    }

    int total_nodes() {
        return count_nodes(root);
    }

    void convert_to_BST() {
        int n = total_nodes();
        int* arr = new int[n];
        int index = 0;
        store_in_array(root, arr, index);
        sort(arr, arr + n);
        root = sorted_array_to_BST(arr, 0, n - 1);
        delete[] arr; // Free the allocated memory
    }

    void inorder_display() {
        if (!root) {
            cout << "Tree is empty." << endl;
            return;
        }
        inorder(root);
        cout << endl;
    }

    bool is_complete_bt(TreeNode* node) {
        if (!node)
            return true;
        queue<TreeNode*> q;
        q.push(node); // pushing the root first;
        bool nullnode = false;
        while (!q.empty()) {
            TreeNode* curr = q.front();
            q.pop();
            if (!curr)
                nullnode = true;
            else {
                if (nullnode)
                    return false;
                if (curr->left) q.push(curr->left);
                if (curr->right) q.push(curr->right);
            }
        }
        return true;
    }

    bool is_full_bt(TreeNode* root) {
        if (!root)
            return true;
        if ((!root->left && root->right) || (root->left && !root->right))
            return false;
        return (is_full_bt(root->left) && is_full_bt(root->right));
    }
};

int main() {
    BinaryTree bt;
    bt.insert(1);
    bt.insert(2);
    bt.insert(3);
    bt.insert(4);
    bt.insert(5);
    bt.insert(6);
    bt.insert(7);

    bt.inorder_display();
    if (bt.is_complete_bt(bt.root))
        cout << "Complete binary tree\n";
    if (bt.is_full_bt(bt.root))
        cout << "Full binary tree\n";

    bt.delete_node(3);
    bt.inorder_display();

    bt.convert_to_BST();
    bt.inorder_display();

    return 0;
}
