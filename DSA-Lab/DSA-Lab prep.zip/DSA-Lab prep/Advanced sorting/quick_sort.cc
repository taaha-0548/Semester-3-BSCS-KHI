#include <iostream>
#include <string>
using namespace std;
int partition(int *arr,int low, int high){
    int pivot=arr[low];
    int i=low+1;
    int j=high;
    while(i<=j){
    while(i<=high && arr[i]<=pivot){
        i++;
    }
    while(j>=low &&arr[j]>pivot){
        j--;
    }
    if(i<j){
        swap(arr[i],arr[j]);
    }
    }
    swap(arr[low],arr[j]);
    return j;
}
void quick_sort(int *arr,int low,int high){
    if(low<high){
   int pivot=partition(arr,low,high);
   quick_sort(arr,low,pivot-1);
   quick_sort(arr,pivot+1,high);
    }
}
void printArray(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main() {
    int arr[] = {1123, 124213, 132, 5123, 23, 5}; // Example array
    int n = sizeof(arr) / sizeof(arr[0]); // Calculate the number of elements

    cout << "Original array: ";
    printArray(arr, n); // Print original array

    quick_sort(arr, 0, n - 1); // Perform Quick Sort

    cout << "Sorted array: ";
    printArray(arr, n); // Print sorted array

    return 0;
}