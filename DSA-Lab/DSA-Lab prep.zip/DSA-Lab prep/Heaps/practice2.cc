#include <iostream>
#include <stack>
using namespace std;
/* the warehouse uses a dynamic system with packeges having ids and timestamps like "pkg5" at 50 mins .. warehouses uses a min heap to manage the packages, after inserting all the intitial packages you need to extract teh firist three packages to be process, ensure the heap is reconstucted after each extraction.. once the */
class Package{
    public:
    string id;
    int time;
    Package(string i="",int t=0):id(i),time(t){}

};
class MinHeap{
    public:
    Package *arr;
    int capacity;
    int size;
   
    void min_heapify_down(int index){
        int smallest =index;
         int t= arr[smallest].time;
        int left= 2*index+1;
        int right =2*index+2;
        if(left<size &&arr[left].time<t){
             smallest =left;
        }
        t= arr[smallest].time;
        if(right <size &&arr[right].time<t)
            smallest =right;
        
        if(smallest!=index){
            swap(arr[smallest],arr[index]);
            min_heapify_down(smallest);
        }

    }
    void min_heapify_up(int index){
       
        while(index>0){
             int parent= (index-1)/2;
             if(arr[index].time<arr[parent].time)
             swap(arr[parent],arr[index]);
             else return;
             index = parent;
        }
    }
    public:
    MinHeap(int c):capacity(c),size(0){
        arr= new Package[capacity];

    }
    void insert(string str,int t){
        Package newpackage(str,t);
        arr[size]=newpackage;
             min_heapify_up(size);
        size++;
   
    }
    Package process_top(){
        if(size==0){
            cout<<"Heap is empty\n";
            return Package();
        }
        Package root = arr[0];
        arr[0]=arr[size-1];
        size--;
        min_heapify_down(0);
        return root;

    }
    void print_heap() const {
        for (int i = 0; i < size; i++) {
            cout << arr[i].id << " (" << arr[i].time << " mins) ";
        }
        cout << endl;
    }

};
int main(){
    MinHeap mh(6);
    mh.insert("pkg1", 30);
    mh.insert("pkg2", 10);
    mh.insert("pkg3", 20);
    mh.insert("pkg4", 40);
    mh.insert("pkg5", 50);
    mh.insert("pkg6",60);
    cout << "Initial Min Heap:\n";
    mh.print_heap();
    // Extract first three packages
    cout << "\nProcessing first three packages:\n";
    for (int i = 0; i < 3; i++) {
        
            Package p = mh.process_top();
            cout << "Processed: " << p.id << " (" << p.time << " mins)\n";
    
    }
   
    stack<Package> package_stack;
    while (mh.size!=0) {
        package_stack.push(mh.process_top());
    }

    
    while (!package_stack.empty()) {
        Package p = package_stack.top();
        mh.insert(p.id, p.time);
        package_stack.pop();
    }

    cout << "\nHeap reconstructed from stack:\n";
    mh.print_heap();

    return 0;

  
}