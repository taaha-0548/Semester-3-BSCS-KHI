#include <iostream>
#include <cmath>

using namespace std;
class Coordinates{
    public:
    int x,y;
    Coordinates(int x,int y):x(x),y(y){}
    Coordinates():x(0),y(0){}
    int get_distance(){
        int x_s=x*x;
        int y_s= y*y;
        return (int)sqrt(x_s+y_s);
    }
};

void max_heapify(Coordinates  arr[],int n,int i){
    int largest= i;
    int left= 2*i+1;
    int right= 2*i+2;
    int distance =arr[largest].get_distance();
    if(left<n && arr[left].get_distance()>distance){
        largest= left;
      
    }
    // if the distance changed in the above code...
      distance =arr[largest].get_distance();
    if(right<n && arr[right].get_distance()>distance){
        largest =right;

    }
    if(largest!=i){
        swap(arr[largest],arr[i]);
        max_heapify(arr,n,largest);
    }
}
void Heap_Sort(Coordinates arr[],int n){
    // build max heap arr
    for(int i=n/2-1;i>=0;i--){
        max_heapify(arr,n,i);
    }
    // heap sort
    for(int i=n-1;i>0;i--){
        swap(arr[0],arr[i]);
        max_heapify(arr,i,0);
    }

}
void find_kth_largest(int k,Coordinates arr[],int n){
     Heap_Sort(arr,n);
   
     int target= arr[n-k].get_distance();
     // for multiple answers
     for(int i=0;i<n;i++){
        if(arr[i].get_distance()==target)
            cout<<"("<<arr[i].x<<", "<<arr[i].y<<")";
     }
}
int main(){
    Coordinates arr[]={
        {1,3},{2,-2},{5,8},{0,1},{7,6}
        };
        int n=5;
   
    int k=2;
    find_kth_largest(k,arr,n);
}