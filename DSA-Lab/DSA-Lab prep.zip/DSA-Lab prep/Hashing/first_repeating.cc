#include <iostream>
using namespace std;
class HashMap{
    int capacity;
    int *arr;
    int size;
    int hashing_function(int value){
        return value % capacity;
    }
    public:
    HashMap(int c):capacity(c),size(0){
        arr= new int[capacity];
        for(int i=0;i<capacity;i++){
            arr[i]=-1;
        }
    }

    bool insert(int value){
        int index= hashing_function(value);
        if(arr[index]!=-1){
        cout<<"first repeating element: "<<value<<endl;
            return false;
        }
        arr[index]=value;
        return true;

    }
    
};
void first_repeating(int *arr,int n){
    HashMap hm(n);
        for(int i=0;i<n;i++){
            if(!hm.insert(arr[i]))
                return;
        }
    }
int main(){
int arr[]={1,3,5,6,7,1,8};;
int n=7;
first_repeating(arr,n);
}