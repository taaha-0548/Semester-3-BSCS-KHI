#include <iostream>
#include <string>
using namespace std;
class HashMap{
      public:
    int *arr;
    int capacity;
  
    int hash_function(char c){
        return c-'a';

    }

    HashMap():capacity(26){
        arr= new int [capacity];
        for(int i=0;i<capacity;i++){
            arr[i]=0;
        }

    }
    void insert(char c){
        int index= hash_function(c);
        arr[index]++;

    }



};
void first_non_repeating(string str){
    HashMap h;
    for(int i=0;i<str.length();i++){
        h.insert(str[i]);
    }
    for(int i=0;i<str.length();i++){
        int index= h.hash_function(str[i]);
        if(h.arr[index]==1){
            cout<<str[i]<<endl;
            return;
        }
     

    }   cout<<"Not found.\n";
}
int main(){
    string str= "geeksforgeeks";
    first_non_repeating(str);
}