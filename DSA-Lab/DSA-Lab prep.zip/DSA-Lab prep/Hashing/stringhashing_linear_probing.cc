#include <iostream>
#include <string>
using namespace std;

class HashTable {
    string *arr;
    int capacity;
    int size;
    int hashing_function(string str){
        int value=0;
        for(int i=0;i<str.length();i++){
            value+=str[i];
        }
        return value %capacity;
    }
 
    public:
    HashTable(int c):capacity(c){
        arr= new string[capacity];
        for(int i=0;i<capacity;i++){
            arr[i]="";
        }
    }

   void insert(string data){
    if (size == capacity) {
    cout << "Hash table is full.\n";
    return;
}

    int index= hashing_function(data);
    int original= index;
    for(int i=0;i<capacity;i++){
        if(arr[index]==""){
            arr[index]=data;
            size++;
            cout<<"data inserted\n";
            return;
        }else if(arr[index]==data) // duplicate not allowed
          return;
          index=(original+i)%capacity;
    }
    arr[index]=data;
    size++;
    
   }
   void remove(string data){
    int index = hashing_function(data);
    int original= index;
    for(int i=0;i<capacity;i++){
        index=(original+i)%capacity;
        if(arr[index]=="")
            break;
        if(arr[index]==data){
            arr[index]="";
            size--;
            return;
        }
        
        
    }
    cout<<"data not found\n";
   }
   // Display the table
    void display() {
        merge_sort(arr,0,capacity-1);
        for (int i = 0; i < capacity; i++) {
            cout << arr[i] << endl;
        }
        cout << endl;
    }
   bool search(string data){
    int index= hashing_function(data);
    int original=index;
    for(int i=0;i<capacity;i++){
        index= (original+i)% capacity;
        if(arr[index]=="")
            return false;
        if(arr[index]==data)
            return true;
    }
    return false;
   }
   void merge(string *arr,int left,int mid,int right){ // {0,1,2,3,4,5}
    int ls= mid+1-left;
    int rs= right-mid;
    string *left_arr= new string[ls];
    string *right_arr= new string[rs];
    for(int i=0;i<ls;i++)
        left_arr[i]=arr[i+left];
    for(int i=0;i<rs;i++)
        right_arr[i]=arr[mid+1+i];
    int i=0,j=0,k=left;
    while(i<ls && j<rs){
        if(left_arr[i]<=right_arr[j])
        arr[k++]=left_arr[i++];
        else arr[k++]= right_arr[j++];
    }
    while(i<ls){
        arr[k++]=left_arr[i++];
    }
    while(j<rs)
    arr[k++]=right_arr[j++];


   }
   void merge_sort(string *arr,int left,int right){
    if(left>=right)
        return ;
        int mid= left+(right-left)/2;
        merge_sort(arr,left,mid);
        merge_sort(arr,mid+1,right);
        merge(arr,left,mid,right);

   }
};

int main() {
    HashTable ht(5); // Create a hash table with 5 buckets

    // Inserting dates into the hash table
    ht.insert("12/05/2023 12:30");
    ht.insert("14/07/2021 14:00");
    ht.insert("01/01/2022 09:00");
    
    ht.insert("11/05/2024 10:15");
    ht.insert("12/12/2022 15:00");

    

  
    ht.display();

    return 0;
}
