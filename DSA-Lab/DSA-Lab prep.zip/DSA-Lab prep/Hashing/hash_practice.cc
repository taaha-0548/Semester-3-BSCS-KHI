#include <iostream>
#include <algorithm>
using namespace std;

// Node for Linked List (Used for Separate Chaining)
class Node {
public:
    int rating;
    int frequency;
    Node* next;
    Node(int r) : rating(r), frequency(1), next(nullptr) {}
};

// Hash Table with Separate Chaining
class HashTable {
    Node** table; // The hash table (array of linked lists)
    int bucket_count; // The number of buckets in the table
    int num_elements; // The current number of elements in the table

    // Hash function to map a value to an index
    int hash_function(int value) {
        return value % bucket_count;
    }

    // Resize the table and rehash all elements
    void resizeAndRehash() {
        int old_size = bucket_count;
        bucket_count *= 2; // Double the bucket size
        Node** new_table = new Node*[bucket_count](); // Create a new table

        // Rehash all elements from the old table to the new table
        for (int i = 0; i < old_size; i++) {
            Node* curr = table[i];
            while (curr) {
                int new_index = hash_function(curr->rating);
                Node* new_node = new Node(curr->rating);
                new_node->frequency = curr->frequency; // Copy frequency
                new_node->next = new_table[new_index];
                new_table[new_index] = new_node;
                curr = curr->next;
            }
        }

        // Delete the old table and point to the new table
        delete[] table;
        table = new_table;
    }

public:
    // Constructor
    HashTable(int size) : bucket_count(size), num_elements(0) {
        table = new Node*[bucket_count](); // Initialize all buckets to nullptr
    }

    // Insert a value into the hash table
    void insert(int rating) {
        // If load factor exceeds 0.7, resize the table and rehash
        if (float(num_elements) / bucket_count > 0.7) {
            resizeAndRehash();
        }

        int index = hash_function(rating); // Find the bucket
        Node* curr = table[index];
        
        // Check if rating already exists, if yes, increment frequency
        while (curr) {
            if (curr->rating == rating) {
                curr->frequency++;
                return;
            }
            curr = curr->next;
        }

        // If rating doesn't exist, insert new node at the beginning
        Node* new_node = new Node(rating);
        new_node->next = table[index];  // Insert at the beginning of the linked list
        table[index] = new_node;        // Update the head of the linked list
        num_elements++;                 // Increment the number of elements
    }

    // Get all ratings and their frequencies into an array
    void getAllRatings(Node* ratings[], int& count) {
        count = 0;
        for (int i = 0; i < bucket_count; i++) {
            Node* curr = table[i];
            while (curr) {
                ratings[count++] = curr;
                curr = curr->next;
            }
        }
    }

    // Destructor to clean up memory
    ~HashTable() {
        for (int i = 0; i < bucket_count; i++) {
            Node* curr = table[i];
            while (curr) {
                Node* temp = curr;
                curr = curr->next;
                delete temp;
            }
        }
        delete[] table;
    }
};

// Merge function to merge two halves in merge sort
void merge(Node* arr[], int left, int mid, int right) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    Node* left_arr[n1], *right_arr[n2];

    for (int i = 0; i < n1; i++) {
        left_arr[i] = arr[left + i];
    }
    for (int j = 0; j < n2; j++) {
        right_arr[j] = arr[mid + 1 + j];
    }

    int i = 0, j = 0, k = left;

    while (i < n1 && j < n2) {
        if (left_arr[i]->frequency > right_arr[j]->frequency || 
            (left_arr[i]->frequency == right_arr[j]->frequency && left_arr[i]->rating > right_arr[j]->rating)) {
            arr[k++] = left_arr[i++];
        } else {
            arr[k++] = right_arr[j++];
        }
    }

    while (i < n1) {
        arr[k++] = left_arr[i++];
    }
    while (j < n2) {
        arr[k++] = right_arr[j++];
    }
}

// Merge Sort function to sort ratings by frequency and rating
void mergeSort(Node* arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }
}

int main() {
    HashTable ht(5); // Create a hash table with 5 buckets

    // Insert ratings
    ht.insert(5);
    ht.insert(4);
    ht.insert(3);
    ht.insert(5);
    ht.insert(5);
    ht.insert(4);
    ht.insert(2);
    ht.insert(4);
    ht.insert(5);
    ht.insert(3);
    ht.insert(3);
    ht.insert(3);

    // Get all ratings and their frequencies
    Node* ratings[100];  // Array to hold the rating nodes
    int count = 0;
    ht.getAllRatings(ratings, count);

    // Sort ratings by frequency and by rating in case of ties
    mergeSort(ratings, 0, count - 1);

    // Display the sorted ratings
    cout << "Ratings sorted by frequency (and by rating in case of ties):" << endl;
    for (int i = 0; i < count; i++) {
        cout << "Rating: " << ratings[i]->rating << ", Frequency: " << ratings[i]->frequency << endl;
    }

    return 0;
}
