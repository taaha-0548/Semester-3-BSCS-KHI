#include <iostream>
#include <string>
using namespace std;

// Node for Linked List (Used for Separate Chaining)
class Node {
public:
    string data;  // Date in the format "DD/MM/YYYY HH:MM"
    Node* next;   // Pointer to the next node in the chain
    Node(string dateVal) : data(dateVal), next(nullptr) {}
};

// Hash Table with Separate Chaining
class HashTable {
    Node** table; // The hash table (array of linked lists)
    int bucket_count; // The number of buckets in the table
    int num_elements; // The current number of elements in the table

    // Hash function to map a value (date) to an index
    int hash_function(const string& date) {
        int hashValue = 0;
        for (char c : date) {
            hashValue += c;  // Sum of ASCII values of characters in the date
        }
        return hashValue % bucket_count;  // Using modulo for bucket count
    }

    // Merge function to merge two sorted arrays of nodes
    void merge(Node* arr[], int left, int mid, int right) {
        int leftSize = mid - left + 1;
        int rightSize = right - mid;
        
        Node* leftArr[leftSize];
        Node* rightArr[rightSize];
        
        for (int i = 0; i < leftSize; ++i) {
            leftArr[i] = arr[left + i];
        }
        for (int i = 0; i < rightSize; ++i) {
            rightArr[i] = arr[mid + 1 + i];
        }
        
        int i = 0, j = 0, k = left;
        while (i < leftSize && j < rightSize) {
            if (leftArr[i]->data < rightArr[j]->data) {
                arr[k++] = leftArr[i++];
            } else {
                arr[k++] = rightArr[j++];
            }
        }
        
        while (i < leftSize) {
            arr[k++] = leftArr[i++];
        }
        
        while (j < rightSize) {
            arr[k++] = rightArr[j++];
        }
    }

    // Merge Sort to sort the array of Node pointers
    void mergeSort(Node* arr[], int left, int right) {
        if (left >= right) return;
        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }

public:
    // Constructor
    HashTable(int size) : bucket_count(size), num_elements(0) {
        table = new Node*[bucket_count](); // Initialize all buckets to nullptr
    }

    // Insert a date into the hash table
    void insert(const string& date) {
        int index = hash_function(date); // Find the bucket
        Node* new_node = new Node(date);  // Create a new node
        new_node->next = table[index]; // move the head to the next position of the current
        table[index] = new_node;    // set curr= head;
        num_elements++;                   // Increment the number of elements
    }

    // Search for a value (date) in the hash table
    bool search(const string& date) {
        int index = hash_function(date); // Find the bucket
        Node* curr = table[index];       // Traverse the linked list
        while (curr) {
            if (curr->data == date)      // Date found
                return true;
            curr = curr->next;           // Move to the next node
        }
        return false;                    // Date not found
    }

    // Remove a value (date) from the hash table
    void remove(const string& date) {
        int index = hash_function(date); // Find the bucket
        Node* curr = table[index];       // Start from the head of the linked list
        Node* prev = nullptr;

        while (curr) {
            if (curr->data == date) {  // Date found
                if (prev) {
                    prev->next = curr->next;  // Bypass the node to delete it
                } else {
                    table[index] = curr->next; // If removing the head, update the head
                }
                delete curr;          // Free the memory
                num_elements--;       // Decrement the number of elements
                return;
            }
            prev = curr;
            curr = curr->next;
        }
    }

    // Display all dates, sorted by name (using merge sort)
    void display() {
        for (int i = 0; i < bucket_count; i++) {
            Node* arr[5]; // We will use an array to store pointers at each bucket
            int count = 0;
            Node* curr = table[i];
            while (curr) {
                arr[count++] = curr;
                curr = curr->next;
            }
            // Sort the dates at this bucket using merge sort
            mergeSort(arr, 0, count - 1);
            cout << "Bucket #" << i + 1 << ": ";
            for (int j = 0; j < count; j++) {
                cout << arr[j]->data << ", ";
            }
            cout << endl;
        }
        cout << endl;
    }

    // Destructor to clean up memory
    ~HashTable() {
        for (int i = 0; i < bucket_count; i++) {
            Node* curr = table[i];
            while (curr) {
                Node* temp = curr;
                curr = curr->next;
                delete temp;
            }
        }
        delete[] table;
    }
};

int main() {
    HashTable ht(5); // Create a hash table with 5 buckets

    // Inserting dates into the hash table
    ht.insert("12/05/2023 12:30");
    ht.insert("14/07/2021 14:00");
    ht.insert("01/01/2022 09:00");
    ht.insert("12/05/2023 12:30");  // Duplicate, should be handled
    ht.insert("11/05/2024 10:15");
    ht.insert("12/12/2022 15:00");

    // Display all dates in sorted order
    cout << "Dates in sorted order: \n";
    ht.display();

    return 0;
}
