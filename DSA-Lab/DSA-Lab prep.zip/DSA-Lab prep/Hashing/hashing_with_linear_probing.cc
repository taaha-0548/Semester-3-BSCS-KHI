#include <iostream>
using namespace std;

class HashTable {
    int* table;
    int capacity;

    int hash_function(int key) {
        return key % capacity;
    }

    // Linear probing with a for loop
    int linear_probe(int key) {
        int index = hash_function(key);
        for (int i = 0; i < capacity; ++i) { // Loop until we find an empty slot or full table
            int new_index = (index + i) % capacity;
            if (table[new_index] == -1) { // Found an empty slot
                return new_index;
            }
        }
        return -1; // Table is full
    }

public:
    HashTable(int cap) : capacity(cap) {
        table = new int[capacity];
        for (int i = 0; i < capacity; i++) {
            table[i] = -1; // Initialize the table with -1 (empty slots)
        }
    }

    // Insert using linear probing
    void insert(int key) {
        int index = linear_probe(key);
        if (index == -1) {
            cout << "Hash table full.\n";
            return;
        }
        table[index] = key;
        cout << "Inserted " << key << " at index " << index << endl;
    }

    // Search using linear probing
    bool search(int key) {
        int index = hash_function(key);
        for (int i = 0; i < capacity; ++i) {
            int new_index = (index + i) % capacity;
            if (table[new_index] == -1) { // Empty slot indicates key not found
                return false;
            }
            if (table[new_index] == key) { // Key found
                return true;
            }
        }
        return false; // Key not found after full probe
    }

    // Remove a key using linear probing
    void remove(int key) {
        int index = hash_function(key);
        for (int i = 0; i < capacity; ++i) {
            int new_index = (index + i) % capacity;
            if (table[new_index] == -1) { // If empty slot is found, key not present
                break;
            }
            if (table[new_index] == key) {
                table[new_index] = -1; // Mark the slot as empty
                cout << "Removed key: " << key << endl;
                return;
            }
        }
        cout << "Key not found.\n";
    }

    // Display the table
    void display() {
        for (int i = 0; i < capacity; i++) {
            cout << table[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    HashTable ht(10);
    ht.insert(20);
    ht.insert(15);
    ht.insert(45);
    ht.insert(105);
    ht.insert(21);
    ht.insert(31);
    ht.display();

    if (ht.search(105)) {
        cout << "found\n";
    } else {
        cout << "not found\n";
    }

    ht.remove(105);
    ht.display();

    return 0;
}
