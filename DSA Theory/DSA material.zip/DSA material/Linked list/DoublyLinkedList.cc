#include <iostream>
#include <string>
using namespace std;
// Node class for doubly linked list.
class Node
{
public:
    int data;
    Node *next;
    Node *prev;
    Node(int val) : data(val), next(nullptr), prev(nullptr) {}
};
class DoublyLinkedList
{
    Node *head;
    Node *tail;

public:
    DoublyLinkedList() : head(nullptr), tail(nullptr) {}
    void insert_at_end(int val)
    {
        Node *new_node = new Node(val);
        if (!head)
        {
            head = new_node;
            tail = head;
        }
        else
        {
            tail->next = new_node;
            new_node->prev = tail;
            tail = new_node;
        }
        cout << "Inserted " << val << " at the end.\n";
    }
    void insert_at_head(int val)
    {
        Node *new_node = new Node(val);
        if (!head)
        {
            head = new_node;
            tail = head;
        }
        else
        {
            new_node->next = head;
            head->prev = new_node;
            head = new_node;
        }
        cout << "Inserted " << val << " at the front.\n";
    }
    // considering 1-based index.
    void insert_at_position(int val, int pos)
    {
        if (pos < 1)
        {
            cout << "Position should be greater than one.\n";
        }
        if (pos == 1)
        {
            insert_at_end(val);
        }
        Node *new_node = new Node(val);
        Node *temp = head;
        int count = 1;
        while (temp && count < pos - 1)
        {
            temp = temp->next;
            count++;
        }
        if (!temp)
        {
            cout << "Position out of bounds. Inserting at the end.\n";
            insert_at_end(val);
            return;
        }
        Node *after_temp = temp->next;
        // Inserting in the middle or at the end
        new_node->next = after_temp;
        new_node->prev = temp;

        if (after_temp)
        {
            after_temp->prev = new_node;
        }
        else
        {
            tail = new_node; // Update tail if we're inserting at the end
        }

        temp->next = new_node;

        cout << "Inserted " << val << " at position " << pos << ".\n";
    }
    // Delete a node from the front of the list
    void delete_from_front()
    {
        if (!head)
        {
            cout << "List is empty. Nothing to delete.\n";
            return;
        }
        Node *to_delete = head;
        if (head == tail)
        { // Only one node in the list
            head = tail = nullptr;
        }
        else
        {
            head = head->next;
            head->prev = nullptr;
        }
        delete to_delete;
        cout << "Deleted node from the front.\n";
    }

    // Delete a node from the end of the list
    void delete_from_end()
    {
        if (!head)
        {
            cout << "List is empty. Nothing to delete.\n";
            return;
        }
        Node *to_delete = tail;
        if (head == tail)
        { // Only one node in the list
            head = tail = nullptr;
        }
        else
        {
            tail = tail->prev;
            tail->next = nullptr;
        }
        delete to_delete;
        cout << "Deleted node from the end.\n";
    }

    // Delete a node at a specific position (1-based index)
    void delete_at_position(int pos)
    {
        if (pos < 1)
        {
            cout << "Position should be greater than or equal to one.\n";
            return;
        }
        if (pos == 1)
        {
            delete_from_front();
            return;
        }

        Node *temp = head;
        int count = 1;

        while (temp && count < pos)
        {
            temp = temp->next;
            count++;
        }

        if (!temp)
        {
            cout << "Position out of bounds. No node to delete.\n";
            return;
        }

        if (temp == tail)
        { // Node to delete is the tail
            delete_from_end();
            return;
        }

        // Node to delete is in the middle
        temp->prev->next = temp->next;
        temp->next->prev = temp->prev;
        delete temp;

        cout << "Deleted node at position " << pos << ".\n";
    }

    // Display the list from front to end
    void display() const
    {
        if (!head)
        {
            cout << "List is empty.\n";
            return;
        }
        Node *temp = head;
        while (temp)
        {
            cout << temp->data << " <-> ";
            temp = temp->next;
        }
        cout << "nullptr\n";
    }

    // Display the list from end to front
    void display_reverse() const
    {
        if (!tail)
        {
            cout << "List is empty.\n";
            return;
        }
        Node *temp = tail;
        while (temp)
        {
            cout << temp->data << " <-> ";
            temp = temp->prev;
        }
        cout << "nullptr\n";
    }
    
    // Search for a node with a specific value and return true if found, false otherwise
    bool search(int val) const
    {
        Node *temp = head;
        while (temp)
        {
            if (temp->data == val)
            {
                return true;
            }
            temp = temp->next;
        }
        return false; // Value not found
    }
    int get_first() const
    {
        if (!head)
        {
            throw runtime_error("List is empty.");
        }
        return head->data;
    }
    int get_last() const
    {
        if (!tail)
        {
            throw runtime_error("List is empty.");
        }
        return tail->data;
    }
    void display_reverse() const
    {
        if (!tail)
        {
            cout << "List is empty.\n";
            return;
        }
        Node *temp = tail;
        while (temp)
        {
            cout << temp->data << " <-> ";
            temp = temp->prev;
        }
        cout << "nullptr\n";
    }

    // Destructor to clean up dynamically allocated nodes
    ~DoublyLinkedList()
    {
        while (head)
        {
            delete_from_front();
        }
    }
};