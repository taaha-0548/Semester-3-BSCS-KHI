#include <iostream>
using namespace std;

class Node {
public:
    int data;  // Data stored in the node
    Node* next;  // Pointer to the next node
    Node(int val) : data(val), next(nullptr) {}
};

class CircularLinkedList {
    Node* head;  // Pointer to the first node (head) of the list

public:
    CircularLinkedList() : head(nullptr) {}

    // Add a node at the front of the list
    void add_at_front(int val) {
        Node* new_node = new Node(val);
        if (!head) {
            // Case 1: List is empty
            head = new_node;
            new_node->next = head;  // Make the new node point to itself (circular link)
        } else {
            // Case 2: List is not empty
            Node* temp = head;
            // Traverse the list to find the last node that points to the head
            while (temp->next != head) {
                temp = temp->next;
            }
            // Insert the new node at the front
            new_node->next = head;
            temp->next = new_node;  // Last node now points to the new node
            head = new_node;  // Update head to the new front node
        }
    }

    // Add a node to the end of the list
    void add_to_end(int val) {
        Node* new_node = new Node(val);
        if (!head) {
            // Case 1: List is empty
            head = new_node;
            new_node->next = head;  // Make the new node point to itself (circular link)
        } else {
            // Case 2: List is not empty
            Node* temp = head;
            // Traverse the list to find the last node
            while (temp->next != head) {
                temp = temp->next;
            }
            // Insert the new node at the end
            new_node->next = head;
            temp->next = new_node;  // Last node now points to the new node
        }
    }

    // Display the entire circular linked list
    void display() {
        if (!head) {
            // Case: List is empty
            cout << "List is empty.\n";
            return;
        }
        Node* temp = head;
        // Loop through the list until we return to the head
        do {
            cout << temp->data << " -> ";
            temp = temp->next;
        } while (temp != head);
        cout << "(head)" << endl;  // Mark the circular link
    }
     void insert_at_position(int val, int pos) {
        if (pos < 1) {
            cout << "Position should be 1 or greater.\n";
            return;
        }

        if (pos == 1) {
            // Insert at the front
            add_at_front(val);
            return;
        }

        Node* new_node = new Node(val);
        Node* temp = head;
        int count = 1;

        // Traverse to the node before the desired position
        while (count < pos - 1 && temp->next != head) {
            temp = temp->next;
            count++;
        }

        if (count < pos - 1) {
            cout << "Position out of bounds.\n";
            delete new_node;
            return;
        }

        new_node->next = temp->next;
        temp->next = new_node;
    }

    // Delete a node from the front of the list
    void delete_from_front() {
        if (!head) {
            // Case: List is empty
            cout << "List is empty.\n";
            return;
        }

        if (head->next == head) {
            // Case: Only one node in the list
            delete head;
            head = nullptr;
        } else {
            // Case: More than one node
            Node* temp = head;
            // Find the last node which points to the head
            while (temp->next != head) {
                temp = temp->next;
            }
            Node* to_delete = head;  // Node to be deleted (old head)
            head = head->next;  // Move head to the next node
            temp->next = head;  // Last node now points to the new head
            delete to_delete;
        }
    }

    // Delete a node from the end of the list
    void delete_from_end() {
        if (!head) {
            // Case: List is empty
            cout << "List is empty.\n";
            return;
        }

        if (head->next == head) {
            // Case: Only one node in the list
            delete head;
            head = nullptr;
        } else {
            // Case: More than one node
            Node* temp = head;
            Node* prev = nullptr;  // Pointer to track the previous node
            // Traverse the list to find the last node
            while (temp->next != head) {
                prev = temp;
                temp = temp->next;
            }
            // Update the second-to-last node to point to the head
            prev->next = head;
            delete temp;  // Delete the last node
        }
    }

    // Search for a node with a specific value in the list
    bool search(int val) {
        if (!head) {
            // Case: List is empty
            return false;
        }
        Node* temp = head;
        // Traverse the list and look for the value
        do {
            if (temp->data == val) {
                return true;  // Value found
            }
            temp = temp->next;
        } while (temp != head);  // Stop when we return to the head
        return false;  // Value not found
    }

    // Delete a node by its value
    void delete_by_value(int val) {
        if (!head) {
            // Case: List is empty
            cout << "List is empty.\n";
            return;
        }

        if (head->data == val) {
            // If the node to delete is the head, we can reuse the existing function
            delete_from_front();
            return;
        }

        Node* temp = head;
        Node* prev = nullptr;
        // Traverse the list to find the node with the matching value
        do {
            prev = temp;
            temp = temp->next;
            if (temp->data == val) {
                // Node with the value found, adjust pointers and delete it
                prev->next = temp->next;
                delete temp;
                return;
            }
        } while (temp != head);

        cout << "Value " << val << " not found in the list.\n";
    }

    // Get the size of the circular linked list
    int size() {
        if (!head) {
            return 0;  // List is empty
        }
        int count = 0;
        Node* temp = head;
        // Traverse the list to count nodes
        do {
            count++;
            temp = temp->next;
        } while (temp != head);
        return count;
    }
};

int main() {
    CircularLinkedList cll;
    cll.add_at_front(10);
    cll.add_at_front(20);
    cll.add_to_end(30);
    cll.display();  // Output: 20 -> 10 -> 30 -> (head)

    cout << "Size of the list: " << cll.size() << endl;  // Output: 3

    cll.delete_from_front();
    cll.display();  // Output: 10 -> 30 -> (head)

    cll.delete_from_end();
    cll.display();  // Output: 10 -> (head)

    cll.add_at_front(40);
    cll.add_to_end(50);
    cll.display();  // Output: 40 -> 10 -> 50 -> (head)

    cout << "Is 10 in the list? " << (cll.search(10) ? "Yes" : "No") << endl;  // Output: Yes

    cll.delete_by_value(10);
    cll.display();  // Output: 40 -> 50 -> (head)

    cout << "Is 10 in the list? " << (cll.search(10) ? "Yes" : "No") << endl;  // Output: No

    return 0;
}
