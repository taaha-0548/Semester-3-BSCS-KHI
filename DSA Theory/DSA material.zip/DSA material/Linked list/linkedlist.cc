#include <iostream>
using namespace std;

class Node {
public:
    int value;
    Node* next;

    // Parameterized constructor
    Node(int value) {
        this->value = value;
        this->next = nullptr;
    }
};

class LinkedList {
private:
    Node* head;
    int size;

public:
    // Constructor
    LinkedList() {
        head = nullptr;
        size = 0;
    }

    // Append function to add a node at the end of the list
    void Add_to_tail(int data) {
        Node* newnode = new Node(data);
        if (head == nullptr)
            head = newnode;
        else {
            Node* temp = head;
            while (temp->next != nullptr)
                temp = temp->next;
            temp->next = newnode;
        }
        size++;
        cout << data << " added at the end of the list.\n";
    }

    // Prepend function to add a node at the beginning of the list
    void Add_to_head(int data) {
        Node* newnode = new Node(data);
        newnode->next = head;
        head = newnode;
        size++;
        cout << data << " added at the start of the list.\n";
    }

    // Delete function to remove a node from the list
    void Delete_from_start() {
       if(head== nullptr){ // which means the list is empty.
        cout<<"This linked list is empty.\n";
        return;
       } 
       Node *temp= head;
       head =temp->next;
       delete temp;
       size--;
    }
    void Delete_from_end(){
        if(head==nullptr){ // which means the list is empty.
            cout<<"The linked list is emppty";
            return;
        }
        if(head->next==nullptr){ // which means only one node.
            delete head; // remove the only node
            head= nullptr;
        } 
        Node* temp= head;
        Node* prev =head;
        while(temp->next!=nullptr){
            prev= temp;
            temp= temp->next;

        }
        prev->next=nullptr;
        delete temp;
        size--;
    }

    void Delete_middle_node() {
    if (head == nullptr) { // Empty list
        cout << "The linked list is empty.\n";
        return;
    }
    if (head->next == nullptr) { // Only one node
        delete head;
        head = nullptr;
        size--;
        return;
    }
    
    Node* slow = head;
    Node* fast = head;
    Node* prev = nullptr; // To keep track of the node before the middle node
    
    while (fast != nullptr && fast->next != nullptr) {
        prev = slow;
        slow = slow->next;
        fast = fast->next->next;
    }
    
    // 'slow' is now pointing to the middle node
    // 'prev' is the node before the middle node
    prev->next = slow->next;
    delete slow;
    size--;
}

    void Delete_at_position(int pos){ 
        if(head==nullptr){ // which means the list is empty.
            cout<<"The linked list is emppty";
            return;
        }

        if(pos>=size){
            cout<<"This position doesnt exist";
            return;
        }
        if(pos==0){
            Delete_from_start();
            return;
        }
        if(pos==size-1){
            Delete_from_end();
        }

        Node* temp =head;
        Node* prev =head;
        for(int i=0;i<pos;i++){
            prev =temp;
            temp=temp->next;

        }
        prev->next=temp->next;
        delete temp;
        size--;

    }
    void Delete_by_value(int data){
         if(head==nullptr){ // which means the list is empty.
            cout<<"The linked list is emppty";
            return;
        }
        Node* temp = head;
        Node* prev = head;
        for(int i=0;i<size;i++){
            if(temp->value== data){
                prev->next= temp->next;
                delete temp;
                size--;
                return;
            }
            temp= temp->next;
        }
    }

    // Search function to find a node in the list
    bool search(int data) {
        Node* temp = head;
        while (temp != nullptr) {
            if (temp->value == data)
                return true;
            temp = temp->next; // move to the next node
        }
        return false;
    }

    // Display function to print the elements of the list
    void display() {
        Node* temp = head;
        while (temp != nullptr) {
            cout << temp->value << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    // Size function to return the number of elements in the list
    int getSize() {
        return size;
    }
};

int main() {
    LinkedList list;

    // Adding 10 nodes
    list.Add_to_tail(1);
    list.Add_to_tail(2);
    list.Add_to_tail(3);
    list.Add_to_tail(4);
    list.Add_to_tail(5);
    list.Add_to_tail(6);
    list.Add_to_tail(7);
    list.Add_to_tail(8);
    list.Add_to_tail(9);
    list.Add_to_tail(10);
    
    // Display the list
    cout << "List after adding 10 nodes: ";
    list.display();

     list.Delete_middle_node();
    cout << "List after deleting the middle node: ";
    list.display();

    // Deleting the head (first node)
    list.Delete_from_start();
    cout << "List after deleting the head: ";
    list.display();

    // Deleting the tail (last node)
    list.Delete_from_end();
    cout << "List after deleting the tail: ";
    list.display();

    // Deleting the middle node
   

    // Deleting at a specific position (e.g., position 3)
    list.Delete_at_position(3);
    cout << "List after deleting the node at position 3: ";
    list.display();

    // Deleting a node by value (e.g., value 5)
    list.Delete_by_value(5);
    cout << "List after deleting the node with value 5: ";
    list.display();

    // Searching for a value (e.g., value 7)
    bool found = list.search(7);
    cout << (found ? "Value 7 found in the list." : "Value 7 not found in the list.") << endl;

    // Displaying the final size of the list
    cout << "Final size of the list: " << list.getSize() << endl;

    return 0;
}
