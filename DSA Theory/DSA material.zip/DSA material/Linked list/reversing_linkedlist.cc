#include <iostream>
using namespace std;
class Node{
    public:
    int data;
    Node *next;
    Node(int data){
        this->data=data;
        this->next=nullptr;
    }
    Node():data(0),next(nullptr){}
    
};
class Linked_list{
    Node *head;
    int size;
    public:
     Linked_list() {
        head = nullptr;
        size = 0;
    }
    void display(){
        Node*temp=head;
        if(temp==nullptr){
            cout<<"Empyt list.\n";
            return;
        }
        while(temp!=nullptr){
            cout<<temp->data<<" ";
            temp=temp->next;
        }
        cout<<endl;
    }
    void Append(int data) {
        Node* newnode = new Node(data);
        if (head == nullptr)
            head = newnode;
        else {
            Node* temp = head;
            while (temp->next != nullptr)
                temp = temp->next;
            temp->next = newnode;
        }
        size++;
        cout << data << " added at the end of the list.\n";
    }

    // Prepend function to add a node at the beginning of the list
    void Prepend(int data) {
        Node* newnode = new Node(data);
        newnode->next = head;
        head = newnode;
        size++;
        cout << data << " added at the start of the list.\n";
    }

    // Delete function to remove a node from the list
    void Delete(int data) {
        if (head == nullptr) return; // this means the list is empty
        Node* temp = head;
        Node* prev = nullptr;
        while (temp != nullptr && temp->data != data) {
            prev = temp;
            temp = temp->next; // to traverse the next node
        }
        if (temp == nullptr) return; // this means the data was not found
        if (prev == nullptr) // the node to be deleted is the head node
            head = temp->next;
        else
            prev->next = temp->next;
        delete temp;
        size--;
        cout << "Deleted " << data << " from the list.\n";
    }

    // Search function to find a node in the list
    bool search(int data) {
        Node* temp = head;
        while (temp != nullptr) {
            if (temp->data == data)
                return true;
            temp = temp->next; // move to the next node
        }
        return false;
    }

    
    // Size function to return the number of elements in the list
    int getSize() {
        return size;
    }
    void reverse(){
        Node *prev=nullptr;
        Node *curr=head;
        Node *next_node=nullptr;
        if(!curr)
        cout<<"Empty list\n";
        while(curr!=nullptr){
            next_node=curr->next;
            curr->next=prev;
            prev=curr;
            curr=next_node;
        }
        head=prev;
        cout<<"reversing list.\n";
    
        
    }
};

int main(){
    Linked_list list;
    list.Append(1);
    list.Append(2);
    list.Append(3);
    list.Append(4);
    list.Append(5);
    list.display();
    list.reverse();
    list.display();

    

}