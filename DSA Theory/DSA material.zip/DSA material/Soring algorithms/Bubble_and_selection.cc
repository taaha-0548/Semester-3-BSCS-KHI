#include <iostream>
using namespace std;
// considering the resulting arrays to be sorted in non-decreasing order.
// first making a swap function, as both of the sorting alogirthms are comparision based.
void swap(int &a,int &b){
    int temp=a;
    a=b;
    b= temp;
} 
// In bubble sort, we sort by comparing adjacent elements sorting the last element on every traversal 

void bubble_sort(int *arr,int size){ 
    for(int i=0;i<size;i++){ 
        for(int j=0;j<size-i-1;j++){
            if(arr[j]>arr[j+1]){
               swap(arr[j],arr[j+1]);
            }
        }
    }
}
// In selection sort, we find the index of the minimum element and swap it with the first unsorted element 



void selection_sort(int *arr,int size){
    for(int i=0;i<size-1;i++){ // the condition works as when the loop reaches the last element it would already be sorted, so no need to to traverse for that
        int min=i;
        for(int j=i+1;j<size;j++){
            if(arr[j]<arr[i])
                min =j;
        }
        if(min!=i)
            swap(arr[i],arr[min]);

    }
}
void printArray(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}
int main() {
    int arr1[] = {64, 25, 12, 22, 11};
    int size1 = sizeof(arr1) / sizeof(arr1[0]);

    cout << "Original array for bubble sort: ";
    printArray(arr1, size1);

    bubble_sort(arr1, size1);
    cout << "Sorted array using bubble sort: ";
    printArray(arr1, size1);

    int arr2[] = {64, 25, 12, 22, 11};
    int size2 = sizeof(arr2) / sizeof(arr2[0]);

    cout << "Original array for selection sort: ";
    printArray(arr2, size2);

    selection_sort(arr2, size2);
    cout << "Sorted array using selection sort: ";
    printArray(arr2, size2);

    return 0;
}