#include <iostream>
#include <string>
using namespace std;
void Shell_sort(int *arr,int n){
    for(int gap=n/2;gap>0;gap/=2){
        for(int i=gap;i<n;i++){
            int key= arr[i];
            int j=i;
            for(j=i;j>=gap &&arr[j-gap]>key;j-=gap){
                arr[j]=arr[j-gap];
            }
            arr[j]=key;
        }
    }
}

void printArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main() {
    int arr[] = {12, 34, 54, 2, 3};
    int n = sizeof(arr) / sizeof(arr[0]);
    cout << "Original array: ";
    printArray(arr, n);

    Shell_sort(arr, n);

    cout << "Sorted array: ";
    printArray(arr, n);
    return 0;
}