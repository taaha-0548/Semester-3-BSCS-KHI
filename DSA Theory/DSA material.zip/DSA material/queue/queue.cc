#include <iostream>
#include <string>
using namespace std;

class Stack {
    int capacity, size, *arr, top;

public:
    Stack(int c) : capacity(c), size(0), top(-1) {
        arr = new int[capacity];
    }

    ~Stack() { // Destructor to free the allocated memory
        delete[] arr;
    }

    bool is_empty() {
        return size == 0;
    }

    bool is_full() {
        return size == capacity;
    }

    void push(int value) {
        if (is_full())
            return;
        arr[++top] = value;
        size++;
    }

    int pop() {
        if (is_empty())
            return -1;
        int popped_val = arr[top];
        top--;
        size--;
        return popped_val;
    }

    int peak() {
        if (is_empty())
            return -1;
        return arr[top];
    }

    int get_size() {
        return size;
    }

    int get_capacity() {
        return capacity;
    }

    void print_stack() {
        if (is_empty()) {
            cout << "Stack is empty." << endl;
            return;
        }
        cout << "Stack (top to bottom): ";
        for (int i = top; i >= 0; i--) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }

    Stack& operator=(const Stack& other) {
        if (this != &other) {
            delete[] arr;  // Clean up existing memory
            capacity = other.capacity;
            size = other.size;
            top = other.top;
            arr = new int[capacity];
            for (int i = 0; i <= top; ++i) {
                arr[i] = other.arr[i];
            }
        }
        return *this;
    }
};

class Queue {
    int front, rear, *arr, capacity, size;

public:
    Queue(int cap) : capacity(cap), size(0), front(0), rear(-1) {
        arr = new int[capacity];
    }

    ~Queue() { // Destructor to free the allocated memory
        delete[] arr;
    }

    bool is_full() {
        return size == capacity;
    }

    bool is_empty() {
        return size == 0;
    }

    void enqueue(int val) {
        if (is_full())
            return;
        arr[++rear] = val;
        size++;
    }

    int dequeue() {
        if (is_empty())
            return -1;
        int val = arr[front];
        front++;
        size--;
        return val;
    }

    void display() {
        if (is_empty()) {
            cout << "Queue is empty!" << endl;
            return;
        }
        for (int i = front; i <= rear; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }

    void reverse() {
        Stack stack(size); // Create a stack with the same size as the queue
        while (!is_empty()) {
            stack.push(dequeue()); // Dequeue from queue and push onto stack
        }
        while (!stack.is_empty()) {
            enqueue(stack.pop()); // Pop from stack and enqueue back to queue
        }
    }
};

int main() {
    Queue queue(5);
    queue.enqueue(1);
    queue.enqueue(2);
    queue.enqueue(3);
    queue.enqueue(4);
    queue.enqueue(5);

    cout << "Original Queue: ";
    queue.display();

    // Reverse the queue
    queue.reverse();
    cout << "Reversed Queue: ";
    queue.display();

    return 0;
}
