#include <iostream>
#include <string>
using namespace std;
class CircularQueue{
    int *arr;
    int front;
    int rear;
    int capacity;
    int curr_size;
    public:
    CircularQueue(int cap):capacity(cap),curr_size(0),front(0),rear(-1){
        arr = new int[ capacity];
    }
    bool is_full(){
        return curr_size==capacity;

    }
    bool is_empty(){
        return curr_size==0;
    }
    void enqueue(int data){
        if(is_full()){
            cout<<"Queue is full, cant nq.\n";
            return;
        }
        rear = (rear+1)% capacity;
        arr[rear]= data;
        curr_size++;
        cout<<data<<" enqueued.\n";
    }
    int dequeue(){
        if(is_empty()){
            cout<<"Queue is empty, cant dq.\n";
            return-1;
        }
        int dq= arr[front];
        front =(front+1)%capacity;
        curr_size--;
        return dq;
    }

};