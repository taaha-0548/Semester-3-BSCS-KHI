#include <iostream>
#include <string>
using namespace std;
class Node{
    public:
    int data;
    Node* next;
    Node(int val):data(val),next(nullptr){}
};
class Stack{
    Node*top;
    int count;
    public:
    Stack():top(nullptr){}
   
    bool isEmpty(){
        return top==nullptr;
    }
       ~Stack(){
        while(!isEmpty()){
            pop();
        }
    }
    //remove the top element from the stack.
    int pop(){
        if(isEmpty()){
            cout<<"Stack Underflow.\n";
            return -1;
        }
        int value=top->data;
        Node*temp=top;
        top=top->next;
        delete temp; // delete the top node.
        count--;
        return value;
    }
    //add element into the stack.
    void push(int data){
        Node* new_node= new Node(data);
        top->next=new_node;
        top =new_node;
        count++;
    }
    int peek(){
        if(isEmpty()){
            cout<<"Stack is empty.\n";
            return;
        }
        return top->data;
    }
    int get_size(){
        return count;
    }
    void display(){
        if(isEmpty()){
            cout<<"Stack is empty.\n";
        }
        Node* temp= top;
        while(temp){
            cout<<temp->data<<" ";
            temp= temp->next;

        }
        cout<<endl;
    }
};