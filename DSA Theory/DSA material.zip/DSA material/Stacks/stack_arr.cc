#include <iostream>
#include <string>
using namespace std;

class Stack {
    int *arr;
    int top; // index
    int capacity;
public:
    Stack(int cap) {
        arr = new int[cap];
        capacity = cap;
        top = -1;
    }
    ~Stack() {
        delete[] arr;
    }
    bool isFull() {
        return top == capacity - 1;
    }
    bool isEmpty() {
        return top == -1;
    }
    int get_size() {
        return top + 1;
    }
    // Insert an element into the stack.
    void push(int new_element) {
        if (isFull()) {
            cout << "Stack Overflow.\n";
            return;
        }
        arr[++top] = new_element;
    }
    // Remove the top element from the stack.
    int pop() {
        if (isEmpty()) {
            cout << "Stack Underflow.\n";
            return -1;
        }
        return arr[top--];
    }
    // Return the top element of the stack.
    int peek() {
        if (isEmpty()) {
            cout << "Stack is empty.\n";
            return -1;
        }
        return arr[top];
    }
    void display(){
        if(isEmpty()){
            cout<<"Stack is empty.\n";
            return;
        }
        for(int i=top;i>=0;i--){
        cout<<arr[i]<<" ";

        }
        cout<<endl;

    }
};

// Function to find the minimum and maximum values in the stack.
void find_min_and_max(Stack &stack) {
    if (stack.isEmpty()) {
        cout << "Stack is empty.\n";
        return;
    }

    int max = stack.peek();
    int min = stack.peek();
    Stack temp(stack.get_size()); // to keep track of popped elements

    while (!stack.isEmpty()){
        int value = stack.pop();
        if (value > max)
            max = value;
        if (value < min)
            min = value;
        temp.push(value);
    }

    // Restoring the elements back to the original stack.
    while (!temp.isEmpty()) {
        stack.push(temp.pop());
    }

    cout << "Minimum value in the stack: " << min << endl;
    cout << "Maximum value in the stack: " << max << endl;
}

// Function to move a single disk from one stack to another.
void move_disk(Stack &source, Stack &dest) {
    int disk = source.pop();
    dest.push(disk);
}

// Recursive function to solve Tower of Hanoi.
void TowerOfHanoi(int n, Stack &source, Stack &destination, Stack &auxiliary) {
    if (n == 1) {
        move_disk(source, destination);
        return;
    }
    TowerOfHanoi(n - 1, source, auxiliary, destination);
    move_disk(source, destination);
    TowerOfHanoi(n - 1, auxiliary, destination, source);
}

int main() {
    // Test find_min_and_max
    Stack stack1(10);
    stack1.push(5);
    stack1.push(3);
    stack1.push(8);
    stack1.push(1);
    stack1.push(7);
    stack1.display();
    cout << "Testing find_min_and_max function:" << endl;
    find_min_and_max(stack1);

    // Test Tower of Hanoi
    int num_of_disks;
    cout << "\nEnter the number of disks for Tower of Hanoi: ";
    cin >> num_of_disks;

    Stack source(num_of_disks);
    Stack auxiliary(num_of_disks);
    Stack destination(num_of_disks);

    // Initialize the source rod with disks in decreasing order.
    for (int i = num_of_disks; i >= 1; i--) {
        source.push(i);
    }
    cout<<"Source stack: ";
        source.display();
    cout<<"Destination stack: ";
  
    destination.display();
    cout << "\nPerforming Tower of Hanoi with " << num_of_disks << " disks:" << endl;
    TowerOfHanoi(num_of_disks, source, destination, auxiliary);
    cout<<"Source stack: ";
    source.display();
    cout<<"Destination stack: ";
    destination.display();
    return 0;
}
