#include <iostream>
#include <string>
#include <queue> // for bfs
#include <stack> // for dfs
using namespace std;
class Graph{
    int no_of_vertices;
    int **adjacency_matrix;
    public:
    Graph(int n):no_of_vertices(n){
        adjacency_matrix = new int *[no_of_vertices];
        for(int i=0;i<no_of_vertices;i++){
            adjacency_matrix[i]= new int[no_of_vertices];
            for(int j=0;j<no_of_vertices;j++){
                adjacency_matrix[i][j]=0; //initialize with 0 
            }
        }
    }

    void add_edge(int u,int v){ // adding an edge from U to V (0 based)
        adjacency_matrix[u][v]=1;
        
        
    }
    void remove_edge(int u,int v){
        adjacency_matrix[u][v]=0;
        
    }
    void display_matrix(){
        for(int i=0;i<no_of_vertices;i++){
            for(int j=0;j<no_of_vertices;j++){
                cout<<adjacency_matrix[i][j]<<" ";
            }
            cout<<endl;
        }
        cout<<endl;
    }
    // add a destructor if necessary.
     void display_list() {
         for (int i = 0; i < no_of_vertices; i++) {
            cout << i << " --> ";
            for (int j = 0; j < no_of_vertices; j++) {
                if (adjacency_matrix[i][j] == 1) {
                    cout << j << " ";
                }
            }
            cout << endl;
    }
     }
     void bfs(int start_vertex){
        bool *visited = new bool [no_of_vertices];
        for(int i=0;i<no_of_vertices;i++){
            visited[i]=false;
        }
        queue<int>q;
        // first visit the starting vertex
        visited[start_vertex]= true;
        q.push(start_vertex);
        cout<<"BFS Traversal:\n";
        while(!q.empty()){
            int curr=q.front();
            q.pop();
            cout<<curr<<" ";
            // now visit the univisited neighbours
            for(int i=0;i<no_of_vertices;i++){
                if(adjacency_matrix[curr][i]==1 &&!visited[i]){ // if there exist an edge between the current vertex and unvisited ith vertex
                visited[i]= true; // marks as visited.
                q.push(i); // enqueue;
                }
            }
            
        }
        cout<<endl;
     }
     void dfs(int start_vertex){
        bool *visited = new bool [no_of_vertices];
        for(int i=0;i<no_of_vertices;i++){
            visited[i]=false;
        }
        stack<int>s;
        // first visit the starting vertex
        visited[start_vertex]= true;
        s.push(start_vertex);
        cout<<"DFS Traversal:\n";
        while(!s.empty()){
            int curr=s.top();
            s.pop();
            cout<<curr<<" ";
            // now visit the univisited neighbours
            for(int i=0;i<no_of_vertices;i++){
                if(adjacency_matrix[curr][i]==1 &&!visited[i]){ // if there exist an edge between the current vertex and unvisited ith vertex
                visited[i]= true; // marks as visited.
                s.push(i); // push into the stack;
                }
            }
            
        }
        cout<<endl;
     }
};
int main(){
   
    Graph graph(7);
    graph.add_edge(0,1);
       graph.add_edge(0,6);
    graph.add_edge(1,2);
    graph.add_edge(2,3);
    graph.add_edge(1,5);
    graph.add_edge(2,4);
  
      graph.add_edge(4,3);
     graph.add_edge(5,4);
      graph.add_edge(6,5);

    
   
    graph.display_matrix();
    graph.display_list();
    graph.bfs(0);
    graph.dfs(0);

}