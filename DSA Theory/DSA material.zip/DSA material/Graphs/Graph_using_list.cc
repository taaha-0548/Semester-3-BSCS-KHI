#include <iostream>
#include <string>
using namespace std;
class Node{
    public:
    int vertex;
    Node *next;
    Node(int v):vertex(v),next(nullptr){}
};
class Graph{
    int no_of_vertices;
    Node** adjacency_list;
    public:
    Graph(int n):no_of_vertices(n){
     
            adjacency_list=new Node*[no_of_vertices];
            for(int i=0;i<no_of_vertices;i++){
                adjacency_list[i]=nullptr; // initializing each list as empty linked lists
            }
        
    }
    void add_edge(int u,int v ){
        // Add node `v` to adjacency list of `u`
        Node* new_node = new Node(v);
        new_node->next = adjacency_list[u];
        adjacency_list[u] = new_node;

        // Add node `u` to adjacency list of `v` (for an undirected graph)
        new_node = new Node(u);
        new_node->next = adjacency_list[v];
        adjacency_list[v] = new_node;
    }
      // Print adjacency list representation
    void print() {
        for (int i = 0; i < no_of_vertices; i++) {
            cout << i << " --> ";
            Node* temp = adjacency_list[i]; // Pointer to traverse the linked list
            while (temp != nullptr) {
                cout << temp->vertex << " ";
                temp = temp->next;
            }
            cout << endl;
        }
    }
};
int main(){
int V = 5; // Number of vertices
    Graph graph(V);

    // Adding edges
    graph.add_edge(0, 1);
    graph.add_edge(0, 4);
    graph.add_edge(1, 2);
    graph.add_edge(1, 3);
    graph.add_edge(1, 4);

    cout << "Adjacency List Representation:\n";
    graph.print();
    
    }