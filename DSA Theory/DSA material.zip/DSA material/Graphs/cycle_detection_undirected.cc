#include <bits/stdc++.h>
using namespace std;

// Function to detect cycle using DFS, accounting for the parent node
bool isCyclicConnected(int** adj, bool* visited, int V, int v, int parent) {
    visited[v] = true;

    // Visit all adjacent nodes of the curre ntnode
    for (int i = 0; i < V; i++) {
        if (adj[v][i] == 1) {  // Check if there's an edge between v and i
            if (!visited[i]) {  // If the neighbor hasn't been visited yet
                if (isCyclicConnected(adj, visited, V, i, v))
                    return true;
            } else if (i != parent) {  // If the neighbor is visited and is not the parent, cycle is found
                return true;
            }
        }
    }

    return false;  // No cycle detected from this node
}

// Function to detect cycle in an undirected graph
bool isCycle(int** adj, int V) {
    bool* visited = new bool[V]();  // Mark all vertices as not visited (dynamically allocated array)

    // Check all vertices
    for (int i = 0; i < V; i++) {
        if (!visited[i]) {
            if (isCyclicConnected(adj, visited, V, i, -1)) {
                delete[] visited;  // Free dynamically allocated memory
                return true;  // Cycle detected
            }
        }
    }

    delete[] visited;  // Free dynamically allocated memory
    return false;  // No cycle detected
}

int main() {
    // Number of vertices
    int V = 5;

    // Dynamically allocate adjacency matrix (5x5 for 5 vertices)
    int** adj = new int*[V];
    for (int i = 0; i < V; i++) {
        adj[i] = new int[V]();  // Initialize all values to 0
    }

    // Add edges to form the graph: 0-1, 1-2, 2-3, 3-4, 4-0 (Cycle)
    adj[0][1] = adj[1][0] = 1;
    adj[1][2] = adj[2][1] = 1;
    adj[2][3] = adj[3][2] = 1;
    adj[3][4] = adj[4][3] = 1;
    adj[4][0] = adj[0][4] = 1;  // Adding the edge that completes the cycle

    // Call the function to detect cycle
    bool ans = isCycle(adj, V);

    // Output the result
    if (ans)
        cout << "1\n";  // Cycle found
    else
        cout << "0\n";  // No cycle found

    // Free dynamically allocated memory for adjacency matrix
    for (int i = 0; i < V; i++) {
        delete[] adj[i];
    }
    delete[] adj;

    return 0;
}
