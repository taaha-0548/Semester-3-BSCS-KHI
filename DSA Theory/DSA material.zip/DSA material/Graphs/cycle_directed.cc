#include <bits/stdc++.h>
using namespace std;

// Function to detect cycle using DFS, using a recursion stack
bool isCyclicConnected(int** adj, bool* visited, bool* recursionStack, int V, int v) {
    visited[v] = true;
    recursionStack[v] = true;  // Mark the node as part of the current DFS path

    // Visit all adjacent nodes of the current node
    for (int i = 0; i < V; i++) {
        if (adj[v][i] == 1) {  // Check if there's a directed edge from v to i
            if (!visited[i]) {  // If the neighbor hasn't been visited yet
                if (isCyclicConnected(adj, visited, recursionStack, V, i))
                    return true;
            } else if (recursionStack[i]) {  // If the neighbor is already in the recursion stack, cycle is found
                return true;
            }
        }
    }

    recursionStack[v] = false;  // Remove the node from the recursion stack as we backtrack
    return false;
}

// Function to detect cycle in a directed graph
bool isCycle(int** adj, int V) {
    bool* visited = new bool[V]();         // Mark all vertices as not visited (dynamically allocated array)
    bool* recursionStack = new bool[V]();  // To keep track of nodes in the current DFS path

    // Check all vertices
    for (int i = 0; i < V; i++) {
        if (!visited[i]) {
            if (isCyclicConnected(adj, visited, recursionStack, V, i)) {
                delete[] visited;         // Free dynamically allocated memory
                delete[] recursionStack;  // Free dynamically allocated memory
                return true;  // Cycle detected
            }
        }
    }

    delete[] visited;         // Free dynamically allocated memory
    delete[] recursionStack;  // Free dynamically allocated memory
    return false;  // No cycle detected
}

int main() {
    // Number of vertices
    int V = 5;

    // Dynamically allocate adjacency matrix (5x5 for 5 vertices)
    int** adj = new int*[V];
    for (int i = 0; i < V; i++) {
        adj[i] = new int[V]();  // Initialize all values to 0
    }

    // Add edges to form a directed graph: 0 -> 1, 1 -> 2, 2 -> 3, 3 -> 4, 4 -> 2 (Cycle)
    adj[0][1] = 1;  // 0 -> 1
    adj[1][2] = 1;  // 1 -> 2
    adj[2][3] = 1;  // 2 -> 3
    adj[3][4] = 1;  // 3 -> 4
    adj[4][2] = 1;  // 4 -> 2 (Cycle here)

    // Call the function to detect cycle
    bool ans = isCycle(adj, V);

    // Output the result
    if (ans)
        cout << "1\n";  // Cycle found
    else
        cout << "0\n";  // No cycle found

    // Free dynamically allocated memory for adjacency matrix
    for (int i = 0; i < V; i++) {
        delete[] adj[i];
    }
    delete[] adj;

    return 0;
}
