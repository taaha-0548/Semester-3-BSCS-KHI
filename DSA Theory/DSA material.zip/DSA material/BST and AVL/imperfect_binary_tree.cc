#include <iostream>
using namespace std;

// Definition for a binary tree node.
class TreeNode {
    public:
    int val;
    TreeNode *left;
    TreeNode *right;
    
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};

int valid_height(TreeNode* head)
{
    if (head == NULL)
        return -1; 
     
      int h_left = valid_height(head->left);
    int h_right = valid_height(head->right);
    
     
     if ((head->left && head->val > head->left->val) || 
        (head->right && head->val > head->right->val)) {
            cout<<"violation"<<endl;
       
    return max(h_left,h_right);  
}
return 1+ max(h_left,h_right);
}

TreeNode* createTree() {
    TreeNode* root = new TreeNode(14);
    root->left = new TreeNode(34);
    root->right = new TreeNode(27);
    root->right->left = new TreeNode(54);
    root->right->left->left = new TreeNode(56);
    root->right->left->right = new TreeNode(89);
    root->right->right = new TreeNode(30);
    root->left->left = new TreeNode(40);
    root->left->right = new TreeNode(37);
    root->left->right->left = new TreeNode(21);
    root->left->right->right = new TreeNode(39);
    root->left->left->left = new TreeNode(13);
    root->left->left->right = new TreeNode(59);
    return root;
}

int main() {
  
    TreeNode* root = createTree();
  cout<<  valid_height(root);   
 

    

    return 0;
}
