#include <iostream>
#include <string>
using namespace std;
class TreeNode{
    public:
    int data;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int d=0):data(d),left(nullptr),right (nullptr){}
};
class BST{
    TreeNode *root;
    public:
    BST():root(nullptr){}
    TreeNode* insert_node(TreeNode*root,int val){
        if(!root)
        return new TreeNode(val);
        if(val>root->data){
        root->right = insert_node(root->right,val);
        }
        else if (val<root->data){
            root->left =insert_node(root->left,val);

        }
        return root;
    }
    TreeNode* second_largest(TreeNode* root){
        if(!root || !root->right) // if empty or single element then no second largest exist
            return nullptr;
        
        TreeNode *curr =root;
        TreeNode *parent=nullptr;
        while(curr->right){
            parent= curr;
            curr=curr->right; //to move to the largest element
        }
        // curr now has the largest element
        // case 1: if the curr doesnt have a left child then parent must be the second largest
        if(!curr->left)
            return parent;
        // case 2: if curr exist then the right most of the curr.left is the second largest
        TreeNode* second =curr->left;
        while(second->right){
            second= second->right;
        }
        return second;
    }
    void Insert(int val){
        root =insert_node(root,val);
    }
    void find_second_largest(){
        TreeNode* s_largest= second_largest(root);
        cout<<s_largest->data<<endl;
    }
};
int main(){
    BST tree;
    tree.Insert(15);
    tree.Insert(10);
    tree.Insert(24);
    tree.Insert(16);
    tree.Insert(19);
    tree.Insert(18);
    tree.find_second_largest();
    
}