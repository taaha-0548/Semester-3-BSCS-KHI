#include <iostream>
#include <algorithm>
using namespace std;
class TreeNode{
    public:
    int data;
    TreeNode*left;
    TreeNode *right;
    TreeNode(int d=0):data(d),left(nullptr),right(nullptr){}
};
    int count_nodes(TreeNode *root){
        if(!root)
            return 0;
        return 1+ count_nodes(root->left)+count_nodes(root->right);
    }
    void store_in_arr(TreeNode *node,int arr[],int &index){
        if(!node )
            return;
        store_in_arr(node->left,arr,index);
        arr[index++]=node->data;
        store_in_arr(node->right,arr,index);
        
    }
    TreeNode *sorted_array_to_bst(int arr[],int start,int end){
        if(start>end)
            return nullptr;
        int mid= start+ (end-start)/2;
        TreeNode *node = new TreeNode(arr[mid]);
        node->left= sorted_array_to_bst(arr,start,mid-1);
        node->right=sorted_array_to_bst(arr,mid+1,end);
        return node;
    }
     void inorderTraversal(TreeNode* node) {
        if (node != nullptr) {
            inorderTraversal(node->left);
            cout << node->data << " ";
            inorderTraversal(node->right);
        }
    }
    void create_bst_from_bt(TreeNode *&root){
        int n =count_nodes(root);
        int *arr =new int [n];
       int index=0;
        store_in_arr(root,arr,index);
         sort(arr, arr + n);
        root = sorted_array_to_bst(arr,0,n-1);
    }

int main(){
    TreeNode* root = new TreeNode(10);
    root->left = new TreeNode(15);
    root->right = new TreeNode(3);
    root->left->left = new TreeNode(5);
    root->left->right = new TreeNode(21);
    root->right->left = new TreeNode(18);
    root->right->right = new TreeNode(7);
    inorderTraversal(root);
    cout<<endl;
    create_bst_from_bt(root);
    inorderTraversal(root);




}