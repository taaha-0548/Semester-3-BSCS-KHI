#include <iostream>
#include <string>
using namespace std;
class TreeNode{
    public:
    int data;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int d=0):data(d),left(nullptr),right (nullptr){}
};
class BST{
    TreeNode *root;
    public:
    BST():root(nullptr){}
    TreeNode* insert_node(TreeNode*root,int val){
        if(!root)
        return new TreeNode(val);
        if(val>root->data){
        root->right = insert_node(root->right,val);
        }
        else if (val<root->data){
            root->left =insert_node(root->left,val);

        }
        return root;
    }
    TreeNode *kth_largest(TreeNode *root,int &k){
        // doing reverse in order to go in descending
        if(!root)
            return nullptr;
        TreeNode *right = kth_largest(root->right,k);
        if(right)
            return right;

        k--;
        if(k==0)
            return root;
        
        return kth_largest(root->left,k);

    }
    
    void Insert(int val){
        root =insert_node(root,val);
    }
    void find_kth_largest (int k){
        int k2=k;
        TreeNode *kth= kth_largest(root,k2);
      
        cout<<k<<"th largest: "<<kth->data;
    }
};
int main(){
    BST tree;
    tree.Insert(15);
    tree.Insert(10);
    tree.Insert(24);
    tree.Insert(16);
    tree.Insert(19);
    tree.Insert(18);
    tree.find_kth_largest(4);
    
}