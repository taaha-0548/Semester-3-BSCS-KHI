#include <iostream>
using namespace std;

class Array {
    int* data;  // Pointer to dynamic array
    int size;   // Size of the array

public:
    // Constructor to initialize array with a given size
    Array(int s) : size(s), data(new int[s]) {
        for (int i = 0; i < size; ++i) {
            data[i] = 0;  // Initialize all elements to 0
        }
        cout << "Array of size " << size << " created." << endl;
    }

    // Destructor to release dynamic memory
    ~Array() {
        delete[] data;
        cout << "Array of size " << size << " destroyed." << endl;
    }

    // Copy constructor (Deep copy)
    Array(const Array& other) : size(other.size), data(new int[other.size]) {
        for (int i = 0; i < size; ++i) {
            data[i] = other.data[i];
        }
        cout << "Array copied." << endl;
    }

    // Copy assignment operator (Deep copy)
    Array& operator=(const Array& other) {
        if (this == &other) return *this;  // Handle self-assignment

        // Release old memory
        delete[] data;

        // Allocate new memory and copy elements
        size = other.size;
        data = new int[size];
        for (int i = 0; i < size; ++i) {
            data[i] = other.data[i];
        }
        cout << "Array assigned." << endl;
        return *this;
    }

    // Boundary checker to ensure index is within valid bounds
    bool boundaryChecker(int index) const {
        return (index >= 0 && index < size);
    }

    // Safe array access (with bounds checking)
    int& operator[](int index) {
        if (!boundaryChecker(index)) {
            cout << "Error: Index " << index << " out of bounds." << endl;
            // Return a reference to a static dummy variable to prevent crashes
            static int dummy = -1;
            return dummy;
        }
        return data[index];
    }

    // Function to get the size of the array
    int getSize() const {
        return size;
    }

    // Function to print array elements
    void printArray() const {
        for (int i = 0; i < size; ++i) {
            cout << data[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    Array arr1(5);  // Create an array of size 5
    arr1[2] = 10;   // Set value at index 2
    arr1.printArray();  // Print array

    arr1[6] = 20;   // Attempt to access out-of-bounds index

    Array arr2 = arr1;  // Copy constructor
    arr2.printArray();  // Print copied array

    Array arr3(3);
    arr3 = arr1;  // Copy assignment
    arr3.printArray();

    return 0;
}
