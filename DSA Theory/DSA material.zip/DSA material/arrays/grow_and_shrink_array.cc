#include <iostream>

using namespace std;
void grow_array(int *&arr,int &size,int n){ // increase the array size by n.
    int *temp = new int[n+size];
    for(int i=0;i<size;i++){
        temp[i]=arr[i];
    }
    for(int i=size;i<size+n;i++){ // initialize new elements to 0.
        temp[i]=0;
    }
    delete []arr;
    arr= temp;
    size+=n;
}
void shrink_array(int *&arr,int &size,int n){ //to shrink the array by n.
    if(size==n){ // if the size and n are equal then the size will become zero
        delete[]arr;
        arr=nullptr;
        size=0;
        return;}
    else if(size<n){ // if n> size, we cant shrink the array.
        cout<<"Not possible.\n";
        return;
    }
    else{
        int *temp= new int[size-n]; // the new size will become size-n
        for(int i=0;i<size-n;i++){
            temp[i]=arr[i];
        }
        delete []arr;
        arr= temp;
        size-=n;
    }

}
void print_arr(int *arr,int size){
    for(int i=0;i<size;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}
int main(){
    int *arr= new int[6];
    int size=6;
    for(int i=0;i<6;i++){
        arr[i]=i+1;
    }
    print_arr(arr,size);

    grow_array(arr,size,3);
    print_arr(arr,size);
    shrink_array(arr,size,4);
    print_arr(arr,size);


}