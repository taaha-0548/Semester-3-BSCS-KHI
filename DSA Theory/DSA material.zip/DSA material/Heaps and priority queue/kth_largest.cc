#include <iostream>
#include <string>
using namespace std;
void max_heapify(int *arr,int n,int index){
    int largest = index;
    int left= 2*index +1;
    int right= 2*index+2;
    if(left<n && arr[left]>arr[largest])
        largest= left;
    if(right<n && arr[right]>arr[largest])
        largest=right;
    if(index!=largest){
        swap(arr[index],arr[largest]);
        max_heapify(arr,n,largest);
    }

}
void build_max_heap(int *arr,int n ){
    for(int i=n/2-1;i>=0;i--){
        max_heapify(arr,n,i);
    }

}
int kth_largest(int *arr,int n,int k){
   build_max_heap(arr,n);
   for(int i=0;i<k-1;i++){
    swap(arr[0],arr[n-1]);
    n--;
    max_heapify(arr,n,0);
   }
   return arr[0];
}
int main() {
    int arr[] = {3, 2, 1, 5, 6, 4};
    int n = sizeof(arr) / sizeof(arr[0]);
    int k = 2;

    int result = kth_largest(arr, n, k);

    cout << "The " << k << "-th largest element is: " << result << endl;

    return 0;
}