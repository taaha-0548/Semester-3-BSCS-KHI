#include <iostream>
#include <string>
using namespace std;
class Maal{
    public:
    string data;
    int priority;
    Maal(string d="",int p=-1):data(d),priority(p){}

};
class MaxHeap{
    Maal *arr;
    int capacity;
    int size;

    public:
    MaxHeap(int c):capacity(c),size(0){
        arr= new Maal[capacity];
    }
    void heapify_down(int index){
        int largest= index;
        int prior= arr[index].priority;
        int left= 2*index+1;
        int right =2*index+2;
        if(left<size&& arr[left].priority>prior)
            largest= left;
        prior= arr[index].priority;
        if(right<size &&arr[right].priority>prior)
            largest =right;
        if(largest!=index){
            swap(arr[largest],arr[index]);
            heapify_down(largest);
        }
    }

    void heapify_up(int index){
        while(index>0){
            int parent= (index-1)/2;
            if(arr[index].priority>arr[parent].priority)
            swap(arr[index],arr[parent]);
            else return ;
            index= parent;
        }
    }
    void insert(string str,int p){
        Maal maal(str,p);
        arr[size]=maal;
        heapify_up(size);
        size++;
      display();
    }
    void remove(){ // removing hte top element.
        if(size==0)
            return;
        swap(arr[0],arr[size-1]);
        size--;
        heapify_down(0);
display();

    }

    void change_priority(string d,int new_priority){
        int index=-1;
        for(int i=0;i<size;i++){
            if(arr[i].data==d){
                index=i;
                break;
            }
        }
        if(index==-1){
            cout<<"maal was not found\n";
            return;
        }
        int old= arr[index].priority;
        arr[index].priority=new_priority;
        if(new_priority>old)
            heapify_up(index);
        else heapify_down(index);
        
        display();
    }
    
    void display() {
        for (int i = 0; i < size; i++) {
            cout << arr[i].data << " (Priority: " << arr[i].priority << ")\n";
        }
        cout<<endl<<endl;
    }
};
int main(){
    MaxHeap mh(5);
    mh.insert("Appal",12);
    mh.insert("Kela",15);
    mh.insert("angoor",2);
    mh.insert("charas",5);
    mh.display();
    mh.change_priority("Kela",4);
    
    mh.remove();
 

}