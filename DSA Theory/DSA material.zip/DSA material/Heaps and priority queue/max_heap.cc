#include <iostream>
using namespace std;

class MaxHeap {
    int* heap;
    int capacity;
    int size; // current size of the max heap

    void heapify_up(int index) {
        while (index > 0) {
            int parent = (index - 1) / 2;
            if (heap[index] > heap[parent]) {
                swap(heap[index], heap[parent]);
                index = parent;
            } else {
                return;
            }
        }
    }

    void heapify_down(int index) {
        int largest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < size && heap[left] > heap[largest])
            largest = left;
        if (right < size && heap[right] > heap[largest])
            largest = right;

        if (largest != index) {
            swap(heap[index], heap[largest]);
            heapify_down(largest);
        }
    }

public:
    MaxHeap(int cap = 10) : capacity(cap), size(0) {
        heap = new int[capacity];
    }

    ~MaxHeap() {
        delete[] heap;
    }

    void insert(int value) {
        if (size == capacity) {
            // Double the capacity if needed
            capacity *= 2;
            int* new_heap = new int[capacity];
            for (int i = 0; i < size; i++) {
                new_heap[i] = heap[i];
            }
            delete[] heap;
            heap = new_heap;
        }
        heap[size] = value;
        heapify_up(size);
        size++;
    }

    void remove_max() {
        if (size == 0) {
            cout << "Heap is empty.\n";
            return;
        }
        swap(heap[0], heap[size - 1]);
        size--; // remove the last element
        heapify_down(0);
        for (int i = 0; i < size; i++) {
            cout << heap[i] << " ";
        }
        cout << endl;
    }

    void remove(int value) {
        if (size == 0) {
            cout << "Heap is empty.\n";
            return;
        }
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (heap[i] == value) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            cout << "Value not found\n";
            return;
        }
        swap(heap[index], heap[size - 1]);
        size--;
        heapify_down(index);
        for (int i = 0; i < size; i++) {
            cout << heap[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    MaxHeap max_heap;
    max_heap.insert(5);
    max_heap.insert(4);
    max_heap.insert(3);
    max_heap.insert(2);
    max_heap.insert(1);

    max_heap.remove(3); // Remove 3 from the heap
    max_heap.remove_max(); // Remove the maximum element
}
