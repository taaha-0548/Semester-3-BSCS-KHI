#include <iostream>
#include <string>
using namespace std;
class Kth_largest{
    int *heap;
    int k; //capacity
    int size;
    void heapify_up(int index){
        while(index>0){
            int parent= (index-1)/2;
            if(heap[index]<heap[parent]){
                swap(heap[index],heap[parent]);
                index=parent;
            }
            else return;
        }
    }
    void heapify_down(int index){
        int smallest =index;
        int left= 2*index+1;
        int right=2*index+2;
        if(left<size && heap[left]<heap[smallest])
            smallest =left;
        if(right<size && heap[right]<heap[smallest])
            smallest =right;
        if(smallest!= index){
            swap(heap[smallest],heap[index]);
            heapify_down(smallest);
        }
    }
    public:
    Kth_largest (int *arr,int k,int s){
     heap = new int [k];
     k=k;
     size=s;
     for(int i=0;i<k;i++){
        add(arr[i]);
     }
    }
    public:
    int add(int val){
        if(size<k){
            heap[size]=val;
            heapify_up(size);
            size++;
        }else if(val >heap[0]){
            heap[0]=val;
            heapify_down(0);
        }
        return heap[0];
    }
};