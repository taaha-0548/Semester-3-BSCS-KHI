#include <iostream>
using namespace std;
class MinHeap{
    int *heap;
    int capacity;
    int size; // current size of the min heap.
    void heapify_up(int index){
        while(index>0){
            int parent= (index-1)/2;
            if(heap[index]<heap[parent]){
                swap(heap[index],heap[parent]);
                index=parent;
               
            }
            else return;
        }
    }
    void heapify_down(int index){
        int smallest =index;
        int left= 2*index+1;
        int right=2*index+2;
        if(left<size && heap[left]<heap[smallest])
            smallest =left;
        if(right<size && heap[right]<heap[smallest])
            smallest =right;
        if(smallest!= index){
            swap(heap[smallest],heap[index]);
            heapify_down(smallest);
        }
    }
    public:
    MinHeap(int cap=10):capacity(cap),size(0){
        heap = new int [capacity];
    }
  
    ~MinHeap(){
        delete[] heap;
    }

    
    void insert(int value){
        if(size==capacity){
            // doubly the capacity if needed
            capacity*=2;
            int *new_heap= new int [capacity];
            for(int i=0;i<size;i++){
                new_heap[i]=heap[i];
            }
            delete[] heap;
            heap=new_heap;
        }
        heap[size]=value;
        heapify_up(size);
        size++;
         for(int i=0;i<size;i++){
                    cout<<heap[i]<<" ";
                }
                cout<<endl;
      
    }
    void remove_min(){
        if(size==0){
        cout<<"Heap is empty.\n";
        return;
        }
        swap(heap[0],heap[size-1]);
        size--; // remove the last element
        heapify_down(0);
        for(int i=0;i<size;i++){
            cout<<heap[i]<<" ";
        }
        cout<<endl;
    }
    void remove(int value){
        if(size==0){
            cout<<"Heap is empty.\n";
            return;
        }
        int index=-1;
        for(int i=0;i<size;i++){
            if(heap[i]==value){
                index= i;
                break;
            }
        }
        if(index==-1){
            cout<<"value not found\n";
            return;
        }
        swap(heap[index],heap[size-1]);
        size--;
        heapify_down(index);
        for(int i=0;i<size;i++){
            cout<<heap[i]<<" ";

        }
        cout<<endl;
    }
};
int main(){
   
    MinHeap min_heap;
    min_heap.insert(5);
    min_heap.insert(4);
    min_heap.insert(3);
    min_heap.insert(2);
    min_heap.insert(1);    
   
   
   
}