#include <iostream>
using namespace std;

// Function to heapify a subtree rooted at index `i` in a Min Heap
void minHeapify(int arr[], int n, int i) {
    int smallest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] < arr[smallest])
        smallest = left;

    if (right < n && arr[right] < arr[smallest])
        smallest = right;

    if (smallest != i) {
        swap(arr[i], arr[smallest]);
        minHeapify(arr, n, smallest);
    }
}
// sort in descending.
void minHeapSort(int arr[], int n) {
    // Build Min Heap
    for (int i = n / 2 - 1; i >= 0; i--) {
        minHeapify(arr, n, i);
    }
    cout<<"Min heap:\n"<<endl;
    for (int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;

    // Extract elements from heap one by one
    for (int i = n - 1; i >= 0; i--) {
        swap(arr[0], arr[i]); // Move current root to end
        minHeapify(arr, i, 0); // Heapify reduced heap
    }
}

int main() {
    int arr[] = {40,20,10,6,3,5,4};
    int n = sizeof(arr) / sizeof(arr[0]);

    minHeapSort(arr, n);

    cout << "Min Heap Sorted array: ";
    for (int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;
    return 0;
}
