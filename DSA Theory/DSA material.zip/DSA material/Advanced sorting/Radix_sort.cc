#include <iostream>
#include <string>
using namespace std;
void counting_sort(int *arr,int n,int exp){
    int output[n];
    int count[10]={0}; // for counting occurrences of digits.
   
   //Step 1: count the occurences of each digit.
    for( int i=0;i<n;i++){
        int digit=(arr[i]/exp)%10; // finding the digit
        count[digit]++;
    }
    //Step 2: modify the array by adding the counts to the next element of the count array.
    for(int i=1;i<10;i++){
        count[i]+=count[i-1]; 
    }
    //Step3: Place the elements in the sorted order in the output array.
    for(int i=n-1;i>=0;i--){
        int digit=(arr[i]/exp)%10;
        output[count[digit]-1]=arr[i];
        count[digit]--;
    }
    // Step 4: Copy the sorted numbers from output[] back to arr[]
    for (int i = 0; i < n; i++) {
        arr[i] = output[i];
    }
}
void radix_sort(int *arr,int n){
    int max=arr[0];
    for(int i=0;i<n;i++){
        if(arr[i]>max)
            max=arr[i];
    }
    for(int exp=1;max/exp>0;exp*=10){ // it will run n number of times, where n= number of digits the max values has.

        // using count sort on each digit (ones,100s,1000s,etc)
        counting_sort(arr,n,exp);
    }


}
int main() {
    int arr[] = {170, 45, 75, 90, 802, 24, 2, 66};  // Example array to be sorted
    int n = sizeof(arr) / sizeof(arr[0]);  // Calculate the size of the array

    // Print the original array
    cout << "Original array: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";  // Print each element of the array
    }
    cout << endl;

    // Call radix_sort to sort the array
    radix_sort(arr, n);

    // Print the sorted array
    cout << "Sorted array: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";  // Print each element of the sorted array
    }
    cout << endl;

    return 0;
}