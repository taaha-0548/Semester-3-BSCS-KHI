#include <iostream>
#include <string>
using namespace std;
class Node{
    public:
    string word;
    Node*next;
    Node(string s):word(s),next(nullptr){}
    Node():word(""),next(nullptr){}
};
class Dictionary{
    Node* dict[100];
    const int capacity=100;
    int hashing_function(string s){
        int sum=0;
        for(int i=0;i<capacity;i++){
            sum+=s[i];
        }
        return sum %capacity;
    }
    public:
    Dictionary(int size = 100) : capacity(size) {
        for (int i = 0; i < capacity; i++) {
            dict[i] = nullptr;
        }
    }
    void insert(string word){
        int index= hashing_function(word);
        Node *new_node= new Node(word);
        new_node->next= dict[index];
        dict[index]= new_node;
        
    }
    bool search(string word){
        int index= hashing_function(word);
        Node*curr =dict[index];
        while(curr){
            if(curr->word== word)
                return true;
            curr=curr->next;
        }
        cout<<"Not found\n";
        return false;

    }
    void remove(string word){
        int index= hashing_function(word);
        Node* curr = dict[index];
        Node* prev= nullptr;
        while(curr){
            if(curr->word== word){
                if(prev){
                    prev->next= curr->next;
                }
                else 
                dict[index]=curr->next;
                delete curr;
                return;
            }
            prev= curr;
            curr = curr->next;
        }
    }
    void display(){
        for(int i=0;i<capacity;i++){
            cout<<"Bucket #"<<i+1<<": ";
            Node*curr =dict[i];
            while(curr){
                cout<<curr->word<<" ";
                curr=curr->next;
            }
            cout<<endl;
        }
        cout<<endl;
    }
};
int main(){
    Dictionary dictionary;
  dictionary.insert("Sarah Jones");
dictionary.insert("John Smith");
dictionary.insert("Tony Balgonie");
dictionary.insert("Tom Katz");
dictionary.display();
}