#include <iostream>
using namespace std;

class HashTable {
    int* table;           // Array for storing keys
    bool* is_deleted;     // Array to track deleted slots
    int bucket_count;     // Number of buckets in the table
    int num_elements;     // Current number of elements in the table

    // Hash function 1
    int hash_function1(int key) {
        return key % bucket_count;
    }

    // Helper function to check if a number is prime
    bool is_prime(int num) {
        if (num <= 1) return false;
        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) return false;
        }
        return true;
    }

    // Find the largest prime smaller than n
    int find_largest_prime(int n) {
        for (int i = n - 1; i >= 2; i--) {
            if (is_prime(i)) {
                return i;
            }
        }
        return 2; // Return the smallest prime if no larger prime is found
    }

    // Hash function 2
    int hash_function2(int key) {
        int prime = find_largest_prime(bucket_count);
        return prime - (key % prime);
    }

    // Resize the table and rehash all elements
    void resizeAndRehash() {
        int old_size = bucket_count;
        bucket_count *= 2; // Double the bucket size
        int* new_table = new int[bucket_count];
        bool* new_deleted = new bool[bucket_count];

        // Initialize new table and deleted flags
        for (int i = 0; i < bucket_count; i++) {
            new_table[i] = -1;
            new_deleted[i] = false;
        }

        // Rehash all elements from the old table to the new table
        for (int i = 0; i < old_size; i++) {
            if (table[i] != -1 && !is_deleted[i]) { // Only rehash valid keys
                int key = table[i];
                int index = hash_function1(key);
                int step = hash_function2(key);

                // Find the next available slot
                while (new_table[index] != -1) {
                    index = (index + step) % bucket_count;
                }
                new_table[index] = key;
            }
        }

        // Delete the old table and update pointers
        delete[] table;
        delete[] is_deleted;
        table = new_table;
        is_deleted = new_deleted;
    }

public:
    // Constructor
    HashTable(int size) : bucket_count(size), num_elements(0) {
        table = new int[bucket_count];
        is_deleted = new bool[bucket_count];

        // Initialize table and deleted flags
        for (int i = 0; i < bucket_count; i++) {
            table[i] = -1;      // -1 indicates an empty slot
            is_deleted[i] = false;
        }
    }

    // Insert a value into the hash table
    void insert(int key) {
        // If load factor exceeds 0.99, resize and rehash
        if (float(num_elements) / bucket_count > 0.99) {
            resizeAndRehash();
        }

        int index = hash_function1(key);
        int step = hash_function2(key);

        // Find the next available slot
        while (table[index] != -1 && table[index] != key) {
            index = (index + step) % bucket_count;
        }

        // If inserting into a new slot, increment element count
        if (table[index] == -1 || is_deleted[index]) {
            table[index] = key;
            is_deleted[index] = false;
            num_elements++;
        }
    }

    // Search for a value in the hash table
    bool search(int key) {
        int index = hash_function1(key);
        int step = hash_function2(key);

        // Probe until we find the key or hit an empty slot
        while (table[index] != -1) {
            if (table[index] == key && !is_deleted[index]) {
                return true; // Key found
            }
            index = (index + step) % bucket_count;
        }
        return false; // Key not found
    }

    // Remove a value from the hash table
    void remove(int key) {
        int index = hash_function1(key);
        int step = hash_function2(key);

        // Probe until we find the key or hit an empty slot
        while (table[index] != -1) {
            if (table[index] == key && !is_deleted[index]) {
                is_deleted[index] = true; // Mark as deleted
                num_elements--;           // Decrement element count
                return;
            }
            index = (index + step) % bucket_count;
        }
    }

    // Display the hash table
    void display() {
        for (int i = 0; i < bucket_count; i++) {
            if (table[i] != -1 && !is_deleted[i]) {
                cout << "Bucket #" << i + 1 << ": " << table[i] << endl;
            } else {
                cout << "Bucket #" << i + 1 << ": [empty]" << endl;
            }
        }
        cout << endl;
    }

    // Destructor to clean up memory
    ~HashTable() {
        delete[] table;
        delete[] is_deleted;
    }
};

int main() {
    HashTable ht(7); // Create a hash table with 7 buckets

    ht.insert(10);
    ht.insert(20);
    ht.insert(15);
    ht.insert(25);
    ht.insert(30);
    ht.insert(5);  // Insert elements
    ht.display();  // Display the table

    cout << "Searching for 25: " << (ht.search(25) ? "Found" : "Not Found") << endl;
    cout << "Searching for 35: " << (ht.search(35) ? "Found" : "Not Found") << endl;

    ht.remove(15); // Remove elements
    ht.remove(5);
    ht.display();  // Display the table after removal

    return 0;
}
