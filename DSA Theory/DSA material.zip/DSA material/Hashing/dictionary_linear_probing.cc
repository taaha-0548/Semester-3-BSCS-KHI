#include <iostream>
#include <string>
using namespace std;
class Dictionary{
    string *dict;
    const int capacity=100;
    int hashing_function(string s){
        int sum=0;
        for(int i=0;i<s.length();i++){
            sum+=s[i];
        }
        return sum % capacity;
    }
    public:
    Dictionary(){
        dict = new string  [capacity];
        for(int i=0;i<capacity;i++){
            dict[i]="";
        }
    }

    void insert(string word){
        int index = hashing_function(word);
        int original=index;
        for(int i=0;i<capacity;i++){
            int index= (original+i)%capacity;
            if(dict[i]==""){
                dict[index]= word;
                return;
            }else if(dict[index]== word){
                cout<<"already exist\n";
                return;
            }
        }
     cout<<"Dictionary full.\n";
    }
    bool search(string word){
        int index= hashing_function(word);
        int original= index;
        for(int i=0;i<capacity;i++){
            index =(original+i)%capacity;
            if(dict[index]== word)
                return true;
            if(dict[index]=="")
            break;
        }
        cout<<"Not found\n";
        return false;
    }
    void display(){
        for(int i=0;i<capacity;i++){
            if(dict[i]=="")
            cout<<"Emtpy"<<endl;
            else
            cout<<dict[i]<<endl;
        }
        cout<<endl;
    }
};
int main(){
Dictionary dictionary;
dictionary.insert("Sarah Jones");
dictionary.insert("John Smith");
dictionary.insert("Tony Balgonie");
dictionary.insert("Tom Katz");
dictionary.display();


}