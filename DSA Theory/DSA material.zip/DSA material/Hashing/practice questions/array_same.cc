#include <iostream>
#include <string>
using namespace std;

class HashMap {
    int *frequency;
    int capacity;

    int hashing_function(int value) {
        return (value  % capacity);
    }

public:
    HashMap(int c) : capacity(c) {
        frequency = new int[capacity]();  // Initialize frequency array to 0
    }

    // Insert the element into the frequency table
    void insert(int value) {
        int index = hashing_function(value);
        frequency[index]++;  // Increment frequency of the element
    }

    // Compare frequencies of two hash tables
    bool compare(HashMap& other) {
        for (int i = 0; i < capacity; i++) {
            if (frequency[i] != other.frequency[i]) {
                return false;  // Frequencies do not match
            }
        }
        return true;
    }
};

bool areArraysEqual(int arr1[], int arr2[], int n) {
    HashMap map1(29);  // Create a hash table for the first array
    HashMap map2(29);  // Create a hash table for the second array

    // Insert elements of both arrays into their respective hash tables
    for (int i = 0; i < n; i++) {
        map1.insert(arr1[i]);
        map2.insert(arr2[i]);
    }

    // Compare the hash tables
    return map1.compare(map2);
}

int main() {
    int arr1[] = {1, 2, 3, 4, 2, 6, 10, 9, 8, 7};
    int arr2[] = {2, 1, 3, 4, 2, 6, 100, 9, 2, 7};
    int n = 10;

    if (areArraysEqual(arr1, arr2, n)) {
        cout << "Yes, both arrays have the same elements with the same frequency." << endl;
    } else {
        cout << "No, the arrays do not have the same elements or frequency." << endl;
    }

    return 0;
}
