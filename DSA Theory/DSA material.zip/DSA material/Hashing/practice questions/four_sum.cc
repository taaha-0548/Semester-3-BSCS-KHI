#include <iostream>
using namespace std;

class Node {
public:
    int a, b, sum;
    Node* next;

    Node(int a = 0, int b = 0, int sum = 0) : a(a), b(b), sum(sum), next(nullptr) {}
};

class HashTable {
    int bucket_count;
    Node** table;

    int hash_function(int value) {
        return abs(value) % bucket_count;  // Handle negative values
    }

public:
    HashTable(int n) : bucket_count(n) {
        table = new Node*[n];
        for (int i = 0; i < n; i++) {
            table[i] = nullptr;
        }
    }

    void insert(int sum, int i, int j) {
        int index = hash_function(sum);
        Node* new_node = new Node(i, j, sum);
        new_node->next = table[index];
        table[index] = new_node;
    }

    bool search(int complement, int k, int l, int arr[], int target) {
        int index = hash_function(complement);
        Node* curr = table[index];
        bool found = false;

        while (curr) {
            if (curr->sum == complement && curr->a != k && curr->b != l) {
                cout << "Found quadruples: (" << arr[curr->a] << ", " << arr[curr->b] 
                     << ", " << arr[k] << ", " << arr[l] << ")\n";
                found = true;
            }
            curr = curr->next;
        }
        return found;
    }

    void find_quadruples(int arr[], int n, int target) {
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                int sum1 = arr[i] + arr[j];
                insert(sum1, i, j);  // Insert all pairs (a, b)
            }
        }

        bool check = false;
        for (int k = 0; k < n; k++) {
            for (int l = k + 1; l < n; l++) {
                int sum2 = arr[k] + arr[l];
                int complement = target - sum2;
                if (search(complement, k, l, arr, target)) {
                    check = true;
                }
            }
        }

        if (!check) {
            cout << "No quadruples found.\n";
        }
    }

    ~HashTable() {
        for (int i = 0; i < bucket_count; i++) {
            Node* curr = table[i];
            while (curr) {
                Node* to_delete = curr;
                curr = curr->next;
                delete to_delete;
            }
        }
        delete[] table;
    }
};

int main() {
    HashTable ht(10);  // Create hash table with 10 buckets
    int arr[] = {1, 0, -1, 0, -2, 2};
    int n = 6, target = 0;

    ht.find_quadruples(arr, n, target);
    return 0;
}
