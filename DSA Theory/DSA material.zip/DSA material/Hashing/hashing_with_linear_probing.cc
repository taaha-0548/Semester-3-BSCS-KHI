#include <iostream>
using namespace std;

class HashTable {
    int* table;
    int capacity;
    int size;

    int hash_function(int key) {
        return key % capacity;
    }

    // Linear probing with a for loop
    int linear_probe(int key) {
        int index = hash_function(key);
        for (int i = 0; i < capacity; ++i) { // Loop until we find an empty slot or full table
            int new_index = (index + i) % capacity;
            if (table[new_index] == -1) { // Found an empty slot
                return new_index;
            }
        }
        return -1; // Table is full
    }

    void resize_and_rehash() {
        int old_capacity = capacity;
        int* old_table = table;

        capacity *= 2; // Double the capacity
        table = new int[capacity];
        size = 0; // Reset the size since we'll re-insert all keys

        for (int i = 0; i < capacity; i++) {
            table[i] = -1; // Initialize the new table with -1 (empty slots)
        }

        // Re-insert all valid keys from the old table
        for (int i = 0; i < old_capacity; i++) {
            if (old_table[i] != -1) {
                insert(old_table[i]);
            }
        }

        delete[] old_table; // Free the old table
        cout << "Rehashed to new capacity: " << capacity << endl;
    }

public:
    HashTable(int cap) : capacity(cap), size(0) {
        table = new int[capacity];
        for (int i = 0; i < capacity; i++) {
            table[i] = -1; // Initialize the table with -1 (empty slots)
        }
    }

    ~HashTable() {
        delete[] table; // Free allocated memory
    }

    // Insert using linear probing
    void insert(int key) {
        if (size >= capacity * 0.7) { // Load factor threshold for rehashing
            resize_and_rehash();
        }

        int index = linear_probe(key);
        if (index == -1) {
            cout << "Hash table full.\n";
            return;
        }
        table[index] = key;
        size++;
        cout << "Inserted " << key << " at index " << index << endl;
    }

    // Search using linear probing
    bool search(int key) {
        int index = hash_function(key);
        for (int i = 0; i < capacity; ++i) {
            int new_index = (index + i) % capacity;
            if (table[new_index] == -1) { // Empty slot indicates key not found
                return false;
            }
            if (table[new_index] == key) { // Key found
                return true;
            }
        }
        return false; // Key not found after full probe
    }

    // Remove a key using linear probing
    void remove(int key) {
        int index = hash_function(key);
        for (int i = 0; i < capacity; ++i) {
            int new_index = (index + i) % capacity;
            if (table[new_index] == -1) { // If empty slot is found, key not present
                break;
            }
            if (table[new_index] == key) {
                table[new_index] = -1; // Mark the slot as empty
                size--;
                cout << "Removed key: " << key << endl;
                return;
            }
        }
        cout << "Key not found.\n";
    }

    // Display the table
    void display() {
        for (int i = 0; i < capacity; i++) {
            if (table[i] != -1)
                cout << table[i] << " ";
            else
                cout << "- ";
        }
        cout << endl;
    }
};

int main() {
    HashTable ht(5); // Small initial capacity for testing rehashing
    ht.insert(20);
    ht.insert(15);
    ht.insert(45);
    ht.insert(105);
    ht.insert(21);
    ht.insert(31); // Should trigger rehashing
    ht.display();

    if (ht.search(105)) {
        cout << "Found\n";
    } else {
        cout << "Not found\n";
    }

    ht.remove(105);
    ht.display();

    return 0;
}
