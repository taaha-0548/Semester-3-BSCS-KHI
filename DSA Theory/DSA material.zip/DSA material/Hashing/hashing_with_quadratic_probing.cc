#include <iostream>
using namespace std;
class HashTable{
    int *table;
    int capacity;
    
    int hash_function(int key){
        return key% capacity;
    }
    int quadratice_probe(int key){
        int index=hash_function(key);
        for(int i=0;i<capacity;i++){
            int new_index=(index+i*i)%capacity;
            if(table[new_index]==-1)
                return new_index;
        }
        return -1; 
    }
    public:
    HashTable(int cap):capacity(cap){
        table =new int [capacity];
        for(int i=0;i<capacity;i++){
            table[i]=-1;
        }
    }
    
    void insert(int key){
        int index =quadratice_probe(key);
        if(index==-1){
            cout<<"Hash table full.\n";
            return;
        }
        table[index]=key;
    }
    bool search(int key){
         int index= hash_function(key);
        int start_index=index;
     for(int i=0;i<capacity;i++){
            int new_index=(index+i*i)%capacity;
            if(table[new_index]==key){
                return true;
            }
             if (table[new_index] == -1)  // No point continuing if the slot is empty
                break;
           
        }
        return false;
    }
    void remove(int key){
       int index= hash_function(key);
        int start_index=index;
        for(int i=0;i<capacity;i++){
            int new_index=(index+i*i)%capacity;
            if(table[new_index]==key){
                table[new_index]=1;
                cout<<"Removed key: "<<key<<endl;
                return;
            }
             if (table[new_index] == -1)  // No point continuing if the slot is empty
                break;
           
        }
        cout<<"Key not found.\n";
    }
    void display(){
        for(int i=0;i<capacity;i++){
            cout<<table[i]<<" ";
        }
        cout<<endl;

    }
};
int main(){
    HashTable ht(10);
    ht.insert(20);
    ht.insert(15);
    ht.insert(45);
    ht.insert(105);
    ht.insert(21);
    ht.insert(31);
    ht.display();
    if(ht.search(105)) cout<<"found\n ";
    else cout<<"not found\n";
    ht.remove(105);
    ht.display();
}