#include <iostream>
using namespace std;

// Node for Linked List (Used for Separate Chaining)
class Node {
public:
    int data;
    Node* next;
    Node(int d) : data(d), next(nullptr) {}
};

// Hash Table with Separate Chaining
class HashTable {
    Node** table; // The hash table (array of linked lists)
    int bucket_count; // The number of buckets in the table
    int num_elements; // The current number of elements in the table

    // Hash function to map a value to an index
    int hash_function(int value) {
        return value % bucket_count;
    }

    // Resize the table and rehash all elements
    void resizeAndRehash() {
        int old_size = bucket_count;
        bucket_count *= 2; // Double the bucket size
        Node** new_table = new Node*[bucket_count](); // Create a new table

        // Rehash all elements from the old table to the new table
        for (int i = 0; i < old_size; i++) {
            Node* curr = table[i];
            while (curr) {
                int new_index = hash_function(curr->data);
                Node* new_node = new Node(curr->data);
                new_node->next = new_table[new_index];
                new_table[new_index] = new_node;
                curr = curr->next;
            }
        }

        // Delete the old table and point to the new table
        delete[] table;
        table = new_table;
    }

public:
    // Constructor
    HashTable(int size) : bucket_count(size), num_elements(0) {
        table = new Node*[bucket_count](); // Initialize all buckets to nullptr
    }

    // Insert a value into the hash table
    void insert(int key) {
        // If load factor exceeds 0.7, resize the table and rehash
        if (float(num_elements) / bucket_count > 0.7) {
            resizeAndRehash();
        }

        int index = hash_function(key); // Find the bucket
        Node* new_node = new Node(key); // Create a new node
        new_node->next = table[index];  // Insert at the beginning of the linked list
        table[index] = new_node;        // Update the head of the linked list
        num_elements++;                 // Increment the number of elements
    }

    // Search for a value in the hash table
    bool search(int key) {
        int index = hash_function(key); // Find the bucket
        Node* curr = table[index];      // Traverse the linked list
        while (curr) {
            if (curr->data == key)      // Key found
                return true;
            curr = curr->next;          // Move to the next node
        }
        return false;                   // Key not found
    }

    // Remove a value from the hash table
    void remove(int key) {
        int index = hash_function(key); // Find the bucket
        Node* curr = table[index];      // Start from the head of the linked list
        Node* prev = nullptr;

        while (curr) {
            if (curr->data == key) {  // Key found
                if (prev) {
                    prev->next = curr->next;  // Bypass the node to delete it
                } else {
                    table[index] = curr->next; // If removing the head, update the head
                }
                delete curr;          // Free the memory
                num_elements--;       // Decrement the number of elements
                return;
            }
            prev = curr;
            curr = curr->next;
        }
    }

    // Display the entire hash table
    void display() {
        for (int i = 0; i < bucket_count; i++) {
            cout << "Bucket #" << i + 1 << ": ";
            Node* curr = table[i];
            while (curr) {
                cout << curr->data << " ";
                curr = curr->next;
            }
            cout << endl;
        }
        cout << endl;
    }

    // Destructor to clean up memory
    ~HashTable() {
        for (int i = 0; i < bucket_count; i++) {
            Node* curr = table[i];
            while (curr) {
                Node* temp = curr;
                curr = curr->next;
                delete temp;
            }
        }
        delete[] table;
    }
};

int main() {
    HashTable ht(5); // Create a hash table with 5 buckets

    ht.insert(30);
    ht.insert(10);
    ht.insert(20);
    ht.insert(35);
    ht.insert(45); 
    ht.insert(25); // This will trigger a resize
    ht.display();   // Display the table

    ht.remove(10);  // Remove an element
    ht.remove(45);  // Remove another element
    ht.display();   // Display the table after removal

    return 0;
}
